<?php

namespace ForGravity\EntryAutomation;

use GFAPI;

/**
 * Class Action
 * @package ForGravity\EntryAutomation
 */
class Action {

	/**
	 * Contains an instance of this class, if available.
	 *
	 * @since  1.2
	 * @access protected
	 * @var    Action $_instance If available, contains an instance of this class.
	 */
	protected static $_instance = null;

	/**
	 * Available Entry Automation actions.
	 *
	 * @since  1.2
	 * @access private
	 * @var    array $_registered_actions Available Entry Automation actions.
	 */
	private static $_registered_actions = array();

	/**
	 * Defines the action name.
	 *
	 * @since  1.2
	 * @access protected
	 * @var    string $name Action name.
	 */
	protected $name;

	/**
	 * Get instance of this class.
	 *
	 * @since  1.2
	 * @access public
	 * @static
	 *
	 * @return Action
	 */
	public static function get_instance() {

		if ( null === static::$_instance ) {
			static::$_instance = new static;
		}

		return static::$_instance;

	}

	/**
	 * Initialize action.
	 *
	 * @since  1.4
	 * @access public
	 */
	public function __construct() {
	}

	/**
	 * Action name.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return string
	 */
	public function get_name() {

		return $this->name;

	}





	// # ACTION REGISTRATION -------------------------------------------------------------------------------------------

	/**
	 * Registers an action so that it gets initialized appropriately.
	 *
	 * @since  1.2
	 * @access public
	 * @static
	 *
	 * @param string $class The class name.
	 */
	public static function register( $class = '' ) {

		if ( class_exists( $class ) ) {
			self::$_registered_actions[] = $class;
		}

	}

	/**
	 * Gets all registered actions.
	 *
	 * @since  1.2
	 * @access public
	 * @static
	 *
	 * @uses   Action::$_registered_actions
	 *
	 * @return Action[]
	 */
	public static function get_registered_actions() {

		// Initialize actions array.
		$actions = array();

		// Loop through registered actions.
		foreach ( self::$_registered_actions as $action ) {

			// Get action.
			$action = call_user_func( array( $action, 'get_instance' ) );

			// Add to array.
			$actions[ $action->get_name() ] = $action;

		}

		return $actions;

	}

	/**
	 * Get action by name.
	 *
	 * @since  1.2
	 * @access public
	 * @static
	 *
	 * @param string $name Action name.
	 *
	 * @uses   Action::get_registered_actions()
	 *
	 * @return static|bool
	 */
	public static function get_action_by_name( $name = '' ) {

		// If name is blank, return.
		if ( rgblank( $name ) ) {
			return false;
		}

		// Get registered actions.
		$actions = self::get_registered_actions();

		// If action is registered, return.
		if ( isset( $actions[ $name ] ) ) {
			return $actions[ $name ];
		}

		return false;

	}




	// # ACTION SETTINGS -----------------------------------------------------------------------------------------------

	/**
	 * Retrieves settings fields for configuring this Entry Automation action.
	 *
	 * @since  1.2.4
	 * @access public
	 *
	 * @return array
	 */
	public function get_settings_fields() {

		/**
		 * Modify the Entry Automation action settings fields.
		 *
		 * @since 1.2.4
		 *
		 * @param array $settings Settings fields.
		 */
		return apply_filters( 'fg_entryautomation_' . $this->name . '_settings_fields', $this->settings_fields() );

	}

	/**
	 * Settings fields for configuring this Entry Automation action.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return array
	 */
	public function settings_fields() {

		return array();

	}

	/**
	 * Icon class for Entry Automation settings button.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return string
	 */
	public function get_icon() {

		return 'fa-cogs';

	}

	/**
	 * Action label, used in Entry Automation settings.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return string
	 */
	public function get_label() {
	}

	/**
	 * Action short label, used in Entry Automation Tasks table.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return string
	 */
	public function get_short_label() {
	}




	// # ACTION SETTINGS -----------------------------------------------------------------------------------------------

	/**
	 * Add links to feed list actions.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array  $links  Action links to be filtered.
	 * @param array  $task   Entry Automation Task meta.
	 * @param string $column The column ID.
	 *
	 * @return array
	 */
	public function feed_list_actions( $links, $task, $column ) {

		return $links;

	}




	// # RUNNING ACTION ------------------------------------------------------------------------------------------------

	/**
	 * Determine if task should be run.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array    $task          Entry Automation Task meta.
	 * @param int|bool $task_run_time Run time of current task.
	 *
	 * @uses   Action::get_name()
	 * @uses   Action::run_task()
	 * @uses   Entry_Automation::get_search_criteria()
	 * @uses   Entry_Automation::prepare_next_run_time()
	 * @uses   GFAddOn::get_slug()
	 * @uses   GFAddOn::log_debug()
	 * @uses   GFAPI::count_entries()
	 */
	public function maybe_run_task( $task, $task_run_time = false ) {

		// Prepare task run time.
		if ( ! $task_run_time ) {
			$task_run_time = fg_entryautomation()->strtotime();
		}

		// Prepare next run time.
		$next_run_time = $this->prepare_next_run_time( $task, $task_run_time );

		// If task is deactivated, exit.
		if ( ! $task['is_active'] ) {

			// Log that we are skipping processing.
			fg_entryautomation()->log_debug( __METHOD__ . '(): Skipping ' . $this->get_name() . ' process for task #' . $task['task_id'] . ' because task is deactivated.' );

			// Schedule next run.
			Scheduler::schedule_task( $task['task_id'], $task['form_id'], $next_run_time );

			return;

		}

		// Log that we are beginning to run the task.
		fg_entryautomation()->log_debug( __METHOD__ . '(): Starting ' . $this->get_name() . ' process for task #' . $task['task_id'] . ' on form #' . $task['form_id'] );

		// Get form.
		$form = GFAPI::get_form( $task['form_id'] );

		// If form was not found, exit.
		if ( ! $form ) {

			// Log that form could not be found.
			fg_entryautomation()->log_error( __METHOD__ . '(): Not running task #' . $task['task_id'] . ' because form #' . $task['form_id'] . ' could not be found.' );

			return;

		}

		// Get search criteria for task.
		$search_criteria = fg_entryautomation()->get_search_criteria( $task, $form );

		// Log the search criteria.
		fg_entryautomation()->log_debug( __METHOD__ . '(): Search criteria for task #' . $task['task_id'] . ': ' . print_r( $search_criteria, true ) );

		// Get entry found for search criteria.
		$found_entries = GFAPI::count_entries( $form['id'], $search_criteria );

		/**
		 * Disable the task from not running if no entries matched the search criteria.
		 *
		 * @since 1.3.6
		 *
		 * @param bool $disable_task_skipping Disable task skipping
		 * @param array $task                 The current Task object.
		 */
		$disable_task_skipping = gf_apply_filters( array(
			'fg_entryautomation_disable_task_skipping',
			$task['form_id'],
			$task['task_id'],
		), false, $task );

		// If no entries were found, exit.
		if ( ! $found_entries && ! $disable_task_skipping ) {

			// Log that no entries were found.
			fg_entryautomation()->log_debug( __METHOD__ . '(): Not running task #' . $task['task_id'] . ' because no entries were found matching the search criteria.' );

			// Set last run time.
			update_option( fg_entryautomation()->get_slug() . '_last_run_time_' . $task['task_id'], fg_entryautomation()->strtotime() );

			// Schedule next run.
			Scheduler::schedule_task( $task['task_id'], $task['form_id'], $next_run_time );

			return;

		}

		// Run task.
		$this->run_task( $task, $form );

		// Set last run time.
		update_option( fg_entryautomation()->get_slug() . '_last_run_time_' . $task['task_id'], $task_run_time );

		// Log next run time.
		fg_entryautomation()->log_debug( __METHOD__ . '(): Scheduling next run time for task #' . $task['task_id'] . ': ' . fg_entryautomation()->strtotime( $next_run_time, 'Y-m-d g:i A', true, true ) );

		// Schedule next run.
		Scheduler::schedule_task( $task['task_id'], $task['form_id'], $next_run_time );

	}

	/**
	 * Run task.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array $task Entry Automation Task meta.
	 * @param array $form The form object.
	 */
	public function run_task( $task, $form ) {
	}




	// # ACTION DELETION -----------------------------------------------------------------------------------------------

	/**
	 * Delete task.
	 *
	 * @since  1.2.5
	 * @access public
	 *
	 * @param int $task_id Task ID.
	 */
	public function delete_task( $task_id ) {
	}




	// # HELPER METHODS ------------------------------------------------------------------------------------------------

	/**
	 * Prepare the next time an Entry Automation task should run.
	 *
	 * @since  1.0.4
	 * @access public
	 *
	 * @param array $task          Entry Automation Task meta.
	 * @param int   $task_run_time Run time of current task.
	 *
	 * @return int
	 */
	public function prepare_next_run_time( $task, $task_run_time ) {

		// Get interval.
		switch ( $task['runTime']['unit'] ) {

			case 'minutes':
				$interval = $task['runTime']['number'] * MINUTE_IN_SECONDS;
				break;

			case 'hours':
				$interval = $task['runTime']['number'] * HOUR_IN_SECONDS;
				break;

			case 'days':
				$interval = $task['runTime']['number'] * DAY_IN_SECONDS;
				break;

			case 'weeks':
				$interval = $task['runTime']['number'] * WEEK_IN_SECONDS;
				break;

			case 'months':
				$interval = $task['runTime']['number'] * MONTH_IN_SECONDS;
				break;

			case 'years':
				$interval = $task['runTime']['number'] * YEAR_IN_SECONDS;
				break;


		}

		// Calculate next run time.
		$next_run_time = $task_run_time + $interval;

		/**
		 * Modify when the task will run next.
		 *
		 * @since 1.4.1
		 *
		 * @param int   $next_run_time Unix timestamp for when the task runs next.
		 * @param array $task          Entry Automation task meta.
		 * @param int   $task_run_time Run time of current task.
		 */
		return apply_filters( 'fg_entryautomation_next_run_time', $next_run_time, $task, $task_run_time );

	}

}
