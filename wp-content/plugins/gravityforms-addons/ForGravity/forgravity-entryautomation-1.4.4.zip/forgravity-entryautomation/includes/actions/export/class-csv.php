<?php

namespace ForGravity\EntryAutomation\Action\Export;

use ForGravity\EntryAutomation\Action\Export;
use GFAPI;
use GFCommon;
use GFExport;
use GFFormsModel;

if ( ! class_exists( '\ForGravity\EntryAutomation\Action\Export' ) ) {
	require_once fg_entryautomation()->get_base_path() . '/includes/actions/class-export.php';
}

/**
 * Export entries to CSV file.
 *
 * @since 1.4
 */
class CSV extends Export {

	/**
	 * Export form entries to CSV file.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array $task Entry Automation Task meta.
	 * @param array $form The Form object.
	 *
	 * @uses   Entry_Automation::get_field_value()
	 * @uses   Entry_Automation::get_search_criteria()
	 * @uses   Export::build_csv_header()
	 * @uses   Export::add_default_export_fields()
	 * @uses   Export::get_export_fields()
	 * @uses   Export::get_file_name()
	 * @uses   GFAPI::get_entries()
	 * @uses   GFCommon::get_base_path()
	 *
	 * @return string
	 */
	public static function prepare_file( $task, $form ) {

		// Require export class.
		if ( ! class_exists( 'GFExport' ) ) {
			require_once GFCommon::get_base_path() . '/export.php';
		}

		// Get export file name.
		$file_path = self::get_file_name( $task, $form );

		// Log export file name.
		fg_entryautomation()->log_debug( __METHOD__ . '(): Exporting entries to file "' . $file_path . '".' );

		// Prepare search criteria.
		$search_criteria = fg_entryautomation()->get_search_criteria( $task, $form );

		// Prepare paging criteria.
		$paging = array(
			'offset'    => 0,
			'page_size' => 50,
		);

		// Get sorting.
		$sorting = self::get_sorting( $task, $form );

		// Get total entry count.
		$found_entries = GFAPI::count_entries( $form['id'], $search_criteria );

		// Set entries processed count.
		$entries_processed = 0;

		// Get export fields.
		$fields = self::get_export_fields( $task );

		// Add default export fields to form.
		$form = self::add_default_export_fields( $form, 'csv' );

		// Get field row counts.
		$field_rows = GFExport::get_field_row_count( $form, wp_list_pluck( $fields, 'id' ), $found_entries );

		// Define the separator.
		$separator = gf_apply_filters( array( 'gform_export_separator', $form['id'] ), ',', $form['id'] );

		// Get export header.
		$header = self::build_header( $form, $fields, $separator, $field_rows );

		// Write header to file.
		file_put_contents( $file_path, $header, FILE_APPEND );

		// Loop until all entries have been processed.
		while ( $entries_processed < $found_entries ) {

			// Log the page number.
			fg_entryautomation()->log_debug( __METHOD__ . '(): Starting export of page ' . ( round( $entries_processed / $paging['page_size'] ) + 1 ) . ' of ' . ( round( $found_entries / $paging['page_size'] ) + 1 ) );

			// Get entries.
			$entries = GFAPI::get_entries( $form['id'], $search_criteria, $sorting, $paging );

			// If no more entries were found, break.
			if ( empty( $entries ) ) {
				fg_entryautomation()->log_debug( __METHOD__ . '(): No entries were found for this page.' );
				break;
			}

			// Initialize export string.
			$lines = '';

			// Loop through entries.
			foreach ( $entries as $entry ) {

				// Loop through export fields.
				foreach ( $fields as $field_meta ) {

					// Get field value.
					$field_value = self::get_field_value( $form, $entry, $field_meta['id'] );

					/**
					 * Override the field value before it is included in the CSV export.
					 *
					 * @since 1.1.6
					 *
					 * @param string $field_value Value of the field being exported.
					 * @param array  $form        The Form object.
					 * @param string $field_id    The ID of the current field.
					 * @param array  $entry       The Entry object.
					 * @param array  $task        Entry Automation Task meta.
					 */
					$field_value = apply_filters( 'fg_entryautomation_export_field_value', $field_value, $form, $field_meta['id'], $entry, $task );

					if ( isset( $field_rows[ $field_meta['id'] ] ) ) {

						// Loop through List filed rows.
						foreach ( $field_value as $row ) {

							// Convert row to string.
							$row_values = array_values( $row );
							$row_string = implode( '|', $row_values );

							// Prevent Excel formulas.
							if ( 0 === strpos( $row_string, '=' ) ) {
								$row_string = "'" . $row_string;
							}

							$lines .= '"' . str_replace( '"', '""', $row_string ) . '"' . $separator;

						}

						// Fill in missing subrow columns.
						$missing_subrows = intval( $field_rows [ $field_meta['id'] ] ) - count( $field_value );

						for ( $i = 0; $i < $missing_subrows; $i++ ) {
							$lines .= '""' . $separator;
						}

					} else {

						// If field value is an array, convert it to a string.
						if ( is_array( $field_value ) ) {
							$field_value = implode( '|', $field_value );
						}

						// Prevent Excel formulas.
						if ( 0 === strpos( $field_value, '=' ) ) {
							$field_value = "'" . $field_value;
						}

						// Add field value to export string.
						$lines .= '"' . str_replace( '"', '""', $field_value ) . '"' . $separator;

					}

				}

				// Remove last separator from line.
				$lines = substr( $lines, 0, strlen( $lines ) - strlen( $separator ) );

				// Add line break.
				$lines .= PHP_EOL;

				// Increase entries processed count.
				$entries_processed++;

			}

			// Convert lines.
			if ( function_exists( 'mb_convert_encoding' ) ) {
				$lines = mb_convert_encoding( $lines, get_option( 'blog_charset' ) );
			}

			/**
			 * Filter the CSV entry export lines before they are written to the file.
			 *
			 * @since 1.3.5
			 *
			 * @param string $lines     Lines to be included in .csv export
			 * @param array  $task      Entry Automation Task meta.
			 * @param string $file_path File name of export file.
			 */
			$lines = apply_filters( 'fg_entryautomation_export_lines', $lines, $task, $file_path );

			// Write export string to file.
			file_put_contents( $file_path, $lines, FILE_APPEND );

			// Increase offset.
			$paging['offset'] += $paging['page_size'];

		}

		// Log that export has been completed.
		fg_entryautomation()->log_debug( __METHOD__ . '(): Export completed.' );

		/**
		 * Executed after entries have been exported.
		 *
		 * @param array  $task      Entry Automation Task meta.
		 * @param array  $form      The form object.
		 * @param string $file_path File name of export file.
		 */
		gf_do_action( array( 'fg_entryautomation_after_export', $form['id'] ), $task, $form, $file_path );

		return $file_path;

	}





	// # HELPER METHODS ------------------------------------------------------------------------------------------------

	/**
	 * Get header for CSV export file.
	 *
	 * @since  1.4
	 * @access public
	 *
	 * @param array  $form       The form object.
	 * @param array  $fields     Fields being exported.
	 * @param string $separator  Column separator.
	 * @param array  $field_rows Row count for each field.
	 *
	 * @uses   Export::get_field_label()
	 *
	 * @return string
	 */
	public static function build_header( $form, $fields, $separator, $field_rows = array() ) {

		// Initialize header string.
		$header = '';

		// Loop through export fields.
		foreach ( $fields as $field ) {

			// Get filed label.
			$label = self::get_field_label( $form, $field );

			// Get subrow count.
			$subrow_count = isset( $field_rows[ $field['id'] ] ) ? intval( $field_rows[ $field['id'] ] ) : 0;

			// Add label to header.
			if ( $subrow_count === 0 ) {
				$header .= '"' . str_replace( '"', '""', $label ) . '"' . $separator;
			} else {
				for ( $i = 1; $i <= $subrow_count; $i++ ) {
					$header .= '"' . str_replace( '"', '""', $label ) . ' ' . $i . '"' . $separator;
				}
			}

		}

		// Remove last separator from header.
		$header = substr( $header, 0, strlen( $header ) - strlen( $separator ) );

		// Add line break.
		$header .= PHP_EOL;

		return $header;

	}

	/**
	 * Get header for CSV export file.
	 *
	 * @since  1.4
	 * @access public
	 *
	 * @param array $form       The form object.
	 * @param array $field_meta Fields being exported.
	 *
	 * @uses   GFCommon::get_label()
	 * @uses   GFFormsModel::get_field()
	 *
	 * @return string
	 */
	public static function get_field_label( $form, $field_meta ) {

		// Get label.
		$label = parent::get_field_label( $form, $field_meta );

		// Get field.
		$field = GFFormsModel::get_field( $form, $field_meta['id'] );

		/**
		 * Override the field header in the entries export.
		 *
		 * @since 1.0
		 *
		 * @param string $label The header being used for the current field. Defaults to the field label (input label for multi-input fields).
		 * @param array  $form  The current form.
		 * @param array  $field The current field.
		 */
		$label = gf_apply_filters( array(
			'gform_entries_field_header_pre_export',
			$form['id'],
			$field_meta['id'],
		), $label, $form, $field );

		// Strip quotes from label.
		$label = str_replace( '"', '""', $label );

		// Prevent Excel formulas.
		if ( 0 === strpos( $label, '=' ) ) {
			$label = "'" . $label;
		}

		return $label;

	}

	/**
	 * Get values for Repeater field.
	 *
	 * @since  1.4
	 * @access protected
	 *
	 * @param array              $form           The Form object.
	 * @param array              $entry          The Entry object.
	 * @param \GF_Field_Repeater $repeater_field Repeater Field object.
	 * @param bool               $is_csv         Return value for CSV file.
	 *
	 * @uses   \GF_Field_Repeater::get_value_export()
	 *
	 * @return array
	 */
	protected static function get_repeater_field_value( $form, $entry, $repeater_field, $is_csv = true ) {

		return $repeater_field->get_value_export( $entry, '', false, $is_csv );

	}

}
