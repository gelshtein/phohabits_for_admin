<?php

namespace ForGravity\EntryAutomation\Action\Export;

use ForGravity\EntryAutomation\Action\Export;
use GFAPI;
use GFCommon;

if ( ! class_exists( '\ForGravity\EntryAutomation\Action\Export' ) ) {
	require_once fg_entryautomation()->get_base_path() . '/includes/actions/class-export.php';
}

/**
 * Export entries to JSON file.
 *
 * @since 1.4
 */
class JSON extends Export {

	/**
	 * Export form entries to JSON file.
	 *
	 * @since  1.4
	 *
	 * @param array $task Entry Automation Task meta.
	 * @param array $form The Form object.
	 *
	 * @uses   Entry_Automation::get_field_value()
	 * @uses   Entry_Automation::get_search_criteria()
	 * @uses   Export::add_default_export_fields()
	 * @uses   Export::get_file_name()
	 * @uses   GFAPI::get_entries()
	 * @uses   GFCommon::get_base_path()
	 *
	 * @return string
	 */
	public static function prepare_file( $task, $form ) {

		// Get export file name.
		$file_path = self::get_file_name( $task, $form );

		// Log export file name.
		fg_entryautomation()->log_debug( __METHOD__ . '(): Exporting entries to file "' . $file_path . '".' );

		// Prepare search criteria.
		$search_criteria = fg_entryautomation()->get_search_criteria( $task, $form );

		// Prepare paging criteria.
		$paging = array(
			'offset'    => 0,
			'page_size' => 50,
		);

		// Get sorting.
		$sorting = self::get_sorting( $task, $form );

		// Get total entry count.
		$found_entries = GFAPI::count_entries( $form['id'], $search_criteria );

		// Set entries processed count.
		$entries_processed = 0;

		// Get export fields.
		$fields = self::get_export_fields( $task );

		// Add default export fields to form.
		$form = self::add_default_export_fields( $form, 'json' );

		// Initialize JSON array.
		$json = array();

		// Loop until all entries have been processed.
		while ( $entries_processed < $found_entries ) {

			// Log the page number.
			fg_entryautomation()->log_debug( __METHOD__ . '(): Starting export of page ' . ( round( $entries_processed / $paging['page_size'] ) + 1 ) . ' of ' . ( round( $found_entries / $paging['page_size'] ) + 1 ) );

			// Get entries.
			$entries = GFAPI::get_entries( $form['id'], $search_criteria, $sorting, $paging );

			// If no more entries were found, break.
			if ( empty( $entries ) ) {
				fg_entryautomation()->log_debug( __METHOD__ . '(): No entries were found for this page.' );
				break;
			}

			// Loop through entries.
			foreach ( $entries as $entry ) {

				// Initialize JSON entry array.
				$json_entry = array();

				// Loop through export fields.
				foreach ( $fields as $field_meta ) {

					// Get field label and value.
					$label = self::get_field_label( $form, $field_meta );
					$value = self::get_field_value( $form, $entry, $field_meta['id'], false );

					/**
					 * Override the field value before it is included in the JSON export.
					 *
					 * @since 1.1.6
					 *
					 * @param string $field_value Value of the field being exported.
					 * @param array  $form        The Form object.
					 * @param string $field_id    The ID of the current field.
					 * @param array  $entry       The Entry object.
					 * @param array  $task        Entry Automation Task meta.
					 */
					$value = apply_filters( 'fg_entryautomation_export_field_value', $value, $form, $field_meta['id'], $entry, $task );

					// Convert value.
					if ( function_exists( 'mb_convert_encoding' ) ) {

						// Convert array.
						if ( is_array( $value ) ) {
							array_walk_recursive( $value, function( $val ) {
								return mb_convert_encoding( $val, get_option( 'blog_charset' ) );
							} );
						} else {
							$value = mb_convert_encoding( $value, get_option( 'blog_charset' ) );
						}

					}

					// Add entry to JSON array.
					$json_entry[ $label ] = $value;

				}

				// Add entry to JSON array.
				$json[] = $json_entry;

				// Increase entries processed count.
				$entries_processed++;

			}

			// Increase offset.
			$paging['offset'] += $paging['page_size'];

		}

		// Write export string to file.
		file_put_contents( $file_path, json_encode( $json ) );

		// Log that export has been completed.
		fg_entryautomation()->log_debug( __METHOD__ . '(): Export completed.' );

		/**
		 * Executed after entries have been exported.
		 *
		 * @param array  $task      Entry Automation Task meta.
		 * @param array  $form      The form object.
		 * @param string $file_path File name of export file.
		 */
		gf_do_action( array( 'fg_entryautomation_after_export', $form['id'] ), $task, $form, $file_path );

		return $file_path;

	}





	// # HELPER METHODS ------------------------------------------------------------------------------------------------

	/**
	 * Get field value from entry.
	 *
	 * @since  1.4.1
	 * @access public
	 *
	 * @param array  $form     The Form object.
	 * @param array  $entry    The Entry object.
	 * @param string $field_id The field ID to return.
	 * @param bool   $is_csv   Return value for CSV file.
	 *
	 * @uses   GFAPI::get_field()
	 * @uses   Export::get_field_value()
	 *
	 * @return string
	 */
	public static function get_field_value( $form, $entry, $field_id, $is_csv = true ) {

		// Get field.
		$field = GFAPI::get_field( $form, $field_id );

		// If field is a list field, return entry value.
		if ( is_a( $field, '\GF_Field_List' ) ) {
			$field_value = rgar( $entry, $field_id );
			$field_value = maybe_unserialize( $field_value );
			return $field_value;
		}

		return parent::get_field_value( $form, $entry, $field_id, $is_csv );

	}

}
