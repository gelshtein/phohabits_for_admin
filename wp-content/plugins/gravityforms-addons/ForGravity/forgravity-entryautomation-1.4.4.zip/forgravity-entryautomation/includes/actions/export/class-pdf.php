<?php

namespace ForGravity\EntryAutomation\Action\Export;

use ForGravity\EntryAutomation\Action\Export;
use GFAPI;
use GFCommon;
use mPDF;

if ( ! class_exists( '\ForGravity\EntryAutomation\Action\Export' ) ) {
	require_once fg_entryautomation()->get_base_path() . '/includes/actions/class-export.php';
}

/**
 * Export entries to PDF file.
 *
 * @since 1.4
 */
class PDF extends Export {

	/**
	 * Export form entries to PDF file.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array $task Entry Automation Task meta.
	 * @param array $form The Form object.
	 *
	 * @uses   Entry_Automation::get_field_value()
	 * @uses   Entry_Automation::get_search_criteria()
	 * @uses   Export::add_default_export_fields()
	 * @uses   Export::get_file_name()
	 * @uses   GFAPI::get_entries()
	 * @uses   GFCommon::get_base_path()
	 *
	 * @return string
	 */
	public static function prepare_file( $task, $form ) {

		// Require needed classes.
		if ( ! class_exists( 'GFExport' ) ) {
			require_once GFCommon::get_base_path() . '/export.php';
		}
		if ( ! class_exists( 'GFEntryDetail' ) ) {
			require_once GFCommon::get_base_path() . '/entry_detail.php';
		}

		// Get export file name.
		$file_path = self::get_file_name( $task, $form );

		// Log export file name.
		fg_entryautomation()->log_debug( __METHOD__ . '(): Exporting entries to file "' . $file_path . '".' );

		// Begin output buffering.
		ob_end_clean();
		ob_start( 'ob_gzhandler' );

		// Display PDF header.
		include fg_entryautomation()->get_base_path() . '/includes/templates/export-pdf-header.php';

		// Prepare search criteria.
		$search_criteria = fg_entryautomation()->get_search_criteria( $task, $form );

		// Prepare paging criteria.
		$paging = array(
			'offset'    => 0,
			'page_size' => 50,
		);

		// Get sorting.
		$sorting = self::get_sorting( $task, $form );

		// Get total entry count.
		$found_entries = GFAPI::count_entries( $form['id'], $search_criteria );

		// Set entries processed count.
		$entries_processed = 0;

		// Add default export fields to form.
		$form = self::add_default_export_fields( $form, 'pdf' );

		// Get fields.
		$fields = self::get_export_fields( $task );

		// Loop until all entries have been processed.
		while ( $entries_processed < $found_entries ) {

			// Log the page number.
			fg_entryautomation()->log_debug( __METHOD__ . '(): Starting export of page ' . ( round( $entries_processed / $paging['page_size'] ) + 1 ) . ' of ' . ( round( $found_entries / $paging['page_size'] ) + 1 ) );

			// Get entries.
			$entries = GFAPI::get_entries( $form['id'], $search_criteria, $sorting, $paging );

			// If no more entries were found, break.
			if ( empty( $entries ) ) {
				fg_entryautomation()->log_debug( __METHOD__ . '(): No entries were found for this page.' );
				break;
			}

			// Loop through entries.
			foreach ( $entries as $entry ) {

				// Display entry.
				require fg_entryautomation()->get_base_path() . '/includes/templates/export-pdf-entry.php';

				// Increase entries processed count.
				$entries_processed++;

			}

			// Increase offset.
			$paging['offset'] += $paging['page_size'];

		}

		// Display PDF footer.
		require fg_entryautomation()->get_base_path() . '/includes/templates/export-pdf-footer.php';

		// Get PDF contents.
		$html = ob_get_clean();

		// Include mPDF.
		if ( ! class_exists( 'mPDF' ) ) {
			require_once fg_entryautomation()->get_base_path() . '/includes/vendor/mpdf/mpdf.php';
		}

		try {

			// Initialize mPDF.
			$mpdf = new mPDF( 'c' );

			// Write HTML to object.
			$mpdf->WriteHTML( $html );

			// Save PDF to file path.
			$mpdf->Output( $file_path );

		} catch ( \Exception $e ) {

			// Log that file could not be saved.
			fg_entryautomation()->log_error( __METHOD__ . '(): Unable to export entries to PDF; ' . $e->getMessage() );

			return false;

		}

		// Log that export has been completed.
		fg_entryautomation()->log_debug( __METHOD__ . '(): Export completed.' );

		/**
		 * Executed after entries have been exported.
		 *
		 * @param array  $task      Entry Automation Task meta.
		 * @param array  $form      The form object.
		 * @param string $file_path File name of export file.
		 */
		gf_do_action( array( 'fg_entryautomation_after_export', $form['id'] ), $task, $form, $file_path );

		return $file_path;

	}

}
