<?php

namespace ForGravity;

use ForGravity\EntryAutomation\Action;
use ForGravity\EntryAutomation\Extension;
use ForGravity\EntryAutomation\Scheduler;

use DateTime;
use DateTimeZone;
use Exception;

use GFAddOn;
use GFAPI;
use GFCommon;
use GFFeedAddOn;
use GFForms;
use GFFormsModel;

GFForms::include_feed_addon_framework();

/**
 * Entry Automation for Gravity Forms.
 *
 * @since     1.0
 * @author    ForGravity
 * @copyright Copyright (c) 2017, Travis Lopes
 */
class Entry_Automation extends GFFeedAddOn {

	/**
	 * Contains an instance of this class, if available.
	 *
	 * @since  1.0
	 * @access private
	 * @var    Entry_Automation $_instance If available, contains an instance of this class.
	 */
	private static $_instance = null;

	/**
	 * Defines the version of Gravity Forms Entry Automation.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string $_version Contains the version, defined from entryautomation.php
	 */
	protected $_version = FG_ENTRYAUTOMATION_VERSION;

	/**
	 * Defines the minimum Gravity Forms version required.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string $_min_gravityforms_version The minimum version required.
	 */
	protected $_min_gravityforms_version = '1.9.13';

	/**
	 * Defines the plugin slug.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string $_slug The slug used for this plugin.
	 */
	protected $_slug = 'entryautomation';

	/**
	 * Defines the main plugin file.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string $_path The path to the main plugin file, relative to the plugins folder.
	 */
	protected $_path = 'forgravity-entryautomation/entryautomation.php';

	/**
	 * Defines the full path to this class file.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string $_full_path The full path.
	 */
	protected $_full_path = __FILE__;

	/**
	 * Defines the URL where this Add-On can be found.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string The URL of the Add-On.
	 */
	protected $_url = 'http://forgravity.com/entry-automation';

	/**
	 * Defines the title of this Add-On.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string $_title The title of the Add-On.
	 */
	protected $_title = 'Entry Automation for Gravity Forms';

	/**
	 * Defines the short title of the Add-On.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string $_short_title The short title.
	 */
	protected $_short_title = 'Entry Automation';

	/**
	 * Allows configuration of what order feeds are executed in from the feed list page.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    bool $_supports_feed_ordering
	 */
	protected $_supports_feed_ordering = true;

	/**
	 * Defines the capability needed to access the Add-On settings page.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string $_capabilities_settings_page The capability needed to access the Add-On settings page.
	 */
	protected $_capabilities_settings_page = 'forgravity_entryautomation';

	/**
	 * Defines the capability needed to access the Add-On form settings page.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string $_capabilities_form_settings The capability needed to access the Add-On form settings page.
	 */
	protected $_capabilities_form_settings = 'forgravity_entryautomation';

	/**
	 * Defines the capability needed to uninstall the Add-On.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    string $_capabilities_uninstall The capability needed to uninstall the Add-On.
	 */
	protected $_capabilities_uninstall = 'forgravity_entryautomation_uninstall';

	/**
	 * Defines the capabilities needed for Entry Automation.
	 *
	 * @since  1.0
	 * @access protected
	 * @var    array $_capabilities The capabilities needed for the Add-On
	 */
	protected $_capabilities = array( 'forgravity_entryautomation', 'forgravity_entryautomation_uninstall' );

	/**
	 * Get instance of this class.
	 *
	 * @since  1.0
	 * @access public
	 * @static
	 *
	 * @return \ForGravity\Entry_Automation
	 */
	public static function get_instance() {

		if ( null === self::$_instance ) {
			self::$_instance = new self;
		}

		return self::$_instance;

	}

	/**
	 * Register needed pre-initialization hooks.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @uses   Entry_Automation::strtotime()
	 */
	public function pre_init() {

		parent::pre_init();

		add_action( FG_ENTRYAUTOMATION_EVENT, array( $this, 'run_automation' ) );

	}

	/**
	 * Register needed hooks.
	 *
	 * @since  1.0
	 * @access public
	 */
	public function init() {

		parent::init();

		remove_filter( 'gform_entry_post_save', array( $this, 'maybe_process_feed' ) );

		add_action( 'gform_after_delete_form', array( $this, 'action_gform_after_delete_form' ), 10, 1 );

		add_filter( 'auto_update_plugin', array( $this, 'maybe_auto_update' ), 10, 2 );
		add_filter( $this->_slug . '_feed_actions', array( $this, 'feed_list_actions' ), 10, 3 );

		// Polls Add-On support
		if ( function_exists( 'gf_polls' ) ) {
			add_filter( 'fg_entryautomation_export_field_value', array( gf_polls(), 'display_entries_field_value' ), 10, 4 );
		}

		// Quiz Add-On support
		if ( function_exists( 'gf_quiz' ) ) {
			add_filter( 'fg_entryautomation_export_field_value', array( gf_quiz(), 'display_export_field_value' ), 10, 4 );
		}

		// Survey Add-On support
		if ( function_exists( 'gf_survey' ) ) {
			add_filter( 'fg_entryautomation_export_field_value', array( gf_survey(), 'export_field_value' ), 10, 4 );
		}

	}

	/**
	 * Register needed hooks.
	 *
	 * @since  1.1.5
	 * @access public
	 */
	public function init_admin() {

		parent::init_admin();

		add_action( 'admin_init', array( $this, 'maybe_serve_export_file' ) );

		// Members 2.0+ integration.
		if ( function_exists( 'members_register_cap_group' ) ) {
			remove_filter( 'members_get_capabilities', array( $this, 'members_get_capabilities' ) );
			add_action( 'members_register_cap_groups', array( $this, 'members_register_cap_group' ) );
			add_action( 'members_register_caps', array( $this, 'members_register_caps' ) );
		}

	}

	/**
	 * Register needed AJAX actions.
	 *
	 * @since  1.0.6
	 * @access public
	 */
	public function init_ajax() {

		parent::init_ajax();

		add_action( 'wp_ajax_' . $this->_slug . '_time_preview', array( $this, 'ajax_time_preview' ) );
		add_action( 'wp_ajax_' . $this->_slug . '_run_task', array( $this, 'ajax_run_task' ) );

		add_action( 'wp_ajax_fg_entryautomation_extension_action', array( $this, 'ajax_handle_extension_action' ) );

	}

	/**
	 * Define minimum requirements needed to run Entry Automation.
	 *
	 * @since  1.0.7
	 * @access public
	 *
	 * @return array
	 */
	public function minimum_requirements() {

		return array( 'php' => array( 'version' => '5.6' ) );

	}

	/**
	 * Enqueue needed scripts.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @return array
	 */
	public function scripts() {

		$scripts = array(
			array(
				'handle'  => $this->get_slug() . '_vendor_react',
				'src'     => '//unpkg.com/react@16.2.0/umd/react.production.min.js',
				'version' => '16.2.0',
			),
			array(
				'handle'  => $this->get_slug() . '_vendor_react-dom',
				'src'     => '//unpkg.com/react-dom@16.2.0/umd/react-dom.production.min.js',
				'version' => '16.2.0',
			),
			array(
				'handle'  => $this->get_slug() . '_vendor-moment',
				'src'     => '//unpkg.com/moment@2.18.1/min/moment.min.js',
				'version' => '2.18.1',
			),
			array(
				'handle'  => 'forgravity_entryautomation_feed_settings',
				'src'     => $this->get_base_url() . '/js/feed_settings.min.js',
				'version' => $this->_version,
				'deps'    => array( 'jquery', $this->get_slug() . '_vendor_react', $this->get_slug() . '_vendor_react-dom', $this->get_slug() . '_vendor-moment' ),
				'enqueue' => array(
					array(
						'admin_page' => array( 'form_settings' ),
						'tab'        => $this->get_slug(),
					),
				),
				'strings' => array(
					'formId'      => rgget( 'id' ),
					'nonce'       => wp_create_nonce( $this->get_slug() ),
					'runTask'     => esc_html__( 'Run Task Now', 'forgravity_entryautomation' ),
					'runningTask' => '<i class="fa fa-spinner fa-pulse fa-fw"></i>&nbsp;' . esc_html__( 'Running Task...', 'forgravity_entryautomation' ),
				),
			),
			array(
				'handle'  => 'forgravity_entryautomation_plugin_settings',
				'src'     => $this->get_base_url() . '/js/plugin_settings.js',
				'version' => $this->_version,
				'deps'    => array( 'jquery' ),
				'enqueue' => array(
					array(
						'admin_page' => array( 'plugin_settings' ),
						'tab'        => $this->get_slug(),
					),
				),
				'strings' => array(
					'nonce'      => wp_create_nonce( $this->get_slug() ),
					'processing' => array(
						'activate'   => '<i class="fa fa-spinner fa-pulse fa-fw"></i>&nbsp;' . esc_html__( 'Activating Extension...', 'forgravity_entryautomation' ),
						'deactivate' => '<i class="fa fa-spinner fa-pulse fa-fw"></i>&nbsp;' . esc_html__( 'Deactivating Extension...', 'forgravity_entryautomation' ),
						'install'    => '<i class="fa fa-spinner fa-pulse fa-fw"></i>&nbsp;' . esc_html__( 'Installing Extension...', 'forgravity_entryautomation' ),
					),
				),
			),
		);

		$scripts = array_merge( parent::scripts(), $scripts );

		return apply_filters( 'fg_entryautomation_scripts', $scripts );

	}

	/**
	 * Enqueue needed stylesheets.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @uses   GFAddOn::get_base_url()
	 * @uses   GFAddOn::get_slug()
	 * @uses   GFAddOn::get_version()
	 *
	 * @return array
	 */
	public function styles() {

		$styles = array(
			array(
				'handle'  => $this->get_slug() . '_feed_settings',
				'src'     => $this->get_base_url() . '/css/feed_settings.min.css',
				'version' => $this->get_version(),
				'enqueue' => array(
					array(
						'admin_page' => array( 'form_settings' ),
						'tab'        => $this->get_slug(),
					),
				),
			),
			array(
				'handle'  => 'forgravity_dashicons',
				'src'     => $this->get_base_url() . '/css/dashicons.css',
				'version' => $this->get_version(),
				'enqueue' => array(
					array( 'query' => 'page=roles&action=edit' ),
				),
			),
		);

		return array_merge( parent::styles(), $styles );

	}





	// # UNINSTALL -----------------------------------------------------------------------------------------------------

	/**
	 * Remove cron event.
	 *
	 * @since  1.0
	 * @access public
	 */
	public function uninstall() {

		global $wpdb;

		// Get export file options.
		$export_file_options = $wpdb->get_col( "SELECT option_name FROM $wpdb->options WHERE option_name LIKE '" . $this->_slug . "_file_%'" );

		// If options were found, remove them.
		if ( ! empty( $export_file_options ) ) {
			array_map( 'delete_option', $export_file_options );
		}

		// Get all feeds.
		$feeds = $this->get_feeds();

		// Loop through feeds.
		foreach ( $feeds as $feed ) {

			// Delete feed.
			$this->delete_feed( $feed['id'] );

		}

	}





	// # FEED SETTINGS -------------------------------------------------------------------------------------------------

	/**
	 * Renders the UI of all settings page based on the specified configuration array $sections.
	 * (Forked to display section tabs.)
	 *
	 * @since  1.0.7
	 * @access public
	 *
	 * @param  array $sections Configuration array containing all fields to be rendered grouped into sections.
	 */
	public function render_settings( $sections ) {

		// Add default save button if not defined.
		if ( ! $this->has_setting_field_type( 'save', $sections ) ) {
			$sections = $this->add_default_save_button( $sections );
		}

		// Initialize tabs.
		$tabs = array();

		// Get tabs.
		foreach ( $sections as $section ) {

			// If no tab is defined, skip it.
			if ( ! rgar( $section, 'tab' ) ) {
				continue;
			}

			// If section doesn't meet dependency, skip it.
			if ( ! $this->setting_dependency_met( rgar( $section, 'dependency' ) ) ) {
				continue;
			}

			// Add tab.
			$tabs[ rgar( $section, 'id' ) ] = array(
				'label' => rgars( $section, 'tab/label' ),
				'icon'  => rgars( $section, 'tab/icon' ),
			);

		}

		?>

        <form id="gform-settings" action="" enctype="multipart/form-data" method="post">
			<?php if ( ! empty( $tabs ) ) { ?>
                <input type="hidden" name="entryautomation_tab"
                       value="<?php echo sanitize_text_field( rgpost( 'entryautomation_tab' ) ); ?>"/>
                <div class="wp-filter entryautomation-tabs">
                    <ul class="filter-links">
						<?php
						$is_first = true;
						foreach ( $tabs as $id => $tab ) {

							$is_current = $this->is_current_section( $id, $is_first );

							echo '<li id="' . esc_attr( $id ) . '-nav">';
							echo '<a href="#' . esc_attr( $id ) . '"' . ( $is_current ? ' class="current"' : '' ) . '>';
							echo $tab['icon'] ? '<i class="fa ' . esc_attr( $tab['icon'] ) . '"></i> ' : null;
							echo esc_html( $tab['label'] );
							echo '</a>';
							echo '</li>';
							$is_first = false;

						}

						?>
                    </ul>
                </div>
				<?php
			}
			wp_nonce_field( $this->_slug . '_save_settings', '_' . $this->_slug . '_save_settings_nonce' );
			$this->settings( $sections );
			?>
        </form>

		<?php
	}

	/***
	 * Displays the UI for a field section
	 * (Forked to set current section class.)
	 *
	 * @since  1.3
	 * @access public
	 *
	 * @param array $section  The section to be displayed
	 * @param bool  $is_first true for the first section in the list, false for all others
	 *
	 * @uses   Entry_Automation::is_current_section()
	 * @uses   GFAddOn::get_slug()
	 * @uses   GFAddOn::setting_dependency_met()
	 * @uses   GFAddOn::single_setting_row()
	 */
	public function single_section( $section, $is_first = false ) {

		extract(
			wp_parse_args(
				$section, array(
					'title'         => false,
					'description'   => false,
					'id'            => '',
					'class'         => false,
					'style'         => '',
					'tooltip'       => false,
					'tooltip_class' => '',
				)
			)
		);

		$classes = array( 'gaddon-section' );

		if ( $is_first ) {
			$classes[] = 'gaddon-first-section';
		}

		if ( $class ) {
			$classes[] = $class;
		}

		if ( 'gf_edit_forms' === rgget( 'page' ) && $this->get_slug() === rgget( 'subview' ) && strpos( $class, 'entryautomation-feed-section' ) !== false ) {
			$classes[] = $this->is_current_section( $section['id'], $is_first, true );
		}

		?>

        <div
                id="<?php echo $id; ?>"
                class="<?php echo implode( ' ', $classes ); ?>"
                style="<?php echo $style; ?>"
        >

			<?php if ( $title ): ?>
                <h4 class="gaddon-section-title gf_settings_subgroup_title">
					<?php echo $title; ?>
					<?php if ( $tooltip ): ?>
						<?php gform_tooltip( $tooltip, $tooltip_class ); ?>
					<?php endif; ?>
                </h4>
			<?php endif; ?>

			<?php if ( $description ): ?>
                <div class="gaddon-section-description"><?php echo $description; ?></div>
			<?php endif; ?>

            <table class="form-table gforms_form_settings">

				<?php
				foreach ( $section['fields'] as $field ) {

					if ( ! $this->setting_dependency_met( rgar( $field, 'dependency' ) ) ) {
						continue;
					}

					if ( is_callable( array( $this, "single_setting_row_{$field['type']}" ) ) ) {
						call_user_func( array( $this, "single_setting_row_{$field['type']}" ), $field );
					} else {
						$this->single_setting_row( $field );
					}
				}
				?>

            </table>

        </div>

		<?php
	}

	/**
	 * Setup fields for feed settings.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @uses   Action::get_registered_actions()
	 * @uses   Action::settings_fields()
	 * @uses   Entry_Automation::get_actions_as_choices()
	 *
	 * @return array
	 */
	public function feed_settings_fields() {

		// Has the task already run?
		$has_task_run = $this->get_current_feed_id() && get_option( $this->get_slug() . '_last_run_time_' . $this->get_current_feed_id() );

		// Prepare Next Run Time field.
		$next_run_field = [
			'name'       => 'nextRun',
			'type'       => 'next_run_time',
			'dependency' => 'action',
		];

		// Set label, tooltip based on task previously running.
		if ( $has_task_run ) {
			$next_run_field['label']   = esc_html__( 'Next Run Time', 'forgravity_entryautomation' );
			$next_run_field['tooltip'] = sprintf(
				'<h6>%s</h6>%s',
				esc_html__( 'Next Run Time', 'forgravity_entryautomation' ),
				esc_html__( 'The next time this action will run.', 'forgravity_entryautomation' )
			);
		} else {
			$next_run_field['label']   = esc_html__( 'Start Running Task', 'forgravity_entryautomation' );
			$next_run_field['tooltip'] = sprintf(
				'<h6>%s</h6>%s',
				esc_html__( 'Start Running Task Time', 'forgravity_entryautomation' ),
				esc_html__( 'Select a time for when the task should be run for the first time.', 'forgravity_entryautomation' )
			);
		}

		$settings = array(
			array(
				'id'     => 'section-general',
				'tab'    => array(
					'label' => esc_html__( 'General', 'forgravity_entryautomation' ),
					'icon'  => 'fa-cog',
				),
				'class'  => 'entryautomation-feed-section',
				'fields' => array(
					array(
						'name'     => 'feedName',
						'label'    => esc_html__( 'Task Name', 'forgravity_entryautomation' ),
						'type'     => 'text',
						'class'    => 'medium',
						'required' => true,
					),
					array(
						'name'     => 'action',
						'label'    => esc_html__( 'Automation Action', 'forgravity_entryautomation' ),
						'type'     => 'radio',
						'required' => true,
						'onclick'  => "jQuery( this ).parents( 'form' ).submit()",
						'choices'  => $this->get_actions_as_choices(),
					),
					$next_run_field,
					array(
						'name'       => 'runTime',
						'label'      => esc_html__( 'Run Task Every', 'forgravity_entryautomation' ),
						'type'       => 'text_select',
						'dependency' => 'action',
						'required'   => true,
						'text'       => array(
							'name'        => 'runTime[number]',
							'class'       => 'small',
							'input_type'  => 'number',
							'after_input' => ' ',
							'min'         => 1,
						),
						'select'     => array(
							'name'          => 'runTime[unit]',
							'default_value' => 'hours',
							'choices'       => array(
								array(
									'value' => 'minutes',
									'label' => esc_html__( 'minutes', 'forgravity_entryautomation' ),
								),
								array(
									'value' => 'hours',
									'label' => esc_html__( 'hours', 'forgravity_entryautomation' ),
								),
								array(
									'value' => 'days',
									'label' => esc_html__( 'days', 'forgravity_entryautomation' ),
								),
								array(
									'value' => 'weeks',
									'label' => esc_html__( 'weeks', 'forgravity_entryautomation' ),
								),
								array(
									'value' => 'months',
									'label' => esc_html__( 'months', 'forgravity_entryautomation' ),
								),
							),
						),
						'tooltip'    => sprintf(
							'<h6>%s</h6>%s',
							esc_html__( 'Run Task Time', 'forgravity_entryautomation' ),
							esc_html__( 'Select how often to run the Entry Automation task. By default, Entry Automation runs tasks every 15 minutes.', 'forgravity_entryautomation' )
						),
					),
					array(
						'name'       => 'dateRange',
						'label'      => esc_html__( 'Select Date Range', 'forgravity_entryautomation' ),
						'type'       => 'date_range',
						'dependency' => 'action',
						'start_date' => true,
						'end_date'   => true,
						'tooltip'    => sprintf(
							'<h6>%s</h6>%s<br /><br />%s',
							esc_html__( 'Deletion Date Range', 'forgravity_entryautomation' ),
							esc_html__( 'Select a date range. Date range is relative to when the task is being run. Setting a range will limit the action to entries submitted during that date range.', 'forgravity_entryautomation' ),
							esc_html__( 'If no start date is set, all entries since the beginning of time will be included. If no end date is set, all entries until the time the action is run will be included.', 'forgravity_entryautomation' )
						),
					),
					array(
						'name'           => 'condition',
						'type'           => 'feed_condition',
						'dependency'     => 'action',
						'label'          => esc_html__( 'Conditional Logic', 'forgravity_entryautomation' ),
						'checkbox_label' => esc_html__( 'Enable', 'forgravity_entryautomation' ),
						'instructions'   => esc_html__( 'Include entries if', 'forgravity_entryautomation' ),
						'tooltip'        => sprintf(
							'<h6>%s</h6>%s',
							esc_html__( 'Conditional Logic', 'forgravity_entryautomation' ),
							esc_html__( 'Filter the entries by adding conditions.', 'forgravity_entryautomation' )
						),
					),
				),
			),
		);

		// Loop through registered actions.
		foreach ( Action::get_registered_actions() as $action ) {

			// Get settings fields for action.
			$action_settings = $action->get_settings_fields();

			// If no settings fields are defined, skip.
			if ( empty( $action_settings ) ) {
				continue;
			}

			// Get keys for action settings.
			$settings_keys = array_keys( $action_settings );

			// If the first settings key is numeric, add each section separately.
			if ( is_numeric( $settings_keys[0] ) ) {

				// Loop through settings sections and add.
				foreach ( $action_settings as $settings_section ) {
					$settings[] = $settings_section;
				}

			} else {

				$settings[] = $action_settings;

			}

		}

		// Add advanced settings tab.
		$settings[] = array(
			'id'         => 'section-advanced',
			'tab'        => array(
				'label' => esc_html__( 'Advanced Settings', 'forgravity_entryautomation' ),
				'icon'  => 'fa-cog',
			),
			'class'      => 'entryautomation-feed-section',
			'dependency' => 'action',
			'fields'     => array(
				array(
					'name'  => 'run_task',
					'label' => esc_html__( 'Run Task Now', 'forgravity_entryautomation' ),
					'type'  => 'run_task',
				),
			),
		);

		// Add save button.
		$settings[] = array(
			'dependency' => 'action',
			'fields'     => array(
				array(
					'type'     => 'save',
					'messages' => array(
						'error'   => esc_html__( 'There was an error while saving the Entry Automation task. Please review the errors below and try again.', 'forgravity_entryautomation' ),
						'success' => esc_html__( 'Entry Automation task updated.', 'forgravity_entryautomation' ),
					),
				),
			),
		);

		return $settings;

	}

	/**
	 * Determine if a section is the one currently displayed.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param string $section_id   Section ID.
	 * @param bool   $is_first     Is this the first section.
	 * @param bool   $return_class Return CSS class instead of boolean.
	 *
	 * @return string|bool
	 */
	public function is_current_section( $section_id, $is_first = false, $return_class = false ) {

		// Get current section.
		$current_section = rgpost( 'entryautomation_tab' );

		// Get first errored section.
		$section_error = $this->get_first_field_error();

		// Initialize current section flag.
		$is_current_section = false;

		// Determine if this is the current section.
		if ( ! empty( $section_error ) && $section_error['section'] == $section_id ) {
			$is_current_section = true;
		} else if ( empty( $section_error ) && $current_section && $section_id === $current_section ) {
			$is_current_section = true;
		} else if ( empty( $section_error ) && rgblank( $current_section ) && $is_first ) {
			$is_current_section = true;
		}

		if ( $return_class && $is_current_section ) {
			return 'gaddon-current-section';
		}

		return ! $return_class ? $is_current_section : '';

	}

	/**
	 * Get first settings field with an error and its section.
	 *
	 * @since  1.3
	 * @access public
	 *
	 * @uses   GFAddOn::get_field_errors()
	 * @uses   GFFeedAddOn::get_feed_settings_fields()
	 *
	 * @return array|string
	 */
	public function get_first_field_error() {

		// Get field errors.
		$errors = $this->get_field_errors();

		// If no field errors were found, return.
		if ( empty( $errors ) ) {
			return '';
		}

		// Get first invalid field.
		$field_name = array_keys( $errors )[0];

		// Get feed settings fields.
		$sections = $this->get_feed_settings_fields();

		// Loop through sections.
		foreach ( $sections as $section ) {

			// Loop through section fields.
			foreach ( $section['fields'] as $field ) {

				// If this is not the invalid field, skip it.
				if ( $field_name !== $field['name'] ) {
					continue;
				}

				return array(
					'section' => $section['id'],
					'field'   => $field,
				);

			}

		}

		return '';

	}

	/**
	 * Get registered actions as choices.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @uses   Action::get_registered_actions()
	 *
	 * @return array
	 */
	public function get_actions_as_choices() {

		// Initialize choices array.
		$choices = array();

		// Get registered actions.
		$actions = Action::get_registered_actions();

		// If no actions are registered, return.
		if ( empty( $actions ) ) {
			return $choices;
		}

		// Loop through actions.
		foreach ( $actions as $action ) {

			// Add as choice.
			$choices[] = array(
				'value' => $action->get_name(),
				'icon'  => $action->get_icon(),
				'label' => $action->get_label(),
			);

		}

		return $choices;

	}

	/**
	 * Define the title for the feed settings page.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @return string
	 */
	public function feed_settings_title() {

		return esc_html__( 'Entry Automation Task Settings', 'forgravity_entryautomation' );

	}

	/**
	 * Render a select settings field.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $field Field settings.
	 * @param bool  $echo  Display field. Defaults to true.
	 *
	 * @uses   GFAddOn::field_failed_validation()
	 * @uses   GFAddOn::get_error_icon()
	 * @uses   GFAddOn::get_field_attributes()
	 * @uses   GFAddOn::get_select_options()
	 * @uses   GFAddOn::get_setting()
	 *
	 * @return string
	 */
	public function settings_select( $field, $echo = true ) {

		// Get after select value.
		$after_select = rgar( $field, 'after_select' );

		// Remove after select property.
		unset( $field['after_select'] );

		// Get select field markup.
		$html = parent::settings_select( $field, false );

		// Add after select.
		if ( ! rgblank( $after_select ) ) {
			$html .= ' ' . $after_select;
		}

		if ( $echo ) {
			echo $html;
		}

		return $html;

	}

	/**
	 * Render a text and select settings field.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $field Field settings.
	 * @param bool  $echo  Display field. Defaults to true.
	 *
	 * @uses   GFAddOn::field_failed_validation()
	 * @uses   GFAddOn::get_error_icon()
	 * @uses   GFAddOn::settings_select()
	 * @uses   GFAddOn::settings_text()
	 *
	 * @return string
	 */
	public function settings_text_select( $field, $echo = true ) {

		// Initialize return HTML.
		$html = '';

		// Duplicate fields.
		$select_field = $text_field = $field;

		// Merge properties.
		$text_field   = array_merge( $text_field, $text_field['text'] );
		$select_field = array_merge( $select_field, $select_field['select'] );

		unset( $text_field['text'], $select_field['text'], $text_field['select'], $select_field['select'] );

		$html .= $this->settings_text( $text_field, false );
		$html .= $this->settings_select( $select_field, false );

		if ( $this->field_failed_validation( $field ) ) {
			$html .= $this->get_error_icon( $field );
		}

		if ( $echo ) {
			echo $html;
		}

		return $html;

	}

	/**
	 * Render a Next Run Time field.
	 *
	 * @since  1.2.5
	 * @access public
	 *
	 * @param array $field Field settings.
	 * @param bool  $echo  Display field. Defaults to true.
	 *
	 * @uses   Entry_Automation::get_first_run_time()
	 * @uses   Entry_Automation::get_next_run_time()
	 * @uses   Entry_Automation::settings_date_time()
	 * @uses   Entry_Automation::strtotime()
	 * @uses   GFAddOn::settings_hidden()
	 * @uses   GFFeedAddOn::get_current_feed_id()
	 *
	 * @return string
	 */
	public function settings_next_run_time( $field, $echo = true ) {

		// Initialize return HTML.
		$html = '';

		// Set default start time.
		$field['default_value'] = $this->strtotime( '+1 hour', 'Y-m-d\TH:i', true );
		$field['default_value'] = $this->strtotime( $field['default_value'], 'Y-m-d\TH:i:s', true );

		// If feed has not run, set default start time.
		if ( $this->get_current_feed_id() ) {

			// Get next scheduled run time.
			$next_run_time = $this->get_next_run_time( $this->get_current_feed_id(), 'Y-m-d\TH:i:s' );

			// If next run time found, set as default value.
			if ( $next_run_time ) {
				$field['default_value'] = $next_run_time;
			}

		}

		// Add field.
		$html = $this->settings_hidden( $field, false );

		// Add container for DateTimePicker.
		$html .= '<div id="nextRunContainer"></div>';

		if ( $echo ) {
			echo $html;
		}

		return $html;

	}

	/**
	 * Schedule the initial automation event upon saving feed.
	 *
	 * @since  1.3
	 * @access public
	 *
	 * @param int $feed_id The ID of the feed being saved.
	 * @param int $form_id The ID of the form the feed belongs to.
	 *
	 * @uses   Entry_Automation::strtotime()
	 * @uses   GFAddOn::get_posted_settings()
	 * @uses   GFAddOn::get_previous_settings()
	 * @uses   GFAddOn::is_save_postback()
	 *
	 * @return int
	 */
	public function maybe_save_feed_settings( $feed_id, $form_id ) {

		$feed_id = parent::maybe_save_feed_settings( $feed_id, $form_id );

		if ( ! $this->is_save_postback() || ! $feed_id || $feed_id === 0 ) {
			return $feed_id;
		}

		// Get previous and posted settings.
		$previous = $this->get_previous_settings();
		$settings = $this->get_posted_settings();

		// Get the new scheduled start time.
		$new_start = $this->strtotime( $settings['nextRun'], 'timestamp', true );

		// Remove change run time.
		unset( $settings['nextRun'] );
		$this->save_feed_settings( $feed_id, $form_id, $settings );

		// Initialize schedule flag.
		$schedule_task = false;

		// If this is a new feed, set schedule flag.
		if ( empty( $previous ) ) {

		    // Set schedule flag.
			$schedule_task = true;

		} else {

			// Prepare times.
			$previous_start = $this->get_next_run_time( $feed_id, 'timestamp' );

			// If times are not the same, set schedule flag.
			if ( $previous_start != $new_start ) {
				$schedule_task = true;
			}

		}

		// If we are not scheduling the task, bail.
		if ( ! $schedule_task ) {
			return $feed_id;
		}

		// Schedule next run.
		Scheduler::schedule_task( $feed_id, $form_id, $new_start );

		return $feed_id;

	}

	/**
	 * Render a date range field.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $field Field settings.
	 * @param bool  $echo  Display field. Defaults to true.
	 *
	 * @uses   GFAddOn::field_failed_validation()
	 * @uses   GFAddOn::get_error_icon()
	 * @uses   GFAddOn::settings_select()
	 * @uses   GFAddOn::settings_text()
	 *
	 * @return string
	 */
	public function settings_date_range( $field, $echo = true ) {

		// Initialize return HTML.
		$html = '';

		// Display start date.
		if ( rgar( $field, 'start_date' ) ) {

			// Prepare number field.
			$start_number = array( 'name' => $field['name'] . '[start]' );

			$html .= '<span class="range">';
			$html .= $this->settings_text( $start_number, false );
			$html .= '<strong>' . esc_html__( 'From', 'forgravity_entryautomation' ) . '</strong>';
			$html .= '<span class="time-preview"></span>';
			$html .= '</span>';

		}

		// Display end date.
		if ( rgar( $field, 'end_date' ) ) {

			// Prepare number field.
			$end_number = array( 'name' => $field['name'] . '[end]' );

			$html .= '<span class="range">';
			$html .= $this->settings_text( $end_number, false );
			$html .= '<strong>' . esc_html__( 'To', 'forgravity_entryautomation' ) . '</strong>';
			$html .= '<span class="time-preview"></span>';
			$html .= '</span>';

		}

		if ( $echo ) {
			echo $html;
		}

		return $html;

	}

	/**
	 * Render a run test now settings field.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $field Field settings.
	 * @param bool  $echo  Display field. Defaults to true.
	 *
	 * @uses   GFAddOn::field_failed_validation()
	 * @uses   GFAddOn::get_error_icon()
	 * @uses   GFAddOn::settings_select()
	 * @uses   GFAddOn::settings_text()
	 *
	 * @return string
	 */
	public function settings_run_task( $field, $echo = true ) {

		// Initialize return HTML.
		$html = '';

		// Add button.
		$html .= '<button id="fg-entryautomation-run-task" class="button">' . esc_html__( 'Run Task Now', 'forgravity_entryautomation' ) . '</button>';

		// Add response container.
		$html .= '<span id="fg-entryautomation-run-task-response"></span>';

		if ( $echo ) {
			echo $html;
		}

		return $html;

	}

	/**
	 * Validates a date range settings field.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $field    Field settings.
	 * @param array $settings Submitted settings values.
	 *
	 * @uses   Entry_Automation::strtotime()
	 * @uses   GFAddOn::set_field_error()
	 */
	public function validate_date_range_settings( $field, $settings ) {

		// Validate start date.
		if ( rgar( $field, 'start_date' ) ) {

			// Get start date field.
			$start_field         = $field;
			$start_field['name'] .= '[start]';

			// Get field value.
			$start_date = rgars( $settings, $field['name'] . '/start' );

			// If start date is defined, validate.
			if ( $start_date ) {

				// Convert start date to time.
				$start_date = $this->strtotime( $start_date );

				// If time did not convert correctly, set field error.
				if ( ! $start_date ) {
					$this->set_field_error( $start_field, esc_html__( 'You must use a valid date string.', 'forgravity_entryautomation' ) );
				}

			}

		}

		// Validate end date.
		if ( rgar( $field, 'end_date' ) ) {

			// Get end date field.
			$end_field         = $field;
			$end_field['name'] .= '[end]';

			// Get field value.
			$end_date = rgars( $settings, $field['name'] . '/end' );

			// If end date is defined, validate.
			if ( $end_date ) {

				// Convert end date to time.
				$end_date = $this->strtotime( $end_date );

				// If time did not convert correctly, set field error.
				if ( ! $end_date ) {
					$this->set_field_error( $end_field, esc_html__( 'You must use a valid date string.', 'forgravity_entryautomation' ) );
				}

			}

		}

	}

	/**
	 * Validates a text and select settings field.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $field    Field settings.
	 * @param array $settings Submitted settings values.
	 */
	public function validate_text_select_settings( $field, $settings ) {

		// Convert text field name.
		$text_field_name = str_replace( array( '[', ']' ), array( '/', '' ), $field['text']['name'] );

		// Get text field value.
		$text_field_value = rgars( $settings, $text_field_name );

		// If text field is empty and field is required, set error.
		if ( rgblank( $text_field_value ) && rgar( $field, 'required' ) ) {
			$this->set_field_error( $field, esc_html__( 'This field is required.', 'forgravity_entryautomation' ) );

			return;
		}

		// If text field is not numeric, set error.
		if ( ! rgblank( $text_field_value ) && ! ctype_digit( $text_field_value ) ) {
			$this->set_field_error( $field, esc_html__( 'You must use a whole number.', 'forgravity_entryautomation' ) );

			return;
		}

	}

	/**
	 * Get default feed name.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @uses   GFFeedAddOn::get_feeds_by_slug()
	 *
	 * @return string
	 */
	public function get_default_feed_name() {

		/**
		 * Query db to look for two formats that the feed name could have been auto-generated with
		 * format from migration to add-on framework: 'Feed ' . $counter
		 * new auto-generated format when adding new feed: $short_title . ' Feed ' . $counter
		 */

		// Set to zero unless a new number is found while checking existing feed names (will be incremented by 1 at the end).
		$counter_to_use = 0;

		// Get Add-On feeds.
		$feeds_to_filter = $this->get_feeds_by_slug( $this->_slug );

		// If feeds were found, loop through and increase counter.
		if ( $feeds_to_filter ) {

			// Loop through feeds and look for name pattern to find what to make default feed name.
			foreach ( $feeds_to_filter as $check ) {

				// Get feed name and trim.
				$name = rgars( $check, 'meta/feed_name' ) ? rgars( $check, 'meta/feed_name' ) : rgars( $check, 'meta/feedName' );
				$name = trim( $name );

				// Prepare feed name pattern.
				$pattern = '/(^Task|^' . $this->_short_title . ' Task)\s\d+/';

				// Search for feed name pattern.
				preg_match( $pattern, $name, $matches );

				// If matches were found, increase counter.
				if ( $matches ) {

					// Number should be characters at the end after a space
					$last_space = strrpos( $matches[0], ' ' );

					$digit = substr( $matches[0], $last_space );

					// Counter in existing feed name greater, use it instead.
					if ( $digit >= $counter_to_use ) {
						$counter_to_use = $digit;
					}

				}

			}

		}

		// Set default feed name
		$value = $this->_short_title . ' Task ' . ( $counter_to_use + 1 );

		return $value;

	}





	// # FEED LIST -----------------------------------------------------------------------------------------------------

	/**
	 * Define the title for the feed list page.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @uses   GFAddOn::get_short_title()
	 * @uses   GFFeedAddOn::can_create_feed()
	 *
	 * @return string
	 */
	public function feed_list_title() {

		// If feed creation is disabled, display title without Add New button.
		if ( ! $this->can_create_feed() ) {
			return sprintf(
				esc_html__( '%s Tasks', 'forgravity_entryautomation' ),
				$this->get_short_title()
			);
		}

		// Prepare add new feed URL.
		$url = add_query_arg( array( 'fid' => '0' ) );
		$url = esc_url( $url );

		// Display feed list title with Add New button.
		return sprintf(
			'%s <a class="add-new-h2" href="%s">%s</a>',
			sprintf(
				esc_html__( '%s Tasks', 'forgravity_entryautomation' ),
				$this->get_short_title()
			),
			$url,
			esc_html__( 'Add New', 'gravityforms' )
		);

	}

	/**
	 * Enable feed duplication.
	 *
	 * @since  1.1.5
	 * @access public
	 *
	 * @param string $id Feed ID requesting duplication.
	 *
	 * @return bool
	 */
	public function can_duplicate_feed( $id ) {

		return true;

	}

	/**
	 * Setup columns for feed list table.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @return array
	 */
	public function feed_list_columns() {

		return array(
			'feedName'    => esc_html__( 'Name', 'forgravity_entryautomation' ),
			'action'      => esc_html__( 'Action', 'forgravity_entryautomation' ),
			'runTime'     => esc_html__( 'Run Task Every', 'forgravity_entryautomation' ),
			'lastRunTime' => esc_html__( 'Last Run Time', 'forgravity_entryautomation' ),
		);

	}

	/**
	 * Add export file URL to feed list actions.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array  $links  Action links to be filtered.
	 * @param array  $feed   The feed item being filtered.
	 * @param string $column The column ID.
	 *
	 * @return array
	 */
	public function feed_list_actions( $links, $feed, $column ) {

		// Get registered actions.
		$actions = Action::get_registered_actions();

		// If no actions are registered, return.
		if ( empty( $actions ) ) {
			return $links;
		}

		// Copy meta out to task.
		$task = array( 'task_id' => $feed['id'], 'form_id' => $feed['form_id'] );
		$task = array_merge( $task, $feed['meta'] );

		// Loop through the actions.
		foreach ( $actions as $action ) {

			// Update links.
			$links = call_user_func( array( $action, 'feed_list_actions' ), $links, $task, $column );

		}

		return $links;

	}

	/**
	 * Prepare Automation Action column value for feed list table.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $feed Current feed.
	 *
	 * @uses   Action::get_action_by_name()
	 *
	 * @return string
	 */
	public function get_column_value_action( $feed ) {

		// Get action.
		$action = Action::get_action_by_name( rgars( $feed, 'meta/action' ) );

		// If action exists, return name.
		if ( is_object( $action ) ) {
			return $action->get_short_label();
		}

		return esc_html__( 'Unable to get action.', 'forgravity_entryautomation' );

	}

	/**
	 * Prepare Last Run Time column value for feed list table.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $feed Current feed.
	 *
	 * @uses   Entry_Automation::strtotime()
	 *
	 * @return string
	 */
	public function get_column_value_lastRunTime( $feed ) {

		// Get last run time.
		$last_run_time = get_option( fg_entryautomation()->get_slug() . '_last_run_time_' . $feed['id'] );

		return $last_run_time ? $this->strtotime( $last_run_time, 'Y-m-d g:i A', true, true ) : 'Never';

	}

	/**
	 * Prepare Run Action Every column value for feed list table.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $feed Current feed.
	 *
	 * @return string
	 */
	public function get_column_value_runTime( $feed ) {

		return sprintf(
			esc_html__( 'Every %d %s', 'forgravity_entryautomation' ),
			$feed['meta']['runTime']['number'],
			$feed['meta']['runTime']['unit']
		);

	}

	/**
	 * Delete feed.
	 *
	 * @since  1.2.5
	 * @access public
	 *
	 * @param int $id Feed ID.
	 *
	 * @uses   Action::get_action_by_name()
	 * @uses   GFAddOn::get_slug()
	 * @uses   GFFeedAddOn::get_feed()
	 */
	public function delete_feed( $id ) {

		// Get feed.
		$feed = $this->get_feed( $id );

		// Delete last run time.
		delete_option( $this->get_slug() . '_last_run_time_' . $id );

		// Delete scheduled event.
		Scheduler::unschedule_task( $id );

		// Get feed action.
		$action = Action::get_action_by_name( rgars( $feed, 'meta/action' ) );

		// Run delete action.
		if ( $action && method_exists( $action, 'delete_task' ) ) {
			call_user_func( array( $action, 'delete_task' ), $id );
		}

		parent::delete_feed( $id );

	}

	/**
	 * Duplicate feed.
	 *
	 * @since  1.3
	 * @access public
	 *
	 * @param int|array $id          The ID of the feed to be duplicated or the feed object when duplicating a form.
	 * @param mixed     $new_form_id False when using feed actions or the ID of the new form when duplicating a form.
	 *
	 * @return int
	 */
	public function duplicate_feed( $id, $new_form_id = false ) {

		// Get new feed ID.
		$feed_id = parent::duplicate_feed( $id, $new_form_id );

		// If a feed ID was not returned, exit.
		if ( ! $feed_id ) {
			return $feed_id;
		}

		// Get next scheduled run time of original feed.
		$next_run_time = Scheduler::get_task_event( $id );

		// Get new feed.
		$new_feed = $this->get_feed( $feed_id );

		// Deactivate new feed.
		$this->update_feed_active( $feed_id, false );

		// Schedule first run time for new task.
		Scheduler::schedule_task( $feed_id, $new_feed['form_id'], $next_run_time['timestamp'] );

		return $feed_id;

	}

	/**
	 * Save order of feeds.
	 * (Forked to regenerate events.)
	 *
	 * @since  1.3
	 * @access public
	 *
	 * @param array $feed_order Array of feed IDs in desired order.
	 *
	 * @uses   Scheduler::get_task_event()
	 * @uses   Scheduler::schedule_task()
	 */
	public function save_feed_order( $feed_order ) {

		// Save feed order.
		parent::save_feed_order( $feed_order );

		// Loop through feed IDs.
		foreach ( $feed_order as $feed_id ) {

			// Get current feed event.
			$event = Scheduler::get_task_event( $feed_id );

			// Reschedule feed.
			if ( $event ) {
				Scheduler::schedule_task( $feed_id, $event['args'][1], $event['timestamp'] );
			}

		}

	}





	// # ENTRY AUTOMATION ----------------------------------------------------------------------------------------------

	/**
	 * Run Entry Automation on forms that pass automation conditions.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array|int $task_ids IDs of the Task being run.
	 * @param int       $form_id  Form ID.
	 *
	 * @uses   Action::get_action_by_name()
	 * @uses   Action::maybe_run_task()
	 * @uses   GFAddOn::log_error()
	 * @uses   GFFeedAddOn::get_feed()
	 */
	public function run_automation( $task_ids = array(), $form_id = 0 ) {

		// Get current time.
		$task_run_time = fg_entryautomation()->strtotime( null, 'Y-m-d H:i' );
		$task_run_time = fg_entryautomation()->strtotime( $task_run_time, 'timestamp', true );

		// If only a singular task ID is provided, convert to array.
		if ( ! is_array( $task_ids ) ) {
			$task_ids = array( $task_ids );
		}

		// Loop through task IDs.
		foreach ( $task_ids as $task_id ) {

			// Get feed.
			$feed = $this->get_feed( $task_id );

			// If feed does not exist, exit.
			if ( ! $feed ) {
				$this->log_error( __METHOD__ . '(): Unable to run task #' . $task_id . ' because task could not be found.' );

				return;
			}

			// Copy meta out to task.
			$task = array(
				'task_id'   => intval( $feed['id'] ),
				'form_id'   => $feed['form_id'],
				'is_active' => $feed['is_active'],
			);
			$task = array_merge( $task, $feed['meta'] );

			// Get action.
			$action = Action::get_action_by_name( $task['action'] );

			// If action could not be found, skip it.
			if ( ! is_object( $action ) ) {
				$this->log_error( __METHOD__ . '(): Unable to run task #' . $task['task_id'] . ' on form #' . $task['form_id'] . ' because action could not be found.' );

				return;
			}

			call_user_func( array( $action, 'maybe_run_task' ), $task, $task_run_time );

		}

	}

	/**
	 * Run a single task from the task settings page.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @uses   Action::get_action_by_name()
	 * @uses   Action::maybe_run_task()
	 * @uses   GFAddOn::get_posted_settings()
	 * @uses   GFAddOn::get_slug()
	 * @uses   GFAddOn::remove_field()
	 * @uses   GFAddOn::get_posted_settings()
	 * @uses   GFFeedAddOn::validate_settings()
	 */
	public function ajax_run_task() {

		// Verify nonce.
		if ( ! wp_verify_nonce( rgpost( 'nonce' ), $this->get_slug() ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Invalid request.', 'forgravity_entryautomation' ) ) );
		}

		// Get settings.
		$settings = $this->get_posted_settings();

		// Get sections.
		$sections = $this->get_feed_settings_fields();
		$sections = $this->remove_field( 'runTime', $sections );

		// Check if settings are valid.
		$is_valid = $this->validate_settings( $sections, $settings );

		// If settings are invalid, return.
		if ( ! $is_valid ) {
			wp_send_json_error( array( 'message' => esc_html__( 'There is an error with your Entry Automation task. Please review your settings and try again.', 'forgravity_entryautomation' ) ) );
		}

		// Prepare task.
		$task            = $settings;
		$task['task_id'] = 0;
		$task['form_id'] = intval( rgpost( 'form_id' ) );

		// Get form.
		$form = GFAPI::get_form( $task['form_id'] );

		// Get action.
		$action = Action::get_action_by_name( $task['action'] );

		// If action could not be found, return.
		if ( ! is_object( $action ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Unable to run task; selected action could not be found.', 'forgravity_entryautomation' ) ) );
		}

		// Run task.
		$response = call_user_func( array( $action, 'run_task' ), $task, $form );

		// Prepare message.
		$message = esc_html__( 'Task has successfully run.', 'forgravity_entryautomation' );
		$message .= 'export' === $task['action'] && file_exists( $response ) ? sprintf( esc_html__( '%sDownload export file.%s', 'forgravity_entryautomation' ), ' <a href="' . str_replace( WP_CONTENT_DIR, WP_CONTENT_URL, $response ) . '" target="_blank">', '</a>' ) : '';

		// Send result.
		wp_send_json_success( array( 'message' => $message ) );

	}





	// # CONDITIONAL LOGIC ---------------------------------------------------------------------------------------------

	/**
	 * Display or return the markup for the feed_condition field type.
	 *
	 * @since 1.2 Added support for logic based on the entry meta.
	 *
	 * @param array $field The field properties.
	 * @param bool  $echo  Should the setting markup be echoed.
	 *
	 * @uses  Entry_Automation::get_feed_condition_entry_meta()
	 * @uses  Entry_Automation::get_feed_condition_entry_properties()
	 * @uses  GFFeedAddOn::settings_feed_condition()
	 *
	 * @return string
	 */
	public function settings_feed_condition( $field, $echo = true ) {

		$entry_meta  = array_merge( $this->get_feed_condition_entry_meta(), $this->get_feed_condition_entry_properties() );
		$find        = 'var feedCondition';
		$replacement = sprintf( 'var entry_meta = %s; %s', json_encode( $entry_meta ), $find );
		$html        = str_replace( $find, $replacement, parent::settings_feed_condition( $field, false ) );

		if ( $echo ) {
			echo $html;
		}

		return $html;

	}

	/**
	 * Get the entry meta for use with the feed_condition setting.
	 *
	 * @since 1.2
	 *
	 * @uses  GFFormsModel::get_entry_meta()
	 *
	 * @return array
	 */
	public function get_feed_condition_entry_meta() {

		$form_id = absint( rgget( 'id' ) );

		return GFFormsModel::get_entry_meta( $form_id );

	}

	/**
	 * Get the entry properties for use with the feed_condition setting.
	 *
	 * @since 1.2
	 *
	 * @return array
	 */
	public function get_feed_condition_entry_properties() {

		$user_choices = array();

		if ( $this->is_form_settings() ) {
			$args = apply_filters( 'gform_filters_get_users', array(
				'number' => 200,
				'fields' => array( 'ID', 'user_login' ),
			) );

			$users = get_users( $args );
			foreach ( $users as $user ) {
				$user_choices[] = array( 'text' => $user->user_login, 'value' => $user->ID );
			}
		}

		return array(
			'is_starred'     => array(
				'label'  => esc_html__( 'Starred', 'gravityforms' ),
				'filter' => array(
					'operators' => array( 'is', 'isnot' ),
					'choices'   => array(
						array(
							'text'  => 'Yes',
							'value' => '1',
						),
						array(
							'text'  => 'No',
							'value' => '0',
						),
					),
				),
			),
			'is_read'     => array(
				'label'  => esc_html__( 'Unread', 'gravityforms' ),
				'filter' => array(
					'operators' => array( 'is' ),
					'choices'   => array(
						array(
							'text'  => 'Yes',
							'value' => '0',
						),
						array(
							'text'  => 'No',
							'value' => '1',
						),
					),
				),
			),
			'ip'             => array(
				'label'  => esc_html__( 'User IP', 'forgravity_entryautomation' ),
				'filter' => array(
					'operators' => array( 'is', 'isnot', '>', '<', 'contains' ),
				),
			),
			'source_url'     => array(
				'label'  => esc_html__( 'Source URL', 'forgravity_entryautomation' ),
				'filter' => array(
					'operators' => array( 'is', 'isnot', '>', '<', 'contains' ),
				),
			),
			'payment_status' => array(
				'label'  => esc_html__( 'Payment Status', 'forgravity_entryautomation' ),
				'filter' => array(
					'operators' => array( 'is', 'isnot' ),
					'choices'   => array(
						array(
							'text'  => esc_html__( 'Paid', 'forgravity_entryautomation' ),
							'value' => 'Paid',
						),
						array(
							'text'  => esc_html__( 'Processing', 'forgravity_entryautomation' ),
							'value' => 'Processing',
						),
						array(
							'text'  => esc_html__( 'Failed', 'forgravity_entryautomation' ),
							'value' => 'Failed',
						),
						array(
							'text'  => esc_html__( 'Active', 'forgravity_entryautomation' ),
							'value' => 'Active',
						),
						array(
							'text'  => esc_html__( 'Cancelled', 'forgravity_entryautomation' ),
							'value' => 'Cancelled',
						),
						array(
							'text'  => esc_html__( 'Pending', 'forgravity_entryautomation' ),
							'value' => 'Pending',
						),
						array(
							'text'  => esc_html__( 'Refunded', 'forgravity_entryautomation' ),
							'value' => 'Refunded',
						),
						array(
							'text'  => esc_html__( 'Voided', 'forgravity_entryautomation' ),
							'value' => 'Voided',
						),
					),
				),
			),
			'payment_amount' => array(
				'label'  => esc_html__( 'Payment Amount', 'forgravity_entryautomation' ),
				'filter' => array(
					'operators' => array( 'is', 'isnot', '>', '<', 'contains' ),
				),
			),
			'transaction_id' => array(
				'label'  => esc_html__( 'Transaction ID', 'forgravity_entryautomation' ),
				'filter' => array(
					'operators' => array( 'is', 'isnot', '>', '<', 'contains' ),
				),
			),
			'created_by'     => array(
				'label'  => esc_html__( 'Created By', 'forgravity_entryautomation' ),
				'filter' => array(
					'operators' => array( 'is', 'isnot' ),
					'choices'   => $user_choices,
				),
			),
		);

	}

	/**
	 * Fork of GFCommon::evaluate_conditional_logic which supports evaluating logic based on entry properties.
	 *
	 * @since 1.2
	 *
	 * @param array $logic The conditional logic to be evaluated.
	 * @param array $form  The Form object.
	 * @param array $entry The Entry object.
	 *
	 * @uses  Entry_Automation::get_feed_condition_entry_meta()
	 * @uses  Entry_Automation::get_feed_condition_entry_properties()
	 * @uses  GFFormsModel::get_field()
	 * @uses  GFFormsModel::get_field_value()
	 * @uses  GFFormsModel::is_value_match()
	 *
	 * @return bool
	 */
	public function evaluate_conditional_logic( $logic, $form, $entry ) {

		if ( ! $logic || ! is_array( rgar( $logic, 'rules' ) ) ) {
			return true;
		}

		$entry_meta      = array_merge( $this->get_feed_condition_entry_meta(), $this->get_feed_condition_entry_properties() );
		$entry_meta_keys = array_keys( $entry_meta );
		$match_count     = 0;

		if ( is_array( $logic['rules'] ) ) {
			foreach ( $logic['rules'] as $rule ) {

				if ( in_array( $rule['fieldId'], $entry_meta_keys ) ) {
					$is_value_match = GFFormsModel::is_value_match( rgar( $entry, $rule['fieldId'] ), $rule['value'], $rule['operator'], null, $rule, $form );
				} else {
					$source_field   = GFFormsModel::get_field( $form, $rule['fieldId'] );
					$field_value    = empty( $entry ) ? GFFormsModel::get_field_value( $source_field, array() ) : GFFormsModel::get_lead_field_value( $entry, $source_field );
					$is_value_match = GFFormsModel::is_value_match( $field_value, $rule['value'], $rule['operator'], $source_field, $rule, $form );
				}

				if ( $is_value_match ) {
					$match_count++;
				}
			}
		}

		$do_action = ( $logic['logicType'] == 'all' && $match_count == sizeof( $logic['rules'] ) ) || ( $logic['logicType'] == 'any' && $match_count > 0 );

		return $do_action;

	}





	// # EXPORT ENTRIES ------------------------------------------------------------------------------------------------

	/**
	 * Serve export file.
	 *
	 * @since  1.1.5
	 * @access public
	 */
	public function maybe_serve_export_file() {

		// If export file action is not set, exit.
		if ( 'fg_entryautomation_export_file' !== rgget( 'action' ) ) {
			return;
		}

		// Verify nonce.
		check_admin_referer( 'fg_entryautomation_export_file' );

		// Get export file path.
		$export_file = get_option( $this->get_slug() . '_file_' . rgget( 'tid' ) );
		$export_file = str_replace( WP_CONTENT_URL, WP_CONTENT_DIR, $export_file );

		// If export file not found, exit.
		if ( ! $export_file || ! file_exists( $export_file ) ) {
			wp_die( esc_html__( 'Export file not found.', 'forgravity_entryautomation' ) );
		}

		// Set headers.
		header( 'X-Robots-Tag: noindex, nofollow', true );
		header( 'Content-Description: File Transfer' );
		header( 'Content-Transfer-Encoding: binary' );
		header( 'Cache-Control: public, must-revalidate, max-age=0' );
		header( 'Pragma: public' );
		header( 'Expires: Sat, 26 Jul 1997 05:00:00 GMT' );
		header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s' ) . ' GMT' );
		header( 'Content-Type: application/force-download' );
		header( 'Content-Type: application/octet-stream', false );
		header( 'Content-Type: application/download', false );
		header( 'Content-Type: ' . mime_content_type( $export_file ), false );
		if ( ! isset( $_SERVER['HTTP_ACCEPT_ENCODING'] ) || empty( $_SERVER['HTTP_ACCEPT_ENCODING'] ) ) {
			// Do not use length if server is using compression.
			header( 'Content-Length: ' . strlen( $export_file ) );
		}
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( basename( $export_file ) ) . '"' );

		// Serve export file.
		readfile( $export_file );

		die();

	}





	// # HELPER METHODS ------------------------------------------------------------------------------------------------

	/**
	 * Delete Entry Automation feeds upon form deletion.
	 *
	 * @since  1.3.4
	 * @access public
	 *
	 * @param int $form_id Form ID.
	 *
	 * @uses   Entry_Automation::delete_feeds()
	 * @uses   GFFeedAddOn::get_feeds()
	 */
	public function action_gform_after_delete_form( $form_id ) {

		// Get feeds for form.
		$feeds = $this->get_feeds( $form_id );

		// If no feeds were found, return.
		if ( ! $feeds ) {
			return;
		}

		// Loop through feeds.
		foreach ( $feeds as $feed_id ) {

			// Delete feed.
			$this->delete_feed( $feed_id );

		}

	}

	/**
	 * Generate a preview of the Entry Automation date range.
	 *
	 * @since  1.0.6
	 * @access public
	 *
	 * @uses   GFCommon::get_local_timestamp()
	 */
	public function ajax_time_preview() {

		// Verify nonce.
		wp_verify_nonce( 'nonce', $this->get_slug() );

		// Get time to preview.
		$preview_time = sanitize_text_field( rgars( $_POST, 'task/time' ) );

		// If preview time is already a time, return it.
		if ( preg_match( '/^([0-9]{4}-[0-9]{2}-[0-9]{2}( [0-9]{1,2}:[0-9]{2}((:[0-9]{2})|( AM| PM)))?)$/', $preview_time ) ) {
			wp_send_json_success( [ 'time' => $preview_time ] );
		}

		// If this is an invalid time, return error.
		if ( ! strtotime( $preview_time ) ) {
			wp_send_json_error( [ 'time' => esc_html__( 'Invalid Time', 'forgravity-entryautomation' ) ] );
		}

		// Get offset.
		$offset = get_option( 'gmt_offset', 0 );
		$offset = $offset >= 0 ? '+' . $offset : strval( $offset );

		// Prepare next run time from request.
		$next_run_time = rgars( $_POST, 'task/nextRun' );
		$next_run_time = $this->strtotime( $next_run_time, 'timestamp', true );

		try {

			// Prepare time zone object.
			$dtz = $offset ? new DateTimeZone( $offset ) : null;

			try {

				// Initialize new DateTime object.
				$dt = new DateTime( null, $dtz );
				$dt->setTimestamp( $next_run_time );
				$dt->modify( '-' . $preview_time );

				wp_send_json_success( [ 'time' => $dt->format( 'Y-m-d g:i A' ) ] );

			} catch ( Exception $e ) {

				// Log that DateTime could not be initialized.
				$this->log_error( __METHOD__ . '(): Unable to initialize DateTime object to prepare preview time, defaulting to strtotime; ' . $e->getMessage() );

				wp_send_json_success( [ 'time' => date( 'Y-m-d g:i A', strtotime( $preview_time, $next_run_time ) ) ] );

			}

		} catch ( Exception $e ) {

			// Log that DateTimeZone could not be initialized.
			$this->log_error( __METHOD__ . '(): Unable to initialize DateTimeZone object to prepare preview time, defaulting to strtotime; ' . $e->getMessage() );

			wp_send_json_success( [ 'time' => date( 'Y-m-d g:i A', strtotime( $preview_time, $next_run_time ) ) ] );

		}

	}

	/**
	 * Convert a string to time.
	 *
	 * @since  1.0.6
	 * @access public
	 *
	 * @param string $string        A date/time string.
	 * @param string $format        Format to convert to. Defaults to UNIX timestamp.
	 * @param bool   $bypass_minus  Bypass prepending minus to string.
	 * @param bool   $set_timestamp Set time via timestamp.
	 *
	 * @return int|string
	 */
	public function strtotime( $string = null, $format = 'timestamp', $bypass_minus = false, $set_timestamp = false ) {

		// Prepend minus if needed.
		if ( ! preg_match( '/^([0-9]{4}-[0-9]{2}-[0-9]{2}( [0-9]{1,2}:[0-9]{2}((:[0-9]{2})|( AM| PM)))?)$/', $string ) ) {
			$string = ctype_digit( substr( $string, 0, 1 ) ) && ! $bypass_minus ? '-' . $string : $string;
		}

		// If this is an invalid time, return error.
		if ( ! rgblank( $string ) && ! strtotime( $string ) && ! $set_timestamp ) {
			return false;
		}

		// If this would be a negative time, return error.
		if ( strtotime( $string ) < 0 && ! $set_timestamp ) {
			return false;
		}

		// Get offset.
		$offset = get_option( 'gmt_offset', 0 );
		$offset = $offset >= 0 ? '+' . $offset : strval( $offset );

		try {

			// Prepare time zone object.
			$dtz = $offset ? new DateTimeZone( $offset ) : null;

			try {

				// Initialize new DateTime object.
				$dt = new DateTime( ! $set_timestamp ? $string : null, $dtz );

				// Set time via timestamp.
				if ( $set_timestamp ) {
					$dt->setTimestamp( $string );
				}

				return 'timestamp' === $format ? $dt->getTimestamp() : $dt->format( $format );

			} catch ( \Exception $e ) {

				// Log that DateTime could not be initialized.
				$this->log_error( __METHOD__ . '(): Unable to initialize DateTime object, defaulting to strtotime; ' . $e->getMessage() );

				return 'timestamp' === $format ? strtotime( $string ) : date( $format, strtotime( $string ) );

			}

		} catch ( \Exception $e ) {

			// Log that DateTimeZone could not be initialized.
			$this->log_error( __METHOD__ . '(): Unable to initialize DateTimeZone object, defaulting to strtotime; ' . $e->getMessage() );

			return 'timestamp' === $format ? strtotime( $string ) : date( $format, strtotime( $string ) );

		}

	}

	/**
	 * Get Entry Automation search criteria for form.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $task Entry Automation Task meta.
	 * @param array $form The Form object.
	 *
	 * @uses   GFCommon::get_local_timestamp()
	 *
	 * @return array
	 */
	public function get_search_criteria( $task, $form ) {

		// Initialize search criteria.
		$search_criteria = array( 'status' => 'active' );

		// Set start time.
		if ( rgars( $task, 'dateRange/start' ) ) {

			// Add start time to search criteria.
			$search_criteria['start_date'] = $this->strtotime( $task['dateRange']['start'], 'Y-m-d H:i:s' );

		} else {

			// Add start time to search criteria.
			$search_criteria['start_date'] = date( 'Y-m-d H:i:s', 0 );

		}

		// Set end time.
		if ( rgars( $task, 'dateRange/end' ) ) {

			// Add end time to search criteria.
			$search_criteria['end_date'] = $this->strtotime( $task['dateRange']['end'], 'Y-m-d H:i:s' );

		} else {

			// Add end time to search criteria.
			$search_criteria['end_date'] = $this->strtotime( null, 'Y-m-d H:i:s' );

		}

		// Add conditional logic.
		if ( rgar( $task, 'feed_condition_conditional_logic' ) ) {

			// Get conditional logic.
			$conditional_logic = $task['feed_condition_conditional_logic_object']['conditionalLogic'];

			// Initialize field filters array.
			$field_filters = array( 'mode' => $conditional_logic['logicType'] );

			// Loop through rules.
			foreach ( $conditional_logic['rules'] as $rule ) {

				// Add rule.
				$field_filters[] = array(
					'key'      => $rule['fieldId'],
					'operator' => $rule['operator'],
					'value'    => $rule['value'],
				);

			}

			// Add to search criteria.
			$search_criteria['field_filters'] = $field_filters;

		}

		/**
		 * Modify the Entry Automation search criteria.
		 *
		 * @param array $search_criteria Search criteria.
		 * @param array $task            Entry Automation Task meta.
		 * @param array $form            The Form object.
		 */
		$search_criteria = gf_apply_filters( array(
			'fg_entryautomation_search_criteria',
			$task['task_id'],
		), $search_criteria, $task, $form );

		return $search_criteria;

	}

	/**
	 * Get next run time for Entry Automation task.
	 *
	 * @since  1.0.6
	 * @access public
	 *
	 * @param int    $task_id Entry Automation Task ID.
	 * @param string $format  Format to return next run time in.
	 *
	 * @return string|bool
	 */
	public function get_next_run_time( $task_id, $format = 'timestamp' ) {

		// Get next run time.
		$next_event = Scheduler::get_task_event( $task_id );

		// If task has not run yet, return.
		if ( ! $next_event ) {
			return false;
		}

		return $this->strtotime( $next_event['timestamp'], $format, true, true );

	}





	// # UPGRADE ROUTINES ----------------------------------------------------------------------------------------------

	/**
	 * Upgrade routines.
	 *
	 * @since  1.0.6
	 * @access public
	 *
	 * @param string $previous_version Previously installed version number.
	 *
	 * @uses   Entry_Automation::upgrade_export_fields()
	 * @uses   Entry_Automation::upgrade_first_run()
	 */
	public function upgrade( $previous_version ) {

		// Run first run time upgrade.
		if ( version_compare( $previous_version, '1.0.6', '<' ) ) {
			$this->upgrade_first_run();
		}

		// Run export fields upgrade.
		if ( version_compare( $previous_version, '1.2', '<' ) ) {
			$this->upgrade_export_fields();
		}

		// Run cron upgrade.
		if ( version_compare( $previous_version, '1.3', '<' ) ) {
			$this->upgrade_to_single_events();
		}

	}

	/**
	 * Upgrade 1.0 feeds to new format.
	 *
	 * @since  1.0.6
	 * @access public
	 *
	 * @uses   Entry_Automation::strtotime()
	 * @uses   GFFeedAddOn::get_feeds()
	 * @uses   GFFeedAddOn::update_feed_meta()
	 */
	public function upgrade_first_run() {

		// Get Entry Automation feeds.
		$feeds = $this->get_feeds();

		// Loop through feeds.
		foreach ( $feeds as $feed ) {

			// Convert first run time.
			if ( 'defined' === $feed['meta']['firstRun']['type'] ) {

				// Define firt run time.
				$feed['meta']['firstRun'] = array(
					'date'   => $this->strtotime( $feed['meta']['firstRun']['when'], 'Y-m-d', true ),
					'hour'   => $this->strtotime( $feed['meta']['firstRun']['when'], 'g', true ),
					'minute' => $this->strtotime( $feed['meta']['firstRun']['when'], 'i', true ),
					'period' => $this->strtotime( $feed['meta']['firstRun']['when'], 'A', true ),
				);

			} else {

				// Define firt run time.
				$feed['meta']['firstRun'] = array(
					'date'   => $this->strtotime( '+1 hour', 'Y-m-d', true ),
					'hour'   => $this->strtotime( '+1 hour', 'g', true ),
					'minute' => '00',
					'period' => $this->strtotime( '+1 hour', 'A', true ),
				);

			}

			// Convert date range.
			foreach ( array( 'start', 'end' ) as $range_type ) {

				// If range type is not an array, skip it.
				if ( ! is_array( $feed['meta']['dateRange'][ $range_type ] ) ) {
					continue;
				}

				// Prepare new date range.
				$feed['meta']['dateRange'][ $range_type ] = rgblank( $feed['meta']['dateRange'][ $range_type ]['number'] ) ? null : $feed['meta']['dateRange'][ $range_type ]['number'] . ' ' . $feed['meta']['dateRange'][ $range_type ]['unit'];

			}

			// Save feed.
			$this->update_feed_meta( $feed['id'], $feed['meta'] );

		}

	}

	/**
	 * Upgrade 1.0 feeds to new format.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @uses   GFAPI::get_form()
	 * @uses   GFCommon::get_label()
	 * @uses   GFFeedAddOn::get_feeds()
	 * @uses   GFFeedAddOn::update_feed_meta()
	 * @uses   GFFormsModel::get_field()
	 */
	public function upgrade_export_fields() {

		// Get Entry Automation feeds.
		$feeds = $this->get_feeds();

		// Loop through feeds.
		foreach ( $feeds as $feed ) {

			// If this is not an export feed, skip.
			if ( 'export' !== rgars( $feed, 'meta/action' ) ) {
				continue;
			}

			// Get form.
			$form = GFAPI::get_form( $feed['form_id'] );

			// Get export fields.
			$export_fields = rgars( $feed, 'meta/exportFields' );

			// Initialize array for new export fields.
			$new_export_fields = array();

			// Loop through export fields.
			foreach ( $export_fields as $field_id => $enabled ) {

				// Get field.
				$field = GFFormsModel::get_field( $form, $field_id );

				// Get field label.
				$field_label = is_float( $field_id ) ? GFCommon::get_label( $field, $field_id ) : GFCommon::get_label( $field );

				// Add new export field.
				$new_export_fields[] = array(
					'id'            => $field_id,
					'enabled'       => '1' == $enabled || true == $enabled ? true : false,
					'label'         => '',
					'default_label' => $field_label,
				);

			}

			// Add new export fields to meta.
			$feed['meta']['exportFields'] = $new_export_fields;

			// Save feed.
			$this->update_feed_meta( $feed['id'], $feed['meta'] );

		}

	}

	/**
	 * Upgrade 1.2 feeds to single scheduled events.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @uses   Entry_Automation::get_first_run_time()
	 * @uses   Entry_Automation::strtotime()
	 * @uses   GFAddOn::get_slug()
	 * @uses   GFFeedAddOn::get_feeds()
	 * @uses   GFFeedAddOn::update_feed_meta()
	 */
	public function upgrade_to_single_events() {

		// Get Entry Automation feeds.
		$feeds = $this->get_feeds();

		// Loop through feeds.
		foreach ( $feeds as $feed ) {

			// Get next run time.
			$run_time = get_option( '_transient_timeout_' . $this->get_slug() . '_timeout_' . $feed['id'], false );

			// If action was supposed to run already, get next run time.
			if ( ! $run_time ) {

				// Get first run time.
				$run_time = $this->get_first_run_time( $feed['meta'] );
				$run_time = $this->strtotime( $run_time, 'timestamp' );

			} else {

				// Get next run time without seconds.
				$run_time += 5;
				$run_time = $this->strtotime( $run_time, 'Y-m-d H:i', true, true );

				// Convert to timestamp.
				$run_time = $this->strtotime( $run_time, 'timestamp', true );

			}

			// Delete timeout transient.
			delete_transient( $this->get_slug() . '_timeout_' . $feed['id'] );

			// Schedule single event for feed.
			Scheduler::schedule_task( $feed['id'], $feed['form_id'], $run_time );

			// Update first run time.
            if ( is_array( $feed['meta']['firstRun'] ) ) {

                // Convert first run time to string.
                $feed['meta']['firstRun'] = sprintf( '%s %s:%s %s', $feed['meta']['firstRun']['date'], $feed['meta']['firstRun']['hour'], $feed['meta']['firstRun']['minute'], $feed['meta']['firstRun']['period'] );

                // Update feed.
                $this->update_feed_meta( $feed['id'], $feed['meta'] );

            }

		}

		// Remove old cron event.
		wp_clear_scheduled_hook( 'fg_entryautomation_maybe_automate' );

	}





	// # PLUGIN SETTINGS -----------------------------------------------------------------------------------------------

	/**
	 * Prepare plugin settings fields.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @uses   Entry_Automation::license_feedback()
	 * @uses   Entry_Automation::license_key_description()
	 *
	 * @return array
	 */
	public function plugin_settings_fields() {

		$settings = array(
			array(
				'fields' => array(
					array(
						'name'                => 'license_key',
						'label'               => esc_html__( 'License Key', 'forgravity_entryautomation' ),
						'type'                => 'text',
						'class'               => 'medium',
						'default_value'       => '',
						'input_type'          => $this->license_feedback() ? 'password' : 'text',
						'error_message'       => esc_html__( 'Invalid License', 'forgravity_entryautomation' ),
						'feedback_callback'   => array( $this, 'license_feedback' ),
						'validation_callback' => array( $this, 'license_validation' ),
						'description'         => $this->license_key_description(),
					),
					array(
						'name'          => 'background_updates',
						'label'         => esc_html__( 'Background Updates', 'forgravity_entryautomation' ),
						'type'          => 'radio',
						'horizontal'    => true,
						'default_value' => false,
						'tooltip'       => esc_html__( 'Set this to ON to allow Entry Automation to download and install bug fixes and security updates automatically in the background. Requires a valid license key.', 'forgravity_easypassthrough' ),
						'choices'       => array(
							array(
								'label' => esc_html__( 'On', 'forgravity_entryautomation' ),
								'value' => true,
							),
							array(
								'label' => esc_html__( 'Off', 'forgravity_entryautomation' ),
								'value' => false,
							),
						),
					),
					array(
						'name'  => 'extensions',
						'label' => esc_html__( 'Extensions', 'forgravity_entryautomation' ),
						'type'  => 'extensions',
					),
				),
			),
		);

		if ( defined( 'FG_ENTRYAUTOMATION_LICENSE_KEY' ) || ( is_multisite() && ! is_main_site() ) ) {
			$settings[0]['fields'][0]['disabled'] = true;
		}

		return apply_filters( 'fg_entryautomation_plugin_settings', $settings );

	}

	/**
	 * Get license validity for plugin settings field.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param string $value Plugin setting value.
	 * @param array  $field Plugin setting field.
	 *
	 * @uses   Entry_Automation::check_license()
	 *
	 * @return null|bool
	 */
	public function license_feedback( $value = '', $field = array() ) {

		// If no license key is provided, check the setting.
		if ( empty( $value ) ) {
			$value = $this->get_setting( 'license_key' );
		}

		// If no license key is provided, return.
		if ( empty( $value ) ) {
			return null;
		}

		// Get license data.
		$license_data = $this->check_license( $value );

		// If no license data was returned or license is invalid, return false.
		if ( empty( $license_data ) || 'invalid' === $license_data->license ) {
			return false;
		} else if ( 'valid' === $license_data->license ) {
			return true;
		}

		return false;

	}

	/**
	 * Activate license on plugin settings save.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array  $field         Plugin setting field.
	 * @param string $field_setting Plugin setting value.
	 *
	 *
	 * @uses   GFAddOn::get_plugin_setting()
	 * @uses   GFAddOn::log_debug()
	 * @uses   Entry_Automation::activate_license()
	 * @uses   Entry_Automation::process_license_request()
	 */
	public function license_validation( $field, $field_setting ) {

		// Get old license.
		$old_license = $this->get_plugin_setting( 'license_key' );

		// If an old license key exists and a new license is being saved, deactivate old license.
		if ( $old_license && $field_setting != $old_license ) {

			// Deactivate license.
			$deactivate_license = $this->process_license_request( 'deactivate_license', $old_license );

			// Log response.
			$this->log_debug( __METHOD__ . '(): Deactivate license: ' . print_r( $deactivate_license, true ) );

		}

		// If field setting is empty, return.
		if ( empty( $field_setting ) ) {
			return;
		}

		// Activate license.
		$this->activate_license( $field_setting );

	}

	/**
	 * Prepare description for License Key plugin settings field.
	 *
	 * @since  1.2.3
	 * @access public
	 *
	 * @uses   Entry_Automation::check_license()
	 * @uses   GFAddOn::get_setting()
	 *
	 * @return string
	 */
	public function license_key_description() {

		// Get license key.
		$license_key = defined( 'FG_ENTRYAUTOMATION_LICENSE_KEY' ) ? FG_ENTRYAUTOMATION_LICENSE_KEY : $this->get_setting( 'license_key' );

		// If no license key is entered, display warning.
		if ( rgblank( $license_key ) ) {
			return esc_html__( 'The license key is used for access to extensions, automatic upgrades and support.', 'forgravity_entryautomation' );
		}

		// Get license data.
		$license_data = $this->check_license( $license_key );

		// If no expiration date is provided, return.
        if ( ! rgobj( $license_data, 'expires' ) ) {
            return '';
        }

        if ( 'lifetime' === $license_data->expires ) {

			return sprintf(
				'<em>%s</em>',
                esc_html__( 'Your license is valid forever.', 'forgravity_entryautomation' )
			);

		} else {

			return sprintf(
				'<em>%s</em>',
				sprintf(
					esc_html__( 'Your license is valid through %s.', 'forgravity_entryautomation' ),
					date( 'Y-m-d', strtotime( $license_data->expires ) )
				)
			);

		}

	}





	// # EXTENSION MANAGEMENT ------------------------------------------------------------------------------------------

	/**
	 * Displays available Entry Automation extensions.
	 *
	 * @since  1.3
	 * @access public
	 *
	 * @param array $field Field settings.
	 * @param bool  $echo  Display field. Defaults to true.
	 *
	 * @uses   Entry_Automation::check_license()
	 * @uses   Entry_Automation::get_license_key()
	 * @uses   Extension::is_activated()
	 * @uses   Extension::is_installed()
	 *
	 * @return string
	 */
	public function settings_extensions( $field, $echo = true ) {

		// Get license key.
		$license_key = $this->get_license_key();

		// If no license key is available, return.
		if ( rgblank( $license_key ) ) {

			// Prepare return message.
			$html = esc_html__( 'To see available extensions, please enter a valid license key.', 'forgravity_entryautomation' );

			if ( $echo ) {
				echo $html;
			}

			return $html;

		}

		// Get license data.
		$license_data = $this->check_license( $license_key );

		// If license is not valid, return.
		if ( 'valid' !== rgobj( $license_data, 'license' ) ) {

			// Prepare return message.
			$html = esc_html__( 'To see available extensions, please enter a valid license key.', 'forgravity_entryautomation' );

			if ( $echo ) {
				echo $html;
			}

			return $html;

		}

		// If no extensions could be found, return.
		if ( ! rgobj( $license_data, 'extensions' ) ) {

			if ( $echo ) {
				echo esc_html__( 'No extensions could be found.', 'forgravity_entryautomation' );
			}

			return esc_html__( 'No extensions could be found.', 'forgravity_entryautomation' );

		}

		// Initialize table.
		$html = '<table>';

		// Loop through
		foreach ( $license_data->extensions as $extension ) {

			// Initialize button text and link variables.
			$button_text   = '';
			$button_link   = '#';
			$button_action = '';
			$button_plugin = $extension->plugin_file;

			// If extension is active, offer deactivate link.
			if ( Extension::is_activated( $extension->plugin_file ) ) {
				$button_text   = esc_html__( 'Deactivate Extension', 'forgravity_entryautomation' );
				$button_action = 'deactivate';
			} else if ( Extension::is_installed( $extension->plugin_file ) ) {
				$button_text   = esc_html__( 'Activate Extension', 'forgravity_entryautomation' );
				$button_action = 'activate';
			} else if ( ! Extension::is_installed( $extension->plugin_file ) ) {
				if ( $extension->has_access ) {
					$button_text   = esc_html__( 'Install Extension', 'forgravity_entryautomation' );
					$button_action = 'install';
				} else {
					$button_text   = esc_html__( 'Upgrade License', 'forgravity_entryautomation' );
					$button_action = 'upgrade';
					$button_link   = $extension->upgrade_url;
				}
			}

			// Add extension row.
			$html .= sprintf(
				'<tr>
                    <td>
                        <strong>%s</strong><br />
                        %s
                    </td>
                    <td style="padding-left: 20px;">
                        <a data-action="%s" data-plugin="%s" href="%s" class="button">
                            %s
                        </a>
                    </td>
                </tr>',
				$extension->name,
				$extension->description,
				$button_action,
				$button_plugin,
				$button_link,
				$button_text
			);

		}

		// Close table.
		$html .= '</table>';

		if ( $echo ) {
			echo $html;
		}

		return $html;

	}

	/**
	 * Process extension management actions.
	 *
	 * @since  1.3
	 * @access public
	 *
	 * @uses   Extension::install_extension()
	 */
	public function ajax_handle_extension_action() {

		// Verify nonce.
		if ( ! wp_verify_nonce( rgpost( 'nonce' ), $this->get_slug() ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Invalid request.', 'forgravity_entryautomation' ) ) );
		}

		// Get plugin and action.
		$plugin = sanitize_text_field( rgars( $_POST, 'extension/plugin' ) );
		$action = sanitize_text_field( rgars( $_POST, 'extension/action' ) );

		switch ( $action ) {

			case 'activate':

				// Activate plugin.
				$activated = activate_plugin( $plugin );

				// Respond based on activation.
				if ( is_wp_error( $activated ) ) {
					wp_send_json_error( array(
						'error'     => sprintf(
							'%s: %s',
							esc_html__( 'Unable to activate extension', 'forgravity_entryautomation' ),
							$activated->get_error_message()
						),
						'newAction' => 'activate',
						'newText'   => esc_html__( 'Activate Extension', 'forgravity_entryautomation' ),
					) );
				} else {
					wp_send_json_success( array(
						'newAction' => 'deactivate',
						'newText'   => esc_html__( 'Deactivate Extension', 'forgravity_entryautomation' ),
					) );
				}

				break;

			case 'deactivate':

				// Deactivate plugin.
				deactivate_plugins( $plugin );

				wp_send_json_success( array(
					'newAction' => 'activate',
					'newText'   => esc_html__( 'Activate Extension', 'forgravity_entryautomation' ),
				) );

				break;

			case 'install':

				// Install plugin.
				$installed = Extension::install_extension( $plugin );

				// Response based on installation.
				if ( is_wp_error( $installed ) ) {
					wp_send_json_error( array(
						'error'     => sprintf(
							'%s: %s',
							esc_html__( 'Unable to install extension', 'forgravity_entryautomation' ),
							$installed->get_error_message()
						),
						'newAction' => 'install',
						'newText'   => esc_html__( 'Install Extension', 'forgravity_entryautomation' ),
					) );
				} else {
					wp_send_json_success( array(
						'newAction' => 'activate',
						'newText'   => esc_html__( 'Activate Extension', 'forgravity_entryautomation' ),
					) );
				}

				break;

		}

	}





	// # LICENSE METHODS -----------------------------------------------------------------------------------------------

	/**
	 * Activate a license key.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param string $license_key The license key.
	 *
	 * @uses   Entry_Automation::process_license_request()
	 *
	 * @return array
	 */
	public function activate_license( $license_key ) {

		// Activate license.
		$license = $this->process_license_request( 'activate_license', $license_key );

		// Clear update plugins transient.
		set_site_transient( 'update_plugins', null );

		// Delete plugin version info cache.
		$cache_key = md5( 'edd_plugin_' . sanitize_key( $this->_path ) . '_version_info' );
		delete_transient( $cache_key );

		return json_decode( wp_remote_retrieve_body( $license ) );

	}

	/**
	 * Check the status of a license key.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param string $license_key The license key.
	 *
	 * @uses   GFAddOn::get_plugin_setting()
	 * @uses   Entry_Automation::process_license_request()
	 *
	 * @return object
	 */
	public function check_license( $license_key = '' ) {

		// If license key is empty, get the plugin setting.
		if ( empty( $license_key ) ) {
			$license_key = $this->get_plugin_setting( 'license_key' );
		}

		// Perform a license check request.
		$license = $this->process_license_request( 'check_license', $license_key );

		return json_decode( wp_remote_retrieve_body( $license ) );

	}

	/**
	 * Get license key.
	 *
	 * @since  1.3
	 * @access public
	 *
	 * @uses   GFAddOn::get_plugin_setting()
	 *
	 * @return string
	 */
	public function get_license_key() {

		return defined( 'FG_ENTRYAUTOMATION_LICENSE_KEY' ) ? FG_ENTRYAUTOMATION_LICENSE_KEY : $this->get_plugin_setting( 'license_key' );

	}

	/**
	 * Process a request to the ForGravity store.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param string $action  The action to process.
	 * @param string $license The license key.
	 * @param int    $item_id The EDD item ID.
	 *
	 * @return array|\WP_Error
	 */
	public function process_license_request( $action, $license, $item_id = FG_ENTRYAUTOMATION_EDD_ITEM_ID ) {

		// Prepare the request arguments.
		$args = array(
			'method'    => 'POST',
			'timeout'   => 10,
			'sslverify' => false,
			'body'      => array(
				'edd_action' => $action,
				'license'    => trim( $license ),
				'item_id'    => urlencode( $item_id ),
				'url'        => home_url(),
			),
		);

		return wp_remote_request( FG_EDD_STORE_URL, $args );

	}





	// # BACKGROUND UPDATES --------------------------------------------------------------------------------------------

	/**
	 * Display activate license message on Plugins list page.
	 *
	 * @since 1.1.4
	 * @acces public
	 *
	 * @uses  GFAddOn::display_plugin_message()
	 * @uses  GFAddOn::get_plugin_setting()
	 * @uses  Entry_Automation::check_license()
	 */
	public function plugin_row() {

		parent::plugin_row();

		// Get license key.
		$license_key = $this->get_plugin_setting( 'license_key' );

		// If no license key is installed, display message.
		if ( rgblank( $license_key ) ) {

			// Prepare message.
			$message = sprintf(
				esc_html__( '%sRegister your copy%s of Entry Automation to receive access to automatic upgrades and support. Need a license key? %sPurchase one now.%s', 'forgravity_entryautomation' ),
				'<a href="' . admin_url( 'admin.php?page=gf_settings&subview=' . $this->_slug ) . '">',
				'</a>',
				'<a href="' . esc_url( $this->_url ) . '" target="_blank">',
				'</a>'
			);

			// Add activate license message.
			self::display_plugin_message( $message );

			return;

		}

		// Get license data.
		$license_data = $this->check_license( $license_key );

		// If license key is invalid, display message.
		if ( empty( $license_data ) || 'valid' !== $license_data->license ) {

			// Prepare message.
			$message = sprintf(
				esc_html__( 'Your license is invalid or expired. %sEnter a valid license key%s or %spurchase a new one.%s', 'forgravity_entryautomation' ),
				'<a href="' . admin_url( 'admin.php?page=gf_settings&subview=' . $this->_slug ) . '">',
				'</a>',
				'<a href="' . esc_url( $this->_url ) . '" target="_blank">',
				'</a>'
			);

			// Add invalid license message.
			self::display_plugin_message( $message );

			return;

		}

	}

	/**
	 * Determines if automatic updating should be processed.
	 *
	 * @since  Unknown
	 * @access 1.0
	 *
	 * @param bool   $update Whether or not to update.
	 * @param object $item   The update offer object.
	 *
	 * @uses   GFAddOn::log_debug()
	 * @uses   Entry_Automation::is_auto_update_disabled()
	 *
	 * @return bool
	 */
	public function maybe_auto_update( $update, $item ) {

		// If this is not the Entry Automation Add-On, exit.
		if ( ! isset( $item->slug ) || 'entryautomation' !== $item->slug ) {
			return $update;
		}

		// Log that we are starting auto update.
		$this->log_debug( __METHOD__ . '(): Starting auto-update for Entry Automation.' );

		// Check if automatic updates are disabled.
		$auto_update_disabled = $this->is_auto_update_disabled();

		// Log automatic update disabled state.
		$this->log_debug( __METHOD__ . '(): Automatic update disabled: ' . var_export( $auto_update_disabled, true ) );

		// If automatic updates are disabled or if the installed version is the newest version or earlier, exit.
		if ( $auto_update_disabled || version_compare( $this->_version, $item->new_version, '=>' ) ) {
			$this->log_debug( __METHOD__ . '(): Aborting update.' );

			return false;
		}

		$current_major = implode( '.', array_slice( preg_split( '/[.-]/', $this->_version ), 0, 1 ) );
		$new_major     = implode( '.', array_slice( preg_split( '/[.-]/', $item->new_version ), 0, 1 ) );

		$current_branch = implode( '.', array_slice( preg_split( '/[.-]/', $this->_version ), 0, 2 ) );
		$new_branch     = implode( '.', array_slice( preg_split( '/[.-]/', $item->new_version ), 0, 2 ) );

		if ( $current_major == $new_major && $current_branch == $new_branch ) {
			$this->log_debug( __METHOD__ . '(): OK to update.' );

			return true;
		}

		$this->log_debug( __METHOD__ . '(): Skipping - not current branch.' );

		return $update;

	}

	/**
	 * Determine if automatic updates are disabled.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @uses   GFAddOn::get_plugin_setting()
	 * @uses   GFAddOn::log_debug()
	 *
	 * @return bool
	 */
	public function is_auto_update_disabled() {

		// WordPress background updates are disabled if you do not want file changes.
		if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
			return true;
		}

		// Do not run auto update during install.
		if ( defined( 'WP_INSTALLING' ) ) {
			return true;
		}

		// Get automatic updater disabled state.
		$wp_updates_disabled = defined( 'AUTOMATIC_UPDATER_DISABLED' ) && AUTOMATIC_UPDATER_DISABLED;
		$wp_updates_disabled = apply_filters( 'automatic_updater_disabled', $wp_updates_disabled );

		// If WordPress automatic updates are disabled, return.
		if ( $wp_updates_disabled ) {
			$this->log_debug( __METHOD__ . '(): WordPress background updates are disabled.' );

			return true;
		}

		// Get background updates plugin setting.
		$enabled = $this->get_plugin_setting( 'background_updates' );

		// Log setting.
		$this->log_debug( __METHOD__ . '(): Background updates setting: ' . var_export( $enabled, true ) );

		return $enabled;

	}





	// # MEMBERS INTEGRATION -------------------------------------------------------------------------------------------

	/**
	 * Register the ForGravity capabilities group with the Members plugin.
	 *
	 * @since  1.2.6
	 * @access public
	 */
	public function members_register_cap_group() {

		members_register_cap_group(
			'forgravity',
			array(
				'label' => esc_html( 'ForGravity' ),
				'icon'  => 'dashicons-forgravity',
				'caps'  => array(),
			)
		);

	}

	/**
	 * Register the capabilities and their human readable labels wit the Members plugin.
	 *
	 * @since  1.2.6
	 * @access public
	 */
	public function members_register_caps() {

		// Define capabilities for Easy Passthrough.
		$caps = array(
			'forgravity_entryautomation'           => esc_html__( 'Manage Settings', 'forgravity_entryautomation' ),
			'forgravity_entryautomation_uninstall' => esc_html__( 'Uninstall', 'forgravity_entryautomation' ),
		);

		// Register capabilities.
		foreach ( $caps as $cap => $label ) {
			members_register_cap(
				$cap,
				array(
					'label' => sprintf( '%s: %s', $this->get_short_title(), $label ),
					'group' => 'forgravity',
				)
			);
		}

	}

}
