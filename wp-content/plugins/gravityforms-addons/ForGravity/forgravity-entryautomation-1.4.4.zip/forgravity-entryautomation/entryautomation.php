<?php
/**
 * Plugin Name: Entry Automation for Gravity Forms
 * Plugin URI: http://forgravity.com/plugins/entry-automation/
 * Description: Automate entry clean up actions
 * Version: 1.4.4
 * Author: ForGravity
 * Author URI: http://forgravity.com
 * Text Domain: forgravity_entryautomation
 * Domain Path: /languages
 **/

if ( ! defined( 'FG_EDD_STORE_URL' ) ) {
	define( 'FG_EDD_STORE_URL', 'https://forgravity.com' );
}

define( 'FG_ENTRYAUTOMATION_VERSION', '1.4.4' );
define( 'FG_ENTRYAUTOMATION_EVENT', 'fg_entryautomation_automate' );
define( 'FG_ENTRYAUTOMATION_EDD_ITEM_ID', 112 );

// Initialize plugin updater.
add_action( 'init', array( 'EntryAutomation_Bootstrap', 'updater' ), 0 );

// If Gravity Forms is loaded, bootstrap the Entry Automation Add-On.
add_action( 'gform_loaded', array( 'EntryAutomation_Bootstrap', 'load' ), 5 );

/**
 * Class EntryAutomation_Bootstrap
 *
 * Handles the loading of the Entry Automation Add-On and registers with the Add-On framework.
 */
class EntryAutomation_Bootstrap {

	/**
	 * If the Feed Add-On Framework exists, Entry Automation Add-On is loaded.
	 *
	 * @access public
	 * @static
	 */
	public static function load() {

		if ( ! method_exists( 'GFForms', 'include_feed_addon_framework' ) ) {
			return;
		}

		if ( ! class_exists( '\ForGravity\EntryAutomation\EDD_SL_Plugin_Updater' ) ) {
			require_once( 'includes/EDD_SL_Plugin_Updater.php' );
		}

		self::include_actions();

		require_once( 'class-entryautomation.php' );
		require_once( 'includes/class-extension.php' );
		require_once( 'includes/class-scheduler.php' );

		GFAddOn::register( '\ForGravity\Entry_Automation' );

	}

	/**
	 * Load Action Framework and bundled actions.
	 *
	 * @access public
	 * @static
	 */
	public static function include_actions() {

		require_once dirname( __FILE__ ) . '/includes/class-action.php';

		foreach ( glob( dirname( __FILE__ ) . '/includes/actions/class-*.php' ) as $action_file ) {
			require_once( $action_file );
		}

	}

	/**
	 * Initialize plugin updater.
	 *
	 * @access public
	 * @static
	 */
	public static function updater() {

		// Get Entry Automation instance.
		$entry_automation = fg_entryautomation();

		// If Entry Automation could not be retrieved, exit.
		if ( ! $entry_automation ) {
			return;
		}

		// Get license key.
		$license_key = fg_entryautomation()->get_license_key();

		new ForGravity\EntryAutomation\EDD_SL_Plugin_Updater(
			FG_EDD_STORE_URL,
			__FILE__,
			array(
				'version' => FG_ENTRYAUTOMATION_VERSION,
				'license' => $license_key,
				'item_id' => FG_ENTRYAUTOMATION_EDD_ITEM_ID,
				'author'  => 'ForGravity',
			)
		);

	}
}

/**
 * Returns an instance of the Entry_Automation class
 *
 * @see    Entry_Automation::get_instance()
 *
 * @return ForGravity\Entry_Automation
 */
function fg_entryautomation() {
	if ( class_exists( '\ForGravity\Entry_Automation' ) ) {
		return ForGravity\Entry_Automation::get_instance();
	}
}
