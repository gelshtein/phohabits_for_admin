<?php //silence is golden
