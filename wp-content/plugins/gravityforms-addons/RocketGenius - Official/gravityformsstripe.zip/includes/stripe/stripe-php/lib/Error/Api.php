<?php

namespace Stripe\Error;

defined( 'ABSPATH' ) || die();

class Api extends Base
{
}
