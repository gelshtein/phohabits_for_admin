<?php

namespace Stripe\Error\OAuth;

defined( 'ABSPATH' ) || die();

/**
 * InvalidScope is raised when an invalid scope parameter is provided.
 */
class InvalidScope extends OAuthBase
{
}
