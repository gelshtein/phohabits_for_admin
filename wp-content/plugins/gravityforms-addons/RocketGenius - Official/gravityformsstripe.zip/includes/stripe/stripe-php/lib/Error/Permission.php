<?php

namespace Stripe\Error;

defined( 'ABSPATH' ) || die();

class Permission extends Base
{
}
