<?php
class GFRcwdCommon{
	
	const GFORMS_RCWDUPLOAD_ITEM_ID = '5308480';

	static function randomcode($args = array()){
		
		$length		= ( isset($args['length']) and (int)$args['length'] > 0 ) ? (int)$args['length'] : 8;
		$uppercase	= isset($args['uppercase']) ? (bool)$args['uppercase'] 	: true;
		$lowercase	= isset($args['lowercase']) ? (bool)$args['lowercase'] 	: true;
		$number		= isset($args['number']) 	? (bool)$args['number'] 	: true;
		$newpass 	= '';
		
		if( !$uppercase and !$lowercase and !$number )
			$uppercase = $lowercase = $number = true;
			
		for ( $k = 1; $k <= $length; $k++ ){

			if ($k % 3){
				
				if( $uppercase === true or $lowercase === true ){
					
					if( $uppercase === true and $lowercase === true ){
						
						if ( rand( 0, 200 ) <= 100 )
							$newpass .= chr(rand ( 65, 90 ));	// Nella tabella ASCII da 65 a 90 ci sono le lettere dell'alfabeto Maiuscole
						else
							$newpass .= chr(rand( 97, 122 ));	// Nella tabella ASCII da 97 a 122 ci sono le lettere dell'alfabeto Minuscole
							
					}elseif($uppercase === true)
						$newpass .= chr(rand (65,90));
					else
						$newpass .= chr(rand(97,122));

				}else
					if($number === true) $newpass .= rand(0,9);

			}else
				if($number === true)
					$newpass .= rand(0,9);

		}
		
		return $newpass;
		
	}
	
	static function format_value($args = array()){
		
		$nv						= get_site_option('gforms_rcwdupload_nv');
		$mode 					= isset($args['mode']) 		? $args['mode'] 			: '';
		$value 					= isset($args['value']) 	? $args['value'] 			: '';
		$lead 					= isset($args['lead']) 		? $args['lead'] 			: 0;
		$field 					= isset($args['field']) 	? $args['field'] 			: '';
		$form					= isset($args['form']) 		? $args['form'] 			: '';
		$form_id				= isset($args['form_id']) 	? $args['form_id'] 			: '';
		$input_id				= isset($args['input_id']) 	? $args['input_id'] 		: '';
		$simpleurl				= isset($args['simpleurl']) ? (bool)$args['simpleurl'] 	: empty($nv) ? true : false;
		$userid					= isset($args['userid']) 	? (int)$args['userid'] 		: 0;
		$export					= isset($args['export']) 	? (bool)$args['export'] 	: false;
		$permalink_structure	= get_option('permalink_structure');
		
		if($export)
			$mode = 'url';
			
		if(empty($permalink_structure))
			$simpleurl = true;

		if(is_numeric($lead))
			$lead = array('id' => $lead);
			
		if( $field['type'] == 'rcwdupload' and $value != '' ){
		
			$upload_info 	= self::upload_info( $form_id, $field['id'], $lead['id'], $userid );
			$value_or		= $value;
			$value_ 		= maybe_unserialize($value);
			
			if( is_array($value_) and count($value_) > 0){
				
				$value = '';

				if($export){
					
					$separator		= ',';
					$export_mode	= apply_filters( 'gforms_rcwdupload_export_mode_'.$form_id.'_'.$field['id'], apply_filters( 'gforms_rcwdupload_export_mode_'.$form_id, apply_filters( 'gforms_rcwdupload_export_mode', 'real', $form_id, $field['id'], $lead['id'] ), $field['id'], $lead['id'] ), $lead['id'] );
					foreach( $value_ as $key => $v ){
					
						$vfile = $v['file'];
						
						switch($export_mode){
							
							case 'url':
							
								$value[$key] = $upload_info['url'].$v['file'];
							
								break;
															
							default:
								$value = json_encode($value_);
								
						}
					
					}

					if( in_array( $export_mode, array('url') ) and !empty($value))
						$value = implode( $separator, $value );
											
				}else{
									
					if($mode == 'only_name')
						$only_name = true;
					else
						$only_name = (bool)apply_filters( 'gforms_rcwdupload_filename_as_title_'.$form_id.'_'.$field['id'], (bool)apply_filters( 'gforms_rcwdupload_filename_as_title'.$form_id, (bool)apply_filters( 'gforms_rcwdupload_filename_as_title', false, $form_id, $field['id'], $lead['id'] ), $field['id'], $lead['id'] ), $lead['id'] );
	
					if($simpleurl)
						$mask_url = false;
					else
						$mask_url = (bool)apply_filters( 'gforms_rcwdupload_entry_mask_url_'.$form_id.'_'.$field['id'], (bool)apply_filters( 'gforms_rcwdupload_entry_mask_url_'.$form_id, (bool)apply_filters( 'gforms_rcwdupload_entry_mask_url', true, $form_id, $field['id'], $lead['id'] ), $field['id'], $lead['id'] ), $lead['id'] );
					
					foreach( $value_ as $key => $v ){
						
						if(isset($v['file'])){
							
							$vfile = apply_filters( 'gforms_rcwdupload_override_filename', $v['file'], $form_id, $field['id'], $lead['id'] );
							
							if($mask_url)
								$url = $upload_info['purl']['inline'];
							else
								$url = $upload_info['url'];

							$title		= ( isset($v['title']) and $v['title'] ) ? $v['title'] : '';
							$title_mode = (int)apply_filters( 'gforms_rcwdupload_title_mode', 0, $vfile, $title, $form_id, $field['id'], $lead['id'] );
																							
							if(!$only_name){								
								
								switch($title_mode){
									
									case '1':

										if(!empty($title))
											$title .= ' - ';
											
										$value[$key] = $title.'<a href="'.$url.$vfile.'" target="_blank">'.$vfile.'</a>';
																	
										break;
										
									default:
									
										$value[$key] = '<a href="'.$url.$vfile.'" target="_blank">'.( !empty($title) ? $title : $vfile ).'</a>';										
									
								}
								
							}else{

								switch($title_mode){
									
									case '1':

										if(!empty($title))
											$title .= ' - ';
											
										$value[$key] = $title.$vfile;
																	
										break;
										
									default:
									
										$value[$key] = $vfile;									
									
								}
																
							}
		
							if($mode == 'url')
								$value[$key] = $url.$vfile;
							
						}
						
					}

					if($mode == 'only_name')
						$separator	= ' - ';
					else
						$separator  = apply_filters( 'gforms_rcwdupload_entry_filelist_separator_'.$form_id.'_'.$field['id'], apply_filters( 'gforms_rcwdupload_entry_filelist_separator_'.$form_id, apply_filters( 'gforms_rcwdupload_entry_filelist_separator', '<br />', $form_id, $field['id'], $lead['id'] ), $field['id'], $lead['id'] ), $lead['id'] );
	
					switch($separator){
						
						case '<br>':
						case '<br />':
						case 'br':
						case 'nl':
						
							$separator = '<br />';
							
							break;	
						case ' ':
						case 'space':
						
							$separator = ' ';	
							
							break;	
							
						case '-':
						case ' -':
						case '- ':
						case ' - ':
						
							$separator = ' - ';
							
							break;	
							
						default:
						
							$separator = '<br />';
							 																					
					}
	
					if(!empty($value))
						$value = implode( $separator, $value );	
									
				}
				
			}

		}

		return $value;
		
	}

	static function upload_info( $form_id, $field_id, $lead_id = 0, $userid = 0 , $rndfldr_ = '' ){
		
		global $rndfldr;
		
		if($rndfldr_)
			$rndfldr = $rndfldr_;

		if(isset($_REQUEST['product_add_to_cart'])){
			
			parse_str( $_REQUEST['product_add_to_cart'], $product_add_to_cart );
			
			if(isset($product_add_to_cart['rcwdupload_rndfldr']))
				$rndfldr = $product_add_to_cart['rcwdupload_rndfldr'];
					
		}

		$rndfldr	= !empty($rndfldr) ? $rndfldr : ( isset($_REQUEST["rcwdupload_rndfldr"]) ? $_REQUEST["rcwdupload_rndfldr"] : GFRcwdCommon::randomcode(array('length' => 15)) );
		$path_temp	= GFORMS_RCWDUPLOAD_UP_TEMP_DIR.RCWD_DS.$form_id.RCWD_DS.$field_id.RCWD_DS.$rndfldr;
		$path 		= GFORMS_RCWDUPLOAD_UP_DIR.RCWD_DS.$form_id.RCWD_DS.$field_id;
		$url_temp	= GFORMS_RCWDUPLOAD_UP_TEMP_URL.'/'.$form_id.'/'.$field_id.'/'.$rndfldr;
		$url		= GFORMS_RCWDUPLOAD_UP_URL.'/'.$form_id.'/'.$field_id;
		$purl 		= get_bloginfo('url').'/gformsrcwdup';
		$inline		= $purl.'/0/'.rand(10009, 99999).'/'.$form_id.'/'.$field_id;
		$attach		= $purl.'/1/'.rand(10009, 99999).'/'.$form_id.'/'.$field_id;

		if($lead_id > 0){
			
			$path	.= RCWD_DS.$lead_id;
			$url	.= '/'.$lead_id;
			$inline .= '/'.$lead_id;
			$attach .= '/'.$lead_id;
			
		}
		
		if( is_multisite() and !is_main_site() ){
/*					die($purl);
	
			$url	= $url;
			$inline = $inline;
			$attach = $attach;	*/		
			
			
		}

		// GFORMS USER REGISTRATION PLUGIN _______________________________________________________________________		
				
			if( /*!IS_ADMIN and*/ ( class_exists("GFUser") or class_exists("GF_User_Registration") ) /*and is_user_logged_in()*/ ){
	
				if( defined('GF_USER_REGISTRATION_VERSION') and version_compare( GF_USER_REGISTRATION_VERSION, '3', '>=' ) )
					$config = gf_user_registration()->get_update_feed($form_id);
				else
					$config = GFUserData::get_update_feed($form_id);

				if( ( $form_id == $config['form_id'] and ( $config['meta']['feed_type'] == 'update' or $config['meta']['feedType'] == 'update' ) ) or $userid > 0 ){
						
					if($userid == 0)
						$userid = get_current_user_id();
			
					$user 		= get_userdata($userid);
					$formmode 	= 'userupdate';
					$path 		= GFORMS_RCWDUPLOAD_UP_DIR.RCWD_DS.'users'.RCWD_DS.$userid;
					$url		= GFORMS_RCWDUPLOAD_UP_URL.'/users/'.$user->ID;
					$purl 		= get_bloginfo('url').'/gformsrcwdup';
					$inline		= $purl.'/0/'.rand(10009, 99999).'/user/'.$userid;
					$attach		= $purl.'/1/'.rand(10009, 99999).'/user/'.$userid;
							
				}
											
			}
		
		// _______________________________________________________________________________________________________
		
		wp_mkdir_p($path_temp);
		wp_mkdir_p($path);
				
		if(!file_exists(GFORMS_RCWDUPLOAD_UP_TEMP_DIR.RCWD_DS."index.html"))
			self::add_file_index(GFORMS_RCWDUPLOAD_UP_TEMP_DIR);
	
		if(!file_exists($path_temp.RCWD_DS."index.html"))
			self::add_file_index($path_temp);
			
		if(!file_exists(GFORMS_RCWDUPLOAD_UP_DIR.RCWD_DS."index.html"))
			self::add_file_index(GFORMS_RCWDUPLOAD_UP_DIR);
			
		if(!file_exists($path.RCWD_DS."index.html"))
			self::add_file_index($path);
			
		$path = apply_filters( "gforms_rcwdupload_path_{$form_id}_{$field_id}", apply_filters( "gforms_rcwdupload_path_{$form_id}", apply_filters( "gforms_rcwdupload_path", $path, $form_id, $field_id, $lead_id ), $field_id, $lead_id ), $lead_id );
		
		$url  = apply_filters( "gforms_rcwdupload_url_{$form_id}_{$field_id}", apply_filters( "gforms_rcwdupload_url_{$form_id}", apply_filters( "gforms_rcwdupload_url", $url, $form_id, $field_id, $lead_id ), $field_id, $lead_id ), $lead_id );

		if(substr( $path_temp, -1 ) != RCWD_DS)
			$path_temp .= RCWD_DS;
							
		if(substr( $path, -1 ) != RCWD_DS)
			$path .= RCWD_DS;
			
		if(substr( $url_temp, -1 ) != '/')
			$url_temp .= '/';
							
		if(substr( $url, -1 ) != '/')
			$url .= '/';			

		if(substr( $inline, -1 ) != '/')
			$inline .= '/';

		if(substr( $attach, -1 ) != '/')
			$attach .= '/';					

		$output = array( 'rndfldr' => $rndfldr, 'path_temp' => $path_temp, 'path' => $path, 'url_temp' => $url_temp, 'url' => $url, 'purl' => array( 'inline' => $inline, 'attach' => $attach ) );
		
		return $output;					
	}

    static function add_file_index($dir){
		
        if(!is_dir($dir))
            return;

        if(!($od = opendir($dir)))
            return;

        set_error_handler(create_function("", "return 0;"), E_ALL);

        if($f = fopen( $dir."/index.html", 'w' ))
            fclose($f);

        restore_error_handler();

        while((false !== $file = readdir($od)))
           if(is_dir("$dir/$file") and $file != '.' and $file != '..' )
               self::add_file_index("$dir/$file");

        closedir($od);
		
    }

	static function field_value_correction( $value = '', $field = array() ){
		
		if(is_array($value) and count($value) > 0 and is_array($field) and count($field) > 0 and $field['type'] == 'rcwdupload' ){

			$field_file		= $value['file'];
			$field_title 	= isset($value['title']) 	? $value['title'] 	: array();
			$field_rndfldr 	= isset($value['rndfldr']) 	? $value['rndfldr'] : '';
			$field_			= array();
			
			foreach($field_file as $k => $v){
				
				$field_[] = array(
				
					'file' => $v,
					'title' => ( isset($field_title[$k]) ? $field_title[$k] : '' )
					
				);
				
				if(!empty($field_rndfldr))
					$field_[$k]['rndfldr'] = $field_rndfldr;
				
			}
			
			return $field_;
	
		}	
		
		return false;	
		
	}
	
    static function get_dir($file){
		
        $dir 	= trailingslashit(dirname($file));
        $count 	= 0;
        
        // sanitize for Win32 installs
        $dir = str_replace('\\' ,'/', $dir); 
        
        // if file is in plugins folder
        $wp_plugin_dir 	= str_replace('\\' ,'/', WP_PLUGIN_DIR); 
        $dir 			= str_replace($wp_plugin_dir, plugins_url(), $dir, $count);
        
        if( $count < 1 ){
	        // if file is in wp-content folder
	        $wp_content_dir = str_replace('\\' ,'/', WP_CONTENT_DIR); 
	        $dir 			= str_replace($wp_content_dir, content_url(), $dir, $count);
        }
        
        if( $count < 1 ){
	        // if file is in ??? folder
	        $wp_dir = str_replace('\\' ,'/', ABSPATH); 
	        $dir 	= str_replace($wp_dir, site_url('/'), $dir);
        }

        return $dir;
		
    }
					
	static function remove_dir( $dirname, $sub = true ){

		if(is_dir($dirname)){
			
			if ($dirHandle = opendir($dirname)){
				
				$old_cwd = getcwd();
				
				chdir($dirname);
		
				while ($file = readdir($dirHandle)){
					
					if ($file == '.' || $file == '..')
						continue;
					
					if(!is_dir($dirname.$file))
						if (!unlink($dirname.$file))
							continue;
					
					if ( is_dir($file) and $sub )
						if (!self::remove_dir($dirname.$file))
							return false;
								
					else{

						if (!unlink($dirname.$file))
							return false;

					}
				}
				
				closedir($dirHandle);
				chdir($old_cwd);
				
				if (!rmdir($dirname))
					return false;
					
				return true;
			}else
				return false;
			
		}
		
	}

	static function RemoveEmptySubFolders($path){
		
		$empty = true;
		
		foreach (glob($path.DIRECTORY_SEPARATOR."*") as $file)
			$empty &= is_dir($file) and self::RemoveEmptySubFolders($file);
			
		return $empty and @rmdir($path);
	  
	}

	static function is_dir_empty($dir){
	
		if (!is_readable($dir))
			return NULL; 
		
		if(is_dir($dir)){
			
			$handle = @opendir($dir);
			
			while( false !== ($entry = readdir($handle)) )
				if ($entry != "." and $entry != ".." )
					return false;
				
		}
				
		return true;
	
	}

	static function remove_file($dir){ 
	
		global $gfrcwd2brem_dirs, $gfrcwd2brem_files;
		
		if(is_dir($dir)){ 
		
			$objects = @scandir($dir); 
			
			foreach($objects as $object){ 
			
				if( $object != "." and $object != ".." ){ 
					
					$sdfhko = $dir."/".$object;
					
					if(!empty($sdfhko)){
										
						if (is_dir($dir."/".$object))
							self::remove_file($dir."/".$object);
						else{
							
							if(file_exists($dir."/".$object)){
								
								$filemtime = filemtime($dir."/".$object);
								
								if( time() - $filemtime > 86400 )
									$gfrcwd2brem_files[] = $dir."/".$object;
									//@unlink($dir."/".$object); 
								
							}
								
						}
					
					}
					
				} 
				
			}
			
			if( is_dir($dir) and self::is_dir_empty($dir) )
				$gfrcwd2brem_dirs[] = $dir;
				//@rmdir($dir); 
			
		} 
	
	}
	
	static function clean_temp(){

		global $gfrcwd2brem_dirs, $gfrcwd2brem_files;

		$clean = get_option('gforms_rcwdupload_clean_temp');
		
		if( !$clean or time() - $clean > 86400 ){
			
			if (is_dir(GFORMS_RCWDUPLOAD_UP_TEMP_DIR)){

				$folders = scandir(GFORMS_RCWDUPLOAD_UP_TEMP_DIR);
			
				foreach($folders as $folder)
					if( !empty($folder) and $folder!= '.' and $folder != '..' and $folder != 'index.html' and file_exists(GFORMS_RCWDUPLOAD_UP_TEMP_DIR.RCWD_DS.$folder) )					
						self::remove_file(GFORMS_RCWDUPLOAD_UP_TEMP_DIR.RCWD_DS.$folder);
			
			}
			
			$clean = update_option( 'gforms_rcwdupload_clean_temp', time() );	
			
			if(!empty($gfrcwd2brem_files))
				foreach($gfrcwd2brem_files as $file)
					if(file_exists($file))
						@unlink($file);
						
			if(!empty($gfrcwd2brem_dirs))
				foreach($gfrcwd2brem_dirs as $dir)
					self::RemoveEmptySubFolders($dir);
			
		}
		
	}
	
	static function handle_upload_request(){

		if (isset($_GET['gformsrcwdupload'])){

			$upload_file = apply_filters( 'gforms_rcwdupload_upload_file', implode( RCWD_DS, array( trailingslashit(dirname(__FILE__)), 'upload.php' )) );
			
			if(!empty($upload_file))
				require_once($upload_file);
			else
				die('Something gone wrong :(');	
				
			throw new gforms_rcwd_clean_exit();
			
		}
		
		if (isset($_GET['gformsrcwduplddwnlod'])){
			
			require_once(implode( RCWD_DS, array( trailingslashit(dirname(__FILE__)), 'download.php' ) ));
			
			throw new gforms_rcwd_clean_exit();
			
		}
		
	}

	function get_lead($id = 0){
		
		$id = (int)$id;
		
		if($id > 0){
			
			global $wpdb;
				
			$lead_detail_table_name = RGFormsModel::get_lead_details_table_name();
			$lead_table_name        = RGFormsModel::get_lead_table_name();
			$results 				= $wpdb->get_results($wpdb->prepare( "SELECT l.*, field_number, value FROM $lead_table_name l LEFT JOIN $lead_detail_table_name ld ON l.id = ld.lead_id WHERE l.id=%d", $id ));		
			$leads 					= RGFormsModel::build_lead_array( $results, true );
	
			return sizeof($leads) == 1 ? $leads[0] : false;
		
		}
		
		return false;
				
	}
	
	static function serial_is_valid($remotecheck = false){

		$check 				= get_option( 'gforms_rcwdupload_verifypurchase' );
		$check['item_id'] 	= self::GFORMS_RCWDUPLOAD_ITEM_ID;
		$docheck 			= true;

		if( isset($check['username']) and isset($check['purchased']) and $check['purchased'] === true and isset($check['lastcheck']) )
			$docheck = false;
		elseif(!$remotecheck)
			return false;		

		if($docheck){
			
			$check['website'] = $_SERVER['HTTP_HOST'];
						
			$checkit 		= self::checkit();
			$remote_post	= $checkit[0];
			$state			= $checkit[1];

			if($state)
				$remote_post = unserialize($remote_post['body']);
			else
				if( !isset($check['purchased']) or !$check['purchased']  ){		
				
					update_option( 'gforms_rcwdupload_verifypurchase', $check );
					
					return false;
					
				}
				
			if( ( $remote_post !== false or $remote_post == '' ) and ( !isset($remote_post['verify-purchase']) or !isset($remote_post['verify-purchase']['item_id']) or $remote_post['verify-purchase']['item_id'] != $check['item_id'] or !isset($remote_post['verify-purchase']['buyer']) or strtolower($remote_post['verify-purchase']['buyer']) != strtolower($check['username']) ) ){

				unset($check['purchased']);
				unset($check['lastcheck']);
				
				update_option( 'gforms_rcwdupload_verifypurchase', $check );
				
				return false;
				
			}

			$check['purchased'] = true;
			$check['lastcheck'] = time();
				
			update_option( 'gforms_rcwdupload_verifypurchase', $check );
		
		}
			
		return true;	
			
	}
	
	static function error_not_authenticated( $isnotice = true, $return = false ){

		if( !isset($_GET['page']) or ( isset($_GET['page']) and $_GET['page'] != 'gforms-rcwdupload' ) ){
			
			$msg = sprintf( __( 'Please fill the correct data in <a href="%1s">this page</a>  before to use %2s for GRAVITY FORMS. Thanks...', 'gforms-rcwdupload' ), admin_url().'admin.php?page=gforms-rcwdupload', __( 'Rcwd Upload', 'gforms-rcwdupload' ) );
			if( is_string($isnotice) and $isnotice == '') 
				$isnotice = true;
			if($isnotice){
				$msg = '<div id="message" class="error"><p>'.$msg.'</p></div>';
			}
			if(!$return)
				echo $msg;
			else
				return $msg;
			
		}
			
	}

	static function checkit($args = array()){

		$check 				= get_option( 'gforms_rcwdupload_verifypurchase' );
		$check['item_id'] 	= self::GFORMS_RCWDUPLOAD_ITEM_ID;
		$dcheck				= isset($args['dcheck']) ? (bool)$args['dcheck'] : false;
		
		if (stripos( get_option('siteurl'), 'https://' ) === 0)
			$_SERVER['HTTPS'] = 'on';

		$api_url 	= 'http://www.cantarano.com';
		$api_surl 	= 'https://rcwd.gdev.it';
		$state		= false;
		
		if (is_ssl())
			$api_url = 'https://rcwd.gdev.it';
		
		$check['website'] 	= $_SERVER['HTTP_HOST'];
		$a					= array(

			'sslverify' => false,
			'timeout' 	=> 15,
			'body' 		=> $check

		);

		$remote_post = wp_remote_post( $api_url.'/envato/api/', $a );

		if( ( !is_wp_error($remote_post) and $remote_post['response']['code'] == 200 ) and $remote_post !== false ){
			
			$state = true;
	
		}elseif($api_url != $api_surl){
			
			$remote_post = wp_remote_post( $api_surl.'/envato/api/', $a );

			if ( ( !is_wp_error($remote_post) and $remote_post['response']['code'] == 200 ) and $remote_post !== false )
				$state = true;
				
		}
		
		return array( $remote_post, $state );
							
	}
	
	static function manage_file_request($args = array()){

		if(empty($args))
			return false;

		$single					= (bool)$args['single'];
		$mode					= isset($args['mode']) ? filter_var( $args['mode'], FILTER_SANITIZE_STRING ) : 'url';		
		$permalink_structure 	= get_option('permalink_structure');	
		$post_id				= isset($args['post_id']) 	? (int)$args['post_id'] 	: 0;
		$form_id				= isset($args['form_id']) 	? (int)$args['form_id'] 	: 0;
		$entry_id				= isset($args['entry_id']) 	? (int)$args['entry_id'] 	: 0;
		$field_id				= isset($args['field_id']) 	? (int)$args['field_id'] 	: 0;
		$user_id				= isset($args['user_id']) 	? (int)$args['user_id'] 	: 0;
		$isfile					= false;
		$value					= false;

		if($user_id > 0){
			
			$entry_id = get_user_meta( $user_id, '_gform-update-entry-id', true ); 
			
			if(empty($entry_id)){
				
				$user_id 	= 0;
				$field_id	= 0;
					
			}
			
		}
		
		if($field_id <= 0)
			return false;
		
		if($post_id > 0)
			$entry_id = (int)get_post_meta( $post_id, '_gform-entry-id', true );
		
		if($entry_id > 0){
			
			$lead = RGFormsModel::get_lead($entry_id);
			
			if( !empty($lead) and $form_id <= 0 )
				$form_id = (int)$lead['form_id'];
		
		}
			
		if($form_id > 0){
			
			$form = RGFormsModel::get_form_meta($form_id);
			
			if(!empty($form)){
				
				foreach( $form['fields'] as $field ){
					
					$field = (array)$field;
					
					if( $field['type'] == 'rcwdupload' and $field_id == $field['id'] ){
						
						$value = unserialize($lead[$field_id]); 
						
						break;
						
					}
					
				}
			
				if(!empty($value)){
				
					$upload_info = GFRcwdCommon::upload_info( $form_id, $field_id, $entry_id, $user_id );
	
					if($mode == 'path'){
						
						foreach( $value as $key => $fl ){
							
							if(!isset($fl['file']))
								continue;		
								
							$v[$key] = $upload_info['path'].$fl['file'];	
							
						}					
						
					}elseif($mode == 'url'){
						
						if(empty($permalink_structure))
							$simpleurl = true;
		
						foreach( $value as $key => $fl ){
				
							if(!isset($fl['file']))
								continue;
												
							if($simpleurl)
								$url = $upload_info['purl']['inline'].$fl['file'];
							else
								$url = $upload_info['url'].$fl['file'];
								
							$v[$key] = $url;	
								
						}
													
					}else
						return false;
		
					if( !empty($v) and count($v) > 0 ){
						
						if($single)
							return $v[0];
					
						return $v;
						
					}
					
				}
			
			}
				
		}
		
		return false;
				
	}
					
}

if (!class_exists('gforms_rcwd_clean_exit')){
	class gforms_rcwd_clean_exit extends RuntimeException{}
}

function gforms_rcwdupload_gpaf_url( $post_id = 0, $field_id = 0, $single = false ){

	if( !is_numeric($post_id) or $post_id <= 0)
		$post_id = get_the_ID();
			
	return GFRcwdCommon::manage_file_request(array(
		
		'post_id'	=>  $post_id,
		'field_id'	=>  $field_id,
		'single'	=>  $single,
		'mode'		=>  'url'
		
	));

}

function gforms_rcwdupload_gpaf_path( $post_id = 0, $field_id = 0, $single = false ){

	if( !is_numeric($post_id) or $post_id <= 0)
		$post_id = get_the_ID();
			
	return GFRcwdCommon::manage_file_request(array(
		
		'post_id'	=>  $post_id,
		'field_id'	=>  $field_id,
		'single'	=>  $single,
		'mode'		=>  'path'
		
	));

}

function gforms_rcwdupload_gaf_url( $entry_id = 0, $field_id = 0, $single = false ){
	
	return GFRcwdCommon::manage_file_request(array(
		
			'field_id'	=>  $field_id,
			'entry_id'	=>  $entry_id,
			'single'	=>  $single,
			'mode'		=>  'url'
		
	));

}

function gforms_rcwdupload_gaf_path( $entry_id = 0, $field_id = 0, $single = false ){
	
	return GFRcwdCommon::manage_file_request(array(
		
			'field_id'	=>  $field_id,
			'entry_id'	=>  $entry_id,
			'single'	=>  $single,
			'mode'		=>  'path'
		
	));

}

function gforms_rcwdupload_guaf_url( $user_id = 0, $field_id = 0, $single = false ){
	
	return GFRcwdCommon::manage_file_request(array(
		
			'user_id'	=>  $user_id,
			'field_id'	=>  $field_id,
			'single'	=>  $single,
			'mode'		=>  'url'
		
	));

}

function gforms_rcwdupload_guaf_path( $user_id = 0, $field_id = 0, $single = false ){
	
	return GFRcwdCommon::manage_file_request(array(
		
			'user_id'	=>  $user_id,
			'field_id'	=>  $field_id,
			'single'	=>  $single,
			'mode'		=>  'path'
		
	));

}
?>