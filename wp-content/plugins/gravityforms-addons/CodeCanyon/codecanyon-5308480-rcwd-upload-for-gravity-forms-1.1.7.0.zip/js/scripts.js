var gformsrcwd 						= {};
var gformsrcwdupload_count 			= 1;
var gformsrcwdupload_original_title	= '';

(function($){

	gformsrcwdplupload_init = function(){
		
		$('.gformsrcwdplupload-container').each(function(){
	
			$(this).gformsrcwdPluploader({});
				
		})
		
	}
	
	gformsrcwd.uploadRefresh = function(el){
		
		var is = 'id';
		
		if($.type(el) == 'string'){
			
			if(el.substr( 0, 1) == '.')
				is = 'class';
			else if( el.substr( 0, 1) != '#' && el.substr( 0, 1) != '.' )
				el = '#'+el;
			
		}else if($.type(el) == 'object')
			el = el.attr('id');

		bhkbhnjop[el].refresh();
	
	}
	
	gformsrcwd.get_atts = function($el){
		
		var atts = {};
		
		$.each( $el[0].attributes, function( index, attr ){
			
			if( attr.name.substr(0, 5) == 'data-' )
				atts[ attr.name.replace('data-', '') ] = attr.value;
				
		});
		
		return atts;
			
	};

	gformsrcwd.addItem = function( element, max, file, source, thej ){

		var count = jQuery(element).closest('.gform_rcwdupload').find('.gforms_rcwdupload').length;
		
		if( max > 0 && count < max ){
		
			if(jQuery(element).hasClass('gforms_rcwdupload'))
				el = jQuery(element).hasClass('gforms_rcwdupload');
			else{
				
				if(jQuery(element).hasClass("gfield_icon_disabled"))
					return;
			
				var el = jQuery(element).closest('.gforms_rcwdupload');
			
			}
			
			var clone = el.clone();
			
			clone.find("input").val('').attr("tabindex", clone.find('input:last').attr("tabindex"));
			
			clone.find('.gformsrcwdplupload-temp').attr( 'data-showtemp', '');
	
			clone.find('.gformsrcwdplupload-filename').html('...');
	
			clone.find('.gformsrcwdplupload-remove, .gformsrcwdplupload-uploadfiles, .gformsrcwdplupload-temp, .gformsrcwdplupload-filesize, gformsrcwdplupload-clientpreview').css({ opacity : 0, display : 'none' });
			
			clone.find('.gformsrcwdplupload-clientpreview').html('');
	
			clone.find('[id]').each(function(){
				
				$(this).attr( 'id', $(this).attr('id') + '_' + gformsrcwdupload_count );
				
			});
					
			el.after(clone);
			gformsrcwd.toggleIcons( jQuery(element).closest('.gform_rcwdupload'), max );
			gformsrcwd.adjustClasses(el.parent());
			
			var args = {};
	
			if(typeof file !== 'undefined'){
				
				args = { addfile : file, 'source' : source };
	
			//	thej.removeFile(file);
				
			}
			
			clone.find('.gformsrcwdplupload-container').gformsrcwdPluploader(args);

			var count = 1;

			$(element).closest('.gformsrcwdupload-wrapper').find('.gformsrcwdupload-filecount').each(function(){
				
				$(this).find('span').html(count);
				
				count++;
				
			});
							
			gformsrcwdupload_count++;
		
		}
		
	}

	gformsrcwd.rename = function(element){
		
		var formid 		= $(element).attr('data-formid');
		var leadid 		= $(element).attr('data-leadid');
		var fieldid 	= $(element).attr('data-fieldid');
		var idsuffix 	= $(element).attr('data-idsuffix');
		var orig		= $('#current-file-' + formid + fieldid + idsuffix).html();
		var file		= $('#current-file-' + formid + fieldid + idsuffix + ' a').text();
		var name		= file.substr( 0, file.lastIndexOf('.') );
		var ext			= file.split('.').pop();

		$('#current-file-' + formid + fieldid + idsuffix + ' a').hide();
		$('#current-file-' + formid + fieldid + idsuffix).append('<span class="rcwduploadnewfilename_wrapper"><input type="text" id="rcwduploadnewfilename_' + formid + fieldid + idsuffix + '" value="' + name + '" data-formid="' + formid + '" data-leadid="' + leadid + '" data-fieldid="' + fieldid + '"  data-idsuffix="' + idsuffix + '" onblur="gformsrcwd.savefilename(this, \'' + ext + '\', \'' + name + '\');"> <span>' + ext + '</span></span>');
		
		$('#rcwduploadnewfilename_' + formid + fieldid + idsuffix).focus();
		
	}
	
	gformsrcwd.savefilename = function( element, ext, orig ){
		
		var formid 		= $(element).attr('data-formid');
		var leadid 		= $(element).attr('data-leadid');
		var fieldid 	= $(element).attr('data-fieldid');
		var idsuffix 	= $(element).attr('data-idsuffix');		
		var val			= $(element).val().trim();
		var fid			= fieldid;
		
		if( val == '' || val == orig ){
			
			$('#current-file-' + formid + fieldid + idsuffix + ' .rcwduploadnewfilename_wrapper').remove();
			$('#current-file-' + formid + fieldid + idsuffix + ' a').show();
				
			return false;
			
		}
			
		$(element).attr( 'readonly', true );
		
		$(element).val('Saving, wait please...');
		
		$.post( window['gformsrcwdi18n' + formid + '_' + fid].pluginurl + 'ajax-rename.php', {
			
			formid		: formid,
			leadid		: leadid,
			fieldid		: fid,
			idsuffix	: idsuffix,
			val			: val,
			orig		: orig,
			ext			: ext
			
		}).done(function(data){

			data 		= jQuery.parseJSON(data);
			var href	= $('#current-file-' + formid + fieldid + idsuffix + ' a').attr('href');
			var file	= $('#current-file-' + formid + fieldid + idsuffix + ' a').attr( 'href', href.replace( orig + '.' + ext, data.name ) );
						
			$('#current-file-' + formid + fieldid + idsuffix + ' a').text(data.name);
			$('#current-file-' + formid + fieldid + idsuffix + ' .rcwduploadnewfilename_wrapper').remove();
			$('#current-file-' + formid + fieldid + idsuffix + ' a').show();
			
		});
		
	}
	
	gformsrcwd.deleteItem = function( element, max ){

		var el 		= jQuery(element).closest('.gforms_rcwdupload');
		var t 		= jQuery(element).closest('.gform_rcwdupload');
		var	wrpr	= $(element).closest('.gformsrcwdupload-wrapper');
		var parent 	= el.parent();
		var count 	= 1;

		el.remove();

		wrpr.find('.gformsrcwdupload-filecount').each(function(){

			$(this).find('span').html(count);
			
			count++;
			
		});		
		
		gformsrcwd.toggleIcons( t, max );
		gformsrcwd.adjustClasses(parent);
		
	}

	gformsrcwd.toggleIcons = function(element, max){
		
		var count = element.find('.gforms_rcwdupload').length;
		if(count == 1)
			element.find(".delete_list_item").css("visibility", "hidden");
		else
			element.find(".delete_list_item").css("visibility", "visible");

		if( max > 0 && count >= max ){
			gformsrcwdupload_original_title = element.find(".add_list_item:first").attr("title");
			element.find(".add_list_item").addClass("gfield_icon_disabled").attr("title", "");
		}
		else{
			var addIcons = element.find(".add_list_item");
			
			addIcons.removeClass("gfield_icon_disabled");
			
			if(gformsrcwdupload_original_title)
				addIcons.attr("title", gformsrcwdupload_original_title);
				
		}
		
	}

	gformsrcwd.adjustClasses = function(el){
		
		var rows = el.children();
		
		for(var i = 0; i < rows.length; i++){
			
			var odd_even_class = (i+1) % 2 == 0 ? "gfield_list_row_even" : "gfield_list_row_odd";
			
			jQuery(rows[i]).removeClass("gfield_list_row_odd").removeClass("gfield_list_row_even").addClass(odd_even_class);
			
		}
		
	}

	$.fn.gformsrcwdPluploader = function(options){

		var el, el_, c, b, formid, fid, j, d, maxf, maxfsize, msel, overw, nf_txt, resize, csresize, fl, upf, cpv, cpv_, cpv_mw, cpv_mh, cpv_cr, nativeFiles, fsz, rmvcf, rmvtf, rmv, fht, fhtf, fhtfhref, fhts, fhtd, gformsfv, gformsfv_, gformsddb, b_txt, upflrs, fdspeed, rptid, rptd, fctid, fcid, reptr, replim, args, aupld, rnm, rndfldr, wrp, finwrp, repsrt, pv, pv_, pv_mw, pv_mh, pv_cr, chnk, frc, hdb, info, qlimit;

		var settings = $.extend( { refresh : false, addfile : false, source : false }, options );					
		
		if(settings.refresh === true){
			// TO DO: REMOVE IT OR NOT REMOVE IT, THIS IS THE QUESTION...
		}else{
		
			el			= $(this);
			el_			= this;
			c 			= el.attr("id");
			wrp			= el.closest('.gformsrcwdupload-wrapper').attr("id");
			finwrp		= el.closest('.gformsrcwdupload-field-inner-wrapper').attr("id");
			b			= el.find('.gformsrcwdplupload-pickfiles').attr("id");
			fl			= el.find('.gformsrcwdplupload-filelist').attr("id");
			upf			= el.find('.gformsrcwdplupload-uploadfiles').attr("id");
			cpv			= el.find('.gformsrcwdplupload-clientpreview').attr("id");
			rndfldr		= $('#rcwdupload_rndfldr').val();
			nativeFiles	= {};
			fsz			= el.find('.gformsrcwdplupload-filesize').attr("id");
			rmvcf		= el.find('.gformsrcwdplupload-removecf').attr("id");
			rmvtf		= el.find('.gformsrcwdplupload-removetf').attr("id");
			rmv			= el.find('.gformsrcwdplupload-remove').attr("id");
			fht			= el.find('.gformsrcwdplupload-temp').attr("id");
			fhtf		= el.find('.gformsrcwdplupload-temp-file').attr("id");
			fhtfhref	= decodeURIComponent($('#'+fhtf).attr('data-temp'));
			fhts		= el.find('.gformsrcwdplupload-temp-size').attr("id");
			fhtd 		= gformsrcwd.get_atts($('#'+fht));		
			gformsfv	= el.find('.gformsrcwdplupload-file-value').attr("id");
			gformsfv_	= $('#'+gformsfv).val();
			gformsddb	= el.find('.gformsrcwdplupload-ddbox').attr("id");
			d 			= gformsrcwd.get_atts(el);
			fid 		= d.fid;
			formid 		= d.formid;
			cpv_		= d.clientpreview;
			cpv_mw		= parseInt(d.clientpreview_max_width);
			cpv_mh		= parseInt(d.clientpreview_max_height);
			cpv_cr		= d.clientpreview_crop == 'Y' ? true : false;
			pv_			= d.preview;
			pv_mw		= parseInt(d.preview_max_width);
			pv_mh		= parseInt(d.preview_max_height);
			pv_cr		= d.preview_crop;
			maxf		= d.maxf;
			maxfsize	= d.maxfsize;
			msel		= d.msel;
			overw		= d.overw;
			nf_txt		= d.nftxt;
			reptr		= d.repeater;
			replim		= d.repeaterlimit;
			repsrt		= d.repeatersortable;
			resize		= d.resize != '' 	? '&'+$.param(JSON.parse(d.resize))	: '';
			csresize	= d.csresize != '' 	? JSON.parse(d.csresize) 			: '';
			upflrs		= d.upflrs != '' 	? JSON.parse(d.upflrs) 				: '';
			aupld		= d.autoupload;	
			hdb			= d.hidebrowse;	
			rnm			= d.rename;
			chnk		= d.chunks;
			frc			= d.frc;
			info		= d.info;
			b_txt		= $('#'+b).html();
			fdspeed		= 300;
			qlimit		= $(document).triggerHandler( 'gformsrcwdupload_global_queue_limit', qlimit );

			if(typeof qlimit === 'undefined')
				qlimit = 5;

			if( reptr == 'Y' && repsrt == 'Y' ){
				
				if($('#' + wrp).hasClass('ui-sortable'))
					$('#' + wrp).sortable('refresh');
				else{
					
					$('#' + wrp).sortable({
						
						placeholder				: "gfrcwdupld-dd-placeholder",
						helper					: "clone",
						appendTo				: document.body,
						forcePlaceholderSize	: true
		
					});
				
				}
			
			}
			
			function rmvtemp(){
	
				$('#' + rmvtf).click(function(ev){
					
					ev.preventDefault();

					el.find('.gformsrcwdplupload-temp').fadeTo(fdspeed, 0, function(){
						
						$(this).css( 'display', 'none' );
						
						bhkbhnjop[c].refresh();
						
					});
					
					$('#'+gformsfv).val(gformsfv_);
					
					if( typeof rmvcf != 'undefined' )
						$('#'+gformsfv).val(gformsfv_);
					else
						$('#'+gformsfv).val('');
						
					$(document).trigger( 'gformsrcwdupload_remove_temp_file', [ formid, fid ] );
					$(document).trigger( 'gformsrcwdupload_' + formid + '_remove_temp_file', [ fid ] );
					$(document).trigger( 'gformsrcwdupload_' + formid + '_' + fid + '_remove_temp_file' );

					if( hdb == 'Y2' )
						$('#' + b).show();	
															
				});	
			
			}
						
			if(typeof document['gformsrcwdupload_ckbtn_'+formid] == "undefined"){
				
				document['gformsrcwdupload_ckbtn_'+formid] = 'wee';
				
				$('#gform_submit_button_'+formid).on( 'click', function(e){
					
					var countreq = $(this).parent().prev('.gform_body').find('.gform_rcwdupload .gformsrcwdplupload-uploadfiles').filter(function(){ return $(this).css('opacity') == 1; }).length;
					
					if(countreq > 0){
						e.preventDefault();
						
						var err 	= new Object();
						err.message = window['gformsrcwdi18n' + formid + '_' + fid].errqueue;
						
						error(err);
						
					}else
						$('#gform_'+formid).submit();
							
				});
				
				
			}
			
			if( typeof fhtd.showtemp != 'undefined' && fhtd.showtemp == 1 ){
	
				$('#'+fhtf+' span.gformsrcwdplupload-temp-file-txt').html(nf_txt);
				$('#'+fhtf+' a').html(gformsfv_);
				$('#'+fhtf+' a').attr( 'href', fhtfhref+gformsfv_);
				$('#'+fhts+' span').html(fhtd.size);
								
				$('#'+fht).fadeTo(fdspeed, 1);
				
				rmvtemp();
				
			}
			
			$('<input/>').attr({ type:'hidden', name:fid+'-gfrcwd[]', 'class':'gformsrcwdplupload-gforms', value:gformsfv_ }).appendTo(el);

			args = {
				
				runtimes 			: 'html5,silverlight,flash,html4',
				container 			: c,
				browse_button 		: b,
				max_file_size 		: maxfsize,
				//url 				: window['gformsrcwdi18n' + formid + '_' + fid].url+'&formid='+formid+'&fid='+fid+'&overw='+overw+resize+'&rnm='+rnm+'&rcwdupload_rndfldr='+rndfldr+'&pv_='+pv_+'&pv_mw='+pv_mw+'&pv_mh='+pv_mh+'&pv_cr='+pv_cr,
				url					: window['gformsrcwdi18n' + formid + '_' + fid].url+'&info='+info,
				flash_swf_url 		: window['gformsrcwdi18n' + formid + '_' + fid].flash_swf_url,
				silverlight_xap_url : window['gformsrcwdi18n' + formid + '_' + fid].silverlight_xap_url,
				multi_selection		: msel,
				dragdrop			: true,
				drop_element		: finwrp,
				chunk_size			: chnk,
				unique_names		: false,
				max_retries			: 3,
				filters				: ''
											
			}
			
			if(csresize != '')
				args.resize = csresize;
				
			if(upflrs != '')
				args.filters = upflrs;

			fltr = $(document).triggerHandler( 'gformsrcwdupload_filters', [ args.filters, formid, fid ] );
			
			if(typeof fltr != 'undefined')
				args.filters = fltr;

			j = new plupload.Uploader(args);
		
			$(document).trigger( 'gformsrcwdupload_object', [ formid, fid ] );
						
			if( typeof bhkbhnjop === 'undefined')
				bhkbhnjop = new Object;

			bhkbhnjop[c] = j;

			$('#' + finwrp).on("dragover", function(event){
				
				 $(this).addClass('dragover');
				 
				 $(this).find('.gformsrcwdupload-dragme').on("dragover", function(event){
				 	
					$('#' + finwrp).addClass('dragover');
					 
				 });
				 
			});
	
			$('#'+finwrp).find('.gformsrcwdupload-dragme').on("dragleave", function(event){
				
				 $('#'+finwrp).removeClass('dragover');
				 
			});
	
			$('#'+finwrp).on("drop", function(event){
				
				 $(this).removeClass('dragover');
				 
			});
	
			$('#'+finwrp).on("end", function(event){
				
				 $(this).removeClass('dragover');
				 
			});							 
	
			j.bind('PostInit', function(up, params){
				
				if(j.runtime == "html5"){

					//var inputFile 	= document.getElementById(j.id + '_html5');
					var inputFile 	= $('#' + up.settings.container).find('.moxie-shim-html5 input')[0];
					var oldFunction = inputFile.onchange;
					
					inputFile.onchange = function(){
						
						nativeFiles = this.files;
						
						oldFunction.call(inputFile);
						
					}
								
				}
				
				if(settings.addfile)
					j.addFile(settings.addfile);
						
			});
			
			j.init();
			
			j.bind( 'FilesAdded', function( up, files ){
	
				var fileExt, flnm;
				var contnr 		= up.settings.container;
				var currfile	= 1;
																
				if(aupld != 'Y')
					$('#' + upf).fadeTo( fdspeed, 1 );

				if( aupld != 'Y' && hdb == 'Y' )
					$('#' + b).hide();
						
				if(up.files.length > maxf){
					
					up.files.reverse();
					
					j.splice( maxf, up.files.length - maxf );
					
				}
				
				var cccccc	= 1;
				var sdfgdg 	= new Array();
				var rmvfl 	= new Array();
				
				$.each( j.files, function( i, file ){
				
					if(cccccc > 1){
						
						var zzzz = new Array();
						
						zzzz.push(file.getNative());
						zzzz.push(file.getSource());
						
						sdfgdg.push(zzzz);
						
						rmvfl.push(file);
						
					}
					
					cccccc++;
					
				});
				
				if(rmvfl.length > 0)
					$.each(rmvfl, function( i, fl ){
						
						j.removeFile(fl);
						
					});
				

				sdfgdg.reverse();
				
				$.each(sdfgdg, function( i, content ){

					gformsrcwd.addItem( el_, replim, content[0], content[1] );
					
				});

				$.each(j.files, function( i, file ){

					fileExt = 'gformsrcwdupload-filext-' + file.name.split('.').pop().toLowerCase(); 	
					flnm 	= file.name;
					
					if(currfile == 1){
						
						if(file.name.length > 30)
							flnm = 	flnm.substr( 0, 30 ) + '...';
						
						if( j.runtime == "html5" /*&& aupld != 'Y'*/ ){
							
							$('#' + cpv).html('');

							var image 			= $( new Image() ).appendTo('#' + cpv);
							var imagefe 		= $( new Image() );
							var preloader 		= new mOxie.Image();
							var editimg			= '';
							preloader.onload 	= function(){
								
								j.settings.url = j.settings.url + '&orw=' + preloader.width + '&orh=' + preloader.height;
								
								if(cpv_ == 'Y'){

									if(typeof $(el_).data('width') != 'undefined')
										var width = parseInt($(el_).data('width'));
		
									if(typeof $(el_).data('height') != 'undefined')
										var height = parseInt($(el_).data('height'));									
		
									if(typeof $(el_).data('height') != 'undefined')
										var crop = Boolean($(el_).data('crop'));
									
									if( cpv_mw > 0 )	
										var width = cpv_mw;
	
									if( cpv_mh > 0 )	
										var height = cpv_mh;
																			
									if( cpv_mw > 0 &&  cpv_mh > 0 )
										var crop = cpv_cr;
																		 

									
									if( preloader.meta && preloader.meta.tiff && preloader.meta.tiff.Orientation){
										
										var orientation = preloader.meta.tiff.Orientation;
										
										if($.inArray( orientation, [ 5, 6, 7, 8 ] )){

											preloader.downsize( width, height, crop, false ); 
									
											image.prop( "src", preloader.getAsDataURL() );
											image.prop( "width", width );
											image.prop( "height", height )											
											
										}else{

											preloader.downsize( width, height, crop ); 
									
											image.prop( "src", preloader.getAsDataURL() );
											image.prop( "width", width );
											image.prop( "height", height );											
											
										}
									
									}else{

										preloader.downsize( width, height, crop ); 
									
										image.prop( "src", preloader.getAsDataURL() );
										image.prop( "width", width );
										image.prop( "height", height );											
											
									}
									
									image.prop( "meta", preloader.meta );
									
									 $('#' + cpv).css( 'display', 'block' ).fadeTo(fdspeed, 1);
								 
								}
								 
							}
							
							preloader.load(file.getSource());						 
							
						
						}

						if(aupld == 'Y'){
							
							j.start();	
	
							$('#'+b).addClass('button-disabled');	
							
							$('#'+upf).fadeTo(fdspeed, 0, function(){
								
								$(this).css( 'display', 'none' );
								
							});
								
						}
												
						$('#'+fl+' .gformsrcwdplupload-filename').closest('.gformsrcwdplupload-filewrapper').attr( 'id', file.id );
						$('#'+fl+' .gformsrcwdplupload-filename').html('<span class="gformsrcwdupload-filext-generic '+fileExt+'" title="'+file.name+'">'+flnm+'</span>');
						
						
						$('#'+fsz+' span').html(' ('+plupload.formatSize(file.size)+')');
						$('#'+fsz).fadeTo( fdspeed, 1 );
						$('#'+rmv).fadeTo( fdspeed, 1 );
						
						g();
					
					}
					
					currfile++;
					
				});
				
				if(j.files.length > 1)
					j.splice( 1, j.files.length - 1 );	
							
				up.refresh();
														
			});






			$('#' + upf).click(function(ev){
				
				if(j.files.length > 0){

					j.start();
					
					$('#' + b).addClass('button-disabled');	
					
					if( aupld != 'Y' && hdb == 'Y' ){
						
						$('#' + upf).hide();
						$('#' + b).show();
						
					}else{
						
						$('#' + upf).fadeTo(fdspeed, 0, function(){
							
							$(this).css( 'display', 'none' );
							
						});
					
					}
										
				}
				
				ev.preventDefault();
				
			});	
			
			
			
  $(document).on('click', '[data-method]', function () {
    var $this = $(this);
    var data = $this.data();
    var $target;
    var result;
	 $image 		= $('#gformsrcwdplupload-imgtedt');
    if ($this.prop('disabled') || $this.hasClass('disabled')) {
      return;
    }

    if ($image.data('cropper') && data.method) {
      data = $.extend({}, data); // Clone a new one

      if (typeof data.target !== 'undefined') {
        $target = $(data.target);

        if (typeof data.option === 'undefined') {
          try {
            data.option = JSON.parse($target.val());
          } catch (e) {
            console.log(e.message);
          }
        }
      }

      if (data.method === 'rotate') {
        $image.cropper('clear');
      }

      result = $image.cropper(data.method, data.option, data.secondOption);

      if (data.method === 'rotate') {
        $image.cropper('crop');
      }

      switch (data.method) {
        case 'scaleX':
        case 'scaleY':
          $(this).data('option', -data.option);
          break;

        case 'getCroppedCanvas':
          if (result) {

            // Bootstrap's Modal
            $('#getCroppedCanvasModal').modal().find('.modal-body').html(result);

            if (!$download.hasClass('disabled')) {
              $download.attr('href', result.toDataURL('image/jpeg'));
            }
          }

          break;
      }

      if ($.isPlainObject(result) && $target) {
        try {
          $target.val(JSON.stringify(result));
        } catch (e) {
          console.log(e.message);
        }
      }

    }
  });			
				
			$('#' + fhts).on('click', 'i.gformsrcwdplupload-editimg', function(ev){

				var thisel		= this;
				var src			= decodeURIComponent($(this).attr('data-img'));
				
/*$('body').prepend('<div id="gformsrcwdplupload-imgtedt-wrapper"><div id="gformsrcwdplupload-imgtedt-img-wrapper"><img id="gformsrcwdplupload-imgtedt" src="' + src + '"></div></div>');

$('#gformsrcwdplupload-imgtedt').cropper({
  aspectRatio: 16 / 9,
  crop: function(e) {
	// Output the result data for cropping image.

  }
  
});

$( document ).on( 'keydown', function ( e ) {
    if ( e.keyCode === 27 ) { // ESC
        $('#gformsrcwdplupload-imgtedt-wrapper').remove();
    }
});*/
				
								
				var btns 		= '<div id="gformsrcwdplupload-imgtedt-buttons"><div class="gformsrcwdplupload-imgtedt-btn-group"><button type="button" class="btn btn-primary" data-method="setDragMode" data-option="move" title="Move"><span class="docs-tooltip" data-toggle="tooltip" title="$().cropper(&quot;setDragMode&quot;, &quot;move&quot;)"><span class="fa fa-arrows"></span></span></button><button type="button" class="btn btn-primary" data-method="setDragMode" data-option="crop" title="Crop"><span class="docs-tooltip" data-toggle="tooltip" title="$().cropper(&quot;setDragMode&quot;, &quot;crop&quot;)"><span class="fa fa-crop"></span></span></button><button type="button" class="btn btn-primary" data-method="rotate" data-option="-45" title="Rotate Left"> <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper(&quot;rotate&quot;, -45)"> <span class="fa fa-rotate-left"></span> </span> </button> <button type="button" class="btn btn-primary" data-method="rotate" data-option="45" title="Rotate Right"> <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper(&quot;rotate&quot;, 45)"> <span class="fa fa-rotate-right"></span> </span> </button></div><div class="gformsrcwdplupload-imgtedt-btn-group"> <button type="button" class="btn btn-primary" data-method="scaleX" data-option="-1" title="Flip Horizontal"> <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper(&quot;scaleX&quot;, -1)"> <span class="fa fa-arrows-h"></span> </span> </button> <button type="button" class="btn btn-primary" data-method="scaleY" data-option="-1" title="Flip Vertical"> <span class="docs-tooltip" data-toggle="tooltip" title="$().cropper(&quot;scaleY&quot;, -1)"> <span class="fa fa-arrows-v"></span> </span> </button> </div><div class="gformsrcwdplupload-imgtedt-btn-group"><button type="button" class="btn btn-primary" data-method="reset" title="Reset"><span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="$().cropper(&quot;reset&quot;)"><span class="fa fa-refresh"></span></span></button></div><div class="gformsrcwdplupload-clear"></div></div>';				
				var myPrompt 	= $.prompt(
				
					'<div id="gformsrcwdplupload-imgtedt-outer-wrapper"><div id="gformsrcwdplupload-imgtedt-wrapper"><img id="gformsrcwdplupload-imgtedt" src="' + src + '"></div>' + btns + '</div>',
					{
						buttons: {
							
							"Save"	: 1,
							"Close"	: 0
							
						},
						top 	: 0,
						loaded 	: function(){
										
							var img 		= $('#gformsrcwdplupload-imgtedt');
							var cropBoxData;
							var canvasData;	
							var crresize	= JSON.parse(d.resize);			
							var crh 		= '';
							var crobject 	= new Object;
							crobject.x 		= 0;
							crobject.y 		= 0;
							crobject.rotate	= 0;
							crobject.scaleX	= 1;
							crobject.scaleY	= 1;
	
							if(crresize.width > 0)
								crobject.width = crresize.width;

							if(crresize.height > 0)
								crobject.height = crresize.height;

							img.cropper({
								
								aspectRatio		: crobject.width / crobject.height,
								autoCropArea	: 1,
								built			: function(){
									
									var curcrop = $('#' + fhts + ' i.gformsrcwdplupload-editimg').attr('data-crop');
									
									if(curcrop == '')
										img.cropper( 'setData', crobject );
									else
										img.cropper( 'setData', jQuery.parseJSON(curcrop) );
										
									
								
								}
							
							});								
							
						},
						submit : function( e, v, m, f ){ 
						
							e.preventDefault();
							
							if(v == 1){
							
								var jsdt = JSON.stringify($('#gformsrcwdplupload-imgtedt').cropper("getData"));
								
								$('#' + fhts + ' i.gformsrcwdplupload-editimg').attr( 'data-crop', jsdt );
																
							}
							
							$('#gformsrcwdplupload-imgtedt-outer-wrapper').remove();
							
							$.prompt.close();
						
						}
						
					}
				
				);


				

						
			});	
	
			j.bind('BeforeUpload', function( up, file ){
				
				up.rcwdfile = file;

				if(typeof window['gformsrcwdCurrUp'] === 'undefined')
					window['gformsrcwdCurrUp'] = new Array();
				
				if(typeof window['gformsrcwdQueue'] === 'undefined')
					window['gformsrcwdQueue'] = new Array();
				
				if(window['gformsrcwdCurrUp'].length >= qlimit){
					
					window['gformsrcwdQueue'].push(up);
					
					$('#' + b).html(window['gformsrcwdi18n' + formid + '_' + fid].queued);

					return false;

				}else{
				
					window['gformsrcwdCurrUp'].push(up);

					$('#' + b).html("0%");
					
					if(typeof up.rcwdthiswasqueued !== 'undefined')
						up.start();
					
				}
				
			});
							
			j.bind('UploadProgress', function( up, file ){

				$( '#' + b ).html(file.percent + "%");

				if(file.percent == 100)
					$('#' + b).html(window['gformsrcwdi18n' + formid + '_' + fid].processing);
				else
					$('#' + b).html(file.percent + "%");
									
			});
							
			j.bind('FileUploaded', function( up, file, info ){
				
				var obj, flnm;
				
				obj = JSON.parse(info.response);

				window['gformsrcwdCurrUp'] = jQuery.grep( window['gformsrcwdCurrUp'], function(value){
				
					return value.settings.container != up.settings.container;
				
				});
				
				if( window['gformsrcwdCurrUp'].length < qlimit && window['gformsrcwdQueue'].length > 0 ){

					bhkbhnjop[window['gformsrcwdQueue'][0].settings.container].rcwdthiswasqueued = true;

					var curr_cntnr	= window['gformsrcwdQueue'][0].settings.container;
					var cccccc		= 1;
					var sdfgdg 		= new Array();
					var rmvfl 		= new Array();
					var thefile 	= window['gformsrcwdQueue'][0].rcwdfile;					
					var zzzz =		 new Array();
					
					zzzz.push(thefile.getNative());
					zzzz.push(thefile.getSource());
					sdfgdg.push(zzzz);
					rmvfl.push(thefile);
												

					if(rmvfl.length > 0)
						$.each(rmvfl, function( i, fl ){
							
							bhkbhnjop[curr_cntnr].removeFile(fl);
							
						});

					bhkbhnjop[curr_cntnr].stop();
					bhkbhnjop[curr_cntnr].addFile(sdfgdg[0][0]);					
					bhkbhnjop[curr_cntnr].start();

					quued_b 	= $('#' + curr_cntnr).find('.gformsrcwdplupload-pickfiles').attr("id");
					quued_upf	= $('#' + curr_cntnr).find('.gformsrcwdplupload-uploadfiles').attr("id");
					
					$('#' + quued_b).addClass('button-disabled');	
					
					$('#' + quued_upf).fadeTo( fdspeed, 0, function(){
						
						$(this).css( 'display', 'none' );
						
					});
					
					window['gformsrcwdQueue'] = jQuery.grep( window['gformsrcwdQueue'], function(value){
					
						return value.settings.container != curr_cntnr;
					
					});
					
				}
							
				if( typeof obj.error != 'undefined' )
					error(obj.error);
				else{
					
					flnm = obj.filename;
							
					$('#' + file.id + " b").html("99%");
					$('#'+ b).addClass('button-disabled');	
					$('#' + gformsfv).val(obj.filename).change();		
					$('#' + fhtf + ' span.gformsrcwdplupload-temp-file-txt').html(nf_txt);
					$('#' + fhtf + ' a').html(obj.filename);
					$('#' + fhtf + ' a').attr( 'href', fhtfhref+obj.filename);
					$('#' + fhts + ' span').html(plupload.formatSize(obj.size));
					$('#' + file.id + " b").html("100%");
					$('#' + fht).fadeTo(fdspeed, 1);	

					$(document).trigger( 'gformsrcwdupload_fileuploaded', [ fhtfhref + obj.filename, formid, fid ] );
					$(document).trigger( 'gformsrcwdupload_' + formid + '_fileuploaded', [ fhtfhref + obj.filename, fid ] );
					$(document).trigger( 'gformsrcwdupload_' + formid + '_' + fid + '_fileuploaded', [ fhtfhref + obj.filename ] );	
					
					var ext = flnm.split('.').pop().toLowerCase();
					
					if( pv_ == 'Y' && ( ext == 'jpg' || ext == 'jpeg' || ext == 'png' || ext == 'gif' || ext == 'tif' || ext == 'tiff' ) ){
						
						var e = $.Event( "gformsrcwdupload_thumb_force_http" );
						
						$(document).trigger( e, [ formid, fid ] );
						
						var frc = Boolean(e.result);
						
						if(frc)
							var frc = 1;
						else
							var frc = 0;
							
						var thumburl = window['gformsrcwdi18n' + formid + '_' + fid].thumburl+'?f=' + encodeURIComponent(obj.base64) + '&w=' + pv_mw + '&h=' + pv_mh + '&c=' + pv_cr + '&t=1&frc=' + frc;
						
						if($('#' + fht + ' .gformsrcwdplupload-temp-preview').length > 0)
							$('#' + fht + ' .gformsrcwdplupload-temp-preview').html('<img src="' + thumburl + '" alt="" />');
						else
							$('#' + fht).append('<div class="gformsrcwdplupload-temp-preview"><img src="' + thumburl + '" alt="" /></div>');
					
					}else{
						
						if($('#' + fht + ' .gformsrcwdplupload-temp-preview').length > 0)
							$('#' + fht + ' .gformsrcwdplupload-temp-preview').remove();						
						
					}
					
					if( hdb == 'Y2' )
						$('#' + b).hide();
						

						var editimg = ' <i class="fa fa-pencil gformsrcwdplupload-editimg" data-img="' + encodeURIComponent(fhtfhref + obj.filename) + '" data-crop=""></i>';
						
						$('#' + fhts + ' span').append(' ' + editimg);
					
					
					
										
	
				}
			
				$('#'+fl+' .gformsrcwdplupload-filename').fadeTo(fdspeed, 0, function(){
					
					$(this).html('...').fadeTo(fdspeed, 1);
					
				});
				
				$('#'+fsz).fadeTo(fdspeed, 0, function(){
					
					$(this).css( 'display', 'none' );
					
				});	
				
				$('#'+rmv).fadeTo(fdspeed, 0, function(){
					
					$(this).css( 'display', 'none' );
					
				});	
	
				$('#'+cpv).fadeTo(fdspeed, 0, function(){
					
					$(this).css( 'display', 'none' );
					$(this).html('');
					
				});
				
				j.removeFile(file);
										
			});
	
			j.bind('UploadComplete', function(up, files){
				
				setTimeout(function(){
					
					$('#' + b).removeClass('button-disabled');	
					$('#' + b).html(b_txt);
					up.refresh();
					
				}, 500);	
								
			});
			
			j.bind('Error', function( up, err ){
				
				error(err);
				up.refresh();
				
			});
	
			function error(err){
				
				var msg;
				
				switch(err.code){
					
					case -600: 
						msg = window['gformsrcwdi18n' + formid + '_' + fid].err600;
						break;	
									
					case -601: 
						msg = window['gformsrcwdi18n' + formid + '_' + fid].err601;
						break;
						
					default:
						msg = err.message;
						
				}
				
				$.prompt(msg);
							
			}
			
			function g(){
	
				$.each(j.files, function (p, o){
					
					$('#' + o.id + ' .gformsrcwdplupload-remove').click(function(){
						
						j.removeFile(o);
						
						$(this).fadeTo(fdspeed, 0, function(){
							
							$(this).css( 'display', 'none' );
							
						});
						$('#'+upf).fadeTo(fdspeed, 0, function(){
							
							$(this).css( 'display', 'none' );
							
						});
						$('#' + fl + ' .gformsrcwdplupload-filename').fadeTo(fdspeed, 0, function(){
							
							$(this).html('...').fadeTo(fdspeed, 1);
							
						});
						$('#' + cpv).fadeTo(fdspeed, 0, function(){
							
							$(this).css( 'display', 'none' );
							$(this).html('');
							
						});
						$('#' + fsz).fadeTo(fdspeed, 0, function(){
							
							$(this).css( 'display', 'none' );
							
						});
											
					});		
	
					rmvtemp();
	
				});
				
			}		
			
			$('#' + rmvcf).click(function(ev){
				
				el.find('.gformsrcwdplupload-current').fadeTo(fdspeed, 0, function(){
					
					$(this).css( 'display', 'none' );
					
					bhkbhnjop[c].refresh();
					
				});
				
				$('#'+gformsfv).val('');	
				ev.preventDefault();

				if( hdb == 'Y2' )
					$('#' + b).show();		
								
			});			
			
		}
		
	}

	$(document).bind('gform_post_render', function( event, form_id ){

		$('#gform_' + form_id + ' .gformsrcwdplupload-container').each(function(){
	
			$(this).gformsrcwdPluploader({});
				
		});

		if(typeof(gform) != "undefined")		
			gform.addFilter( 'gform_is_value_match', function( isMatch, formId, rule ){
			
				return isMatch;
				
			 } );
		
	});

	$(document).bind('gform_post_conditional_logic', function(){

		$('.gformsrcwdplupload-container').each(function(){
	
			gformsrcwd.uploadRefresh($(this));
				
		});
		
	});

})(jQuery);	