Thank you for purchasing my plugin :)

For info about installation, check the HELP folder.