=== Gravity Forms Image Choices ===
Contributors: jetsloth
Tags: admin,gravityforms,forms
Requires at least: 4.0
Tested up to: 5.1.1
Version: 1.2.11
License: GPL2
License URI: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Easily add images as choices for Radio Buttons or Checkboxes fields in your Gravity Forms, including Survey, Quiz, Product and Option fields that have their field type set to Radio Buttons or Checkboxes

== Description ==
**Gravity Forms Image Choices**

Easily add images as choices for Radio Buttons or Checkboxes fields in your Gravity Forms, including Survey, Quiz, Product and Option fields that have their field type set to Radio Buttons or Checkboxes

== Installation ==
1. Install Gravity Forms Image Choices by uploading the files to your server
2. Activate the plugin through the \'Plugins\' menu in WordPress
3. Make sure you also have Gravity Forms activated (at least v2.0)
4. Enter your license key in the Gravity Forms Image Choices settings tab through the 'Forms > Settings' menu in Wordpress
6. Read the documentation and watch our videos for more info

== Frequently Asked Questions ==

= Does this plugin rely on anything? =
Yes, you need to install the [Gravity Forms Plugin](http://gravityforms.com) for this plugin to work. And it needs to be at least v2.0
