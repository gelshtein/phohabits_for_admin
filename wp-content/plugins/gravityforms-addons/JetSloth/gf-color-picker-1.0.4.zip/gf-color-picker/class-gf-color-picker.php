<?php

//------------------------------------------

/*
// HOW TO MODIFY THE 'Pick color' label for single text field

// Add following PHP to your theme functions
add_filter('gf_colorpicker_action_label', 'my_gf_colorpicker_action_label');
function my_gf_colorpicker_action_label($value) {
	return 'Pick color';
}

// HOW TO MODIFY THE 'Pick color' label for radio button 'Other' (JS)
// Add following JS to your theme or a HTML field in the form
<script>
window.gf_colorpicker_action_label = function(val){
	return 'Pick color';
}
</script>

// HOW TO MODIFY THE 'Color' label prefix on the Pantone style
// Add following JS to your theme or a HTML field in the form
<script>
window.gf_colorpicker_pantone_label_prefix = function(val){
	return 'Color';
}
</script>

// TIP: To modify this value on individual field (Single picker only), add you own Placeholder value in the Appearance tab


// To modify the 'Other' label prefix for radio button 'Other' use GF's filter (https://docs.gravityforms.com/gform_other_choice_value/)
// Add following PHP to your theme functions
add_filter( 'gform_other_choice_value', 'gf_colorpicker_pantone_other_label', 10, 2 );
function gf_colorpicker_pantone_other_label( $placeholder, $field ) {
    return 'Custom';
}

 */

// load our custom updater if it doesn't already exist
include( dirname( __FILE__ ) . '/lib/Mexitek/PHPColors/Color.php' );
use Mexitek\PHPColors\Color;

GFForms::include_addon_framework();

class GFColorPicker extends GFAddOn {

	protected $_version = GFCP_VERSION;
	protected $_min_gravityforms_version = '2.0';

	protected $_slug = GFCP_SLUG;
	protected $_path = 'gf-color-picker/gf-color-picker.php';
	protected $_full_path = __FILE__;
	protected $_title = GFCP_NAME;
	protected $_short_title = 'Color Picker';
	protected $_url = 'https://jetsloth.com/gravity-forms-color-picker/';

	protected $_defaultSwatchStyle = 'pantone';

	/**
	 * Members plugin integration
	 */
	protected $_capabilities = array( 'gravityforms_edit_forms', 'gravityforms_edit_settings' );

	/**
	 * Permissions
	 */
	protected $_capabilities_settings_page = 'gravityforms_edit_settings';
	protected $_capabilities_form_settings = 'gravityforms_edit_forms';
	protected $_capabilities_uninstall = 'gravityforms_uninstall';

	private static $_instance = null;

	/**
	 * Get an instance of this class.
	 *
	 * @return GFColorPicker
	 */
	public static function get_instance() {
		if ( self::$_instance == null ) {
			self::$_instance = new GFColorPicker();
		}

		return self::$_instance;
	}

	private function __clone() {
	} /* do nothing */

	/**
	 * Handles anything which requires early initialization.
	 */
	public function pre_init() {
		parent::pre_init();
	}

	/**
	 * Handles hooks and loading of language files.
	 */
	public function init() {

		// add a special class to relevant fields so we can identify them later
		add_action( 'gform_field_css_class', array( $this, 'add_custom_class' ), 10, 3 );
		add_filter( 'gform_field_choice_markup_pre_render', array( $this, 'add_color_options_markup' ), 10, 4 );
		add_filter( 'gform_field_content', array( $this, 'add_single_color_picker_markup' ), 10, 3 );

		// display on entry detail
		add_filter( 'gform_entry_field_value', array( $this, 'custom_entry_field_value' ), 20, 4 );
		add_filter( 'gform_order_summary', array( $this, 'custom_order_summary_entry_field_value' ), 10, 4 );

		// display in notifications
		add_filter( 'gform_merge_tag_filter', array( $this, 'custom_notification_merge_tag' ), 11, 5 );

		add_filter('gform_register_init_scripts', array( $this, 'load_custom_css' ), 10, 4);

		parent::init();

	}

	/**
	 * Initialize the admin specific hooks.
	 */
	public function init_admin() {

		// form editor
		add_action( 'gform_field_standard_settings', array( $this, 'color_choice_field_settings' ), 10, 2 );
		add_filter( 'gform_tooltips', array( $this, 'add_color_choice_field_tooltips' ) );

		// display results on entry list
		add_filter( 'gform_entries_field_value', array( $this, 'entries_table_field_value' ), 10, 4 );

		$name = plugin_basename($this->_path);
		add_action( 'after_plugin_row_'.$name, array( $this, 'gf_plugin_row' ), 10, 2 );

		parent::init_admin();

	}

	/**
	 * The Color Picker add-on does not support logging.
	 *
	 * @param array $plugins The plugins which support logging.
	 *
	 * @return array
	 */
	public function set_logging_supported( $plugins ) {

		return $plugins;

	}


	// # SCRIPTS & STYLES -----------------------------------------------------------------------------------------------

	/**
	 * Return the scripts which should be enqueued.
	 *
	 * @return array
	 */
	public function scripts() {
		$gf_color_picker_js_deps = array( 'jquery', 'jquery-ui-sortable', 'colorjoe_js' );
		if ( wp_is_mobile() ) {
			$gf_color_picker_js_deps[] = 'jquery-touch-punch';
		}

		$scripts = array(
				array(
						'handle'   => 'gf_color_picker_form_editor_js',
						'src'      => $this->get_base_url() . '/js/gf_color_picker_form_editor.js',
						'version'  => $this->_version,
						'deps'     => array( 'jquery' ),
						'callback' => array( $this, 'localize_scripts' ),
						'enqueue'  => array(
								array( 'admin_page' => array( 'form_editor', 'plugin_settings', 'form_settings' ) ),
						),
				),
				array(
						'handle'   => 'gf_color_picker_ace_editor',
						'src'      => $this->get_base_url() . '/lib/ace/ace.js',
						'deps'     => array( 'jquery' ),
						'enqueue'  => array(
								array( 'admin_page' => array( 'plugin_settings', 'form_settings' ) ),
						),
				),
				array(
						'handle'  => 'colorjoe_js',
						'src'     => $this->get_base_url() . '/js/colorjoe.js',
						'version' => $this->_version,
						'deps'     => array( 'jquery' ),
						'enqueue' => array(
							array( 'admin_page' => array( 'form_editor', 'entry_view', 'entry_detail', 'entry_edit' ) ),
							array( 'field_types' => array( 'radio', 'checkbox', 'survey', 'poll', 'quiz', 'post_custom_field', 'product', 'option' ) ),
						),
				),
				array(
						'handle'  => 'gf_color_picker_js',
						'src'     => $this->get_base_url() . '/js/gf_color_picker.js',
						'version' => $this->_version,
						'deps'    => $gf_color_picker_js_deps,
						'callback' => array( $this, 'localize_scripts' ),
						'enqueue' => array(
								array( 'admin_page' => array( 'form_editor', 'entry_view', 'entry_detail', 'entry_edit' ) ),
								array( 'field_types' => array( 'radio', 'checkbox', 'survey', 'poll', 'quiz', 'post_custom_field', 'product', 'option' ) ),
						),
				),
		);

		return array_merge( parent::scripts(), $scripts );
	}

	/**
	 * Return the stylesheets which should be enqueued.
	 *
	 * @return array
	 */
	public function styles() {

		$styles = array(
				array(
						'handle'  => 'gf_color_picker_form_editor_css',
						'src'     => $this->get_base_url() . '/css/gf_color_picker_form_editor.css',
						'version' => $this->_version,
						'enqueue' => array(
							array('admin_page' => array( 'form_editor', 'plugin_settings', 'form_settings', 'entry_view', 'entry_detail' )),
							array('query' => 'page=gf_entries&view=entry&id=_notempty_')
						),
				),
				array(
						'handle'  => 'gf_color_picker_css',
						'src'     => $this->get_base_url() . '/css/gf_color_picker.css',
						'version' => $this->_version,
						'media'   => 'screen',
						'enqueue' => array(
							array('admin_page' => array( 'form_editor', 'entry_view', 'entry_detail' )),
							array('field_types' => array( 'radio', 'checkbox', 'survey', 'poll', 'quiz', 'post_custom_field', 'product', 'option' )),
							array('query' => 'page=gf_entries&view=entry&id=_notempty_')
						),
				),
		);

		return array_merge( parent::styles(), $styles );
	}

	function load_custom_css($form) {

		require_once( dirname( __FILE__ ) . '/inc/php-html-css-js-minifier.php' );
		$minifier = PHP_HTML_CSS_JS_Minifier::get_instance();

		$form_settings = $this->get_form_settings($form);
		$form_css_value = (isset($form_settings['gf_color_picker_custom_css'])) ? $form_settings['gf_color_picker_custom_css'] : '';
		if (!empty($form_css_value)) {
			$form_css_value_min = $minifier->minify_css($form_css_value);
			$form_css_script = '(function(){ if (typeof window.gf_color_picker_custom_css_'.$form['id'].' === "undefined") window.gf_color_picker_custom_css_'.$form['id'].' = "'.addslashes($form_css_value_min).'"; })();';
			GFFormDisplay::add_init_script($form['id'], 'gf_color_picker_custom_css_script_'.$form['id'], GFFormDisplay::ON_PAGE_RENDER, $form_css_script);
		}

		$ignore_global_css_value = (isset($form_settings['gf_color_picker_ignore_global_css'])) ? $form_settings['gf_color_picker_ignore_global_css'] : 0;
		$ignore_global_css_value_script = '(function(){ if (typeof window.gf_color_picker_ignore_global_css_'.$form['id'].' === "undefined") window.gf_color_picker_ignore_global_css_'.$form['id'].' = '.$ignore_global_css_value.'; })();';
		GFFormDisplay::add_init_script($form['id'], 'gf_color_picker_ignore_global_css_'.$form['id'], GFFormDisplay::ON_PAGE_RENDER, $ignore_global_css_value_script);

		if (empty($ignore_global_css_value)) {
			$global_css_value = $this->get_plugin_setting('gf_color_picker_custom_css_global');
			if (!empty($global_css_value)) {
				$global_css_value_min = $minifier->minify_css($global_css_value);
				$global_css_script = '(function(){ if (typeof window.gf_color_picker_custom_css_global === "undefined") window.gf_color_picker_custom_css_global = "'.addslashes($global_css_value_min).'"; })();';
				GFFormDisplay::add_init_script($form['id'], 'gf_color_picker_custom_css_global_script', GFFormDisplay::ON_PAGE_RENDER, $global_css_script);
			}
		}

		return $form;
	}


	/**
	 * Localize the strings used by the scripts.
	 */
	public function localize_scripts() {

		// Get current page protocol
		$protocol = isset( $_SERVER['HTTPS'] ) ? 'https://' : 'http://';
		// Output admin-ajax.php URL with same protocol as current page
		$params = array(
			'ajaxurl'   => admin_url( 'admin-ajax.php', $protocol ),
			'pluginUrl' => plugins_url('', __FILE__),
			'version' => GFCP_VERSION
		);
		wp_localize_script( 'gf_color_picker_form_editor_js', 'colorPickerFieldVars', $params );

		//localize strings for the js file
		$strings = array(
				'useColors'    => esc_html__( 'use colors', GFCP_TEXT_DOMAIN ),
				'colorPicker'    => esc_html__( 'Color Picker', GFCP_TEXT_DOMAIN ),
				'useColorPicker'    => esc_html__( 'Use Color Picker', GFCP_TEXT_DOMAIN ),
				'confirmColorsToggle'    => esc_html__( 'Image choices is enabled on this field. Are you sure you want to remove the image choices and use colors instead?', GFCP_TEXT_DOMAIN ),
				'selectColor'    => esc_html__( 'Select color', GFCP_TEXT_DOMAIN ),
				'changeColor'    => esc_html__( 'Change color', GFCP_TEXT_DOMAIN ),
				'removeColor'    => esc_html__( 'Remove this color', GFCP_TEXT_DOMAIN ),
				'removeAllChoices'    => esc_html__( 'Remove All Choices', GFCP_TEXT_DOMAIN ),
				'entrySettingTitle'    => esc_html__( 'Color Picker Entry / Notification Display', GFCP_TEXT_DOMAIN ),
				'entrySettingForm'    => esc_html__( 'Use Form Setting', GFCP_TEXT_DOMAIN ),
				'entrySettingValue'    => esc_html__( 'Value', GFCP_TEXT_DOMAIN ),
				'entrySettingSwatch'    => esc_html__( 'Swatch', GFCP_TEXT_DOMAIN ),
				'entrySettingText'    => esc_html__( 'Label', GFCP_TEXT_DOMAIN ),
				'entrySettingSwatchText'    => esc_html__( 'Swatch and Label', GFCP_TEXT_DOMAIN ),
				'entrySettingSwatchValue'    => esc_html__( 'Swatch and Value', GFCP_TEXT_DOMAIN ),
				'displayStyleSettingTitle'    => esc_html__( 'Color Picker Display Style', GFCP_TEXT_DOMAIN ),
				'displayStyleSettingForm'    => esc_html__( 'Use Form Setting', GFCP_TEXT_DOMAIN ),
				'displayStyleSettingShadowBox'    => esc_html__( 'Shadow Box', GFCP_TEXT_DOMAIN ),
				'displayStyleSettingPantone'    => esc_html__( 'Pantone', GFCP_TEXT_DOMAIN ),
				'displayStyleSettingCircle'    => esc_html__( 'Circle', GFCP_TEXT_DOMAIN ),
				'displayStyleSettingHorizontalBar'    => esc_html__( 'Horizontal Bar', GFCP_TEXT_DOMAIN ),
				'displayStyleSettingCompactButton'    => esc_html__( 'Compact Button', GFCP_TEXT_DOMAIN ),
				'displayStyleSettingNone'    => esc_html__( 'None', GFCP_TEXT_DOMAIN ),
				'displaySettingsTitle'    => esc_html__( 'Color Picker Display', GFCP_TEXT_DOMAIN ),
				'selectLayout'    => esc_html__( 'Colors layout', GFCP_TEXT_DOMAIN ),
				'layoutHorizontal'    => esc_html__( 'Horizontal (inline)', GFCP_TEXT_DOMAIN ),
				'layoutVertical'    => esc_html__( 'Vertical (stacked)', GFCP_TEXT_DOMAIN ),
		);
		wp_localize_script( 'gf_color_picker_form_editor_js', 'colorPickerFieldStrings', $strings );

		$cpStrings = array(
			'pickColor' => esc_html__( 'Pick color', GFCP_TEXT_DOMAIN ),
			'color' => esc_html__( 'Color', GFCP_TEXT_DOMAIN )
		);
		wp_localize_script( 'gf_color_picker_js', 'colorPickerStrings', $cpStrings );

	}


	/**
	 * Creates a settings page for this add-on.
	 */
	public function plugin_settings_fields() {

		$license = $this->get_plugin_setting('gf_color_picker_license_key');
		$status = get_option('gf_color_picker_license_status');

		$license_field = array(
			'name' => 'gf_color_picker_license_key',
			'tooltip' => esc_html__('Enter the license key you received after purchasing the plugin.', GFCP_TEXT_DOMAIN),
			'label' => esc_html__('License Key', GFCP_TEXT_DOMAIN),
			'type' => 'text',
			'input_type' => 'password',
			'class' => 'medium',
			'default_value' => '',
			'validation_callback' => array($this, 'license_validation'),
			'feedback_callback' => array($this, 'license_feedback'),
			'error_message' => esc_html__( 'Invalid license', GFCP_TEXT_DOMAIN ),
		);

		if (!empty($license) && !empty($status)) {
			$license_field['after_input'] = ($status == 'valid') ? ' License is valid' : ' Invalid or expired license';
		}

		$custom_css_global_value = $this->get_plugin_setting('gf_color_picker_custom_css_global');
		$custom_css_global_field = array(
			'name' => 'gf_color_picker_custom_css_global',
			'tooltip' => esc_html__('These styles will be loaded for all forms.<br/>Find examples at <a href="https://jetsloth.com/support/gravity-forms-color-picker/">https://jetsloth.com/support/gravity-forms-color-picker/</a>', GFCP_TEXT_DOMAIN),
			'label' => esc_html__('Custom CSS', GFCP_TEXT_DOMAIN),
			'type' => 'textarea',
			'class' => 'large',
			'default_value' => $custom_css_global_value
		);

		$fields = array(
			array(
				'title'  => esc_html__('To unlock plugin updates, please enter your license key below', GFCP_TEXT_DOMAIN),
				'fields' => array(
					$license_field
				)
			),
			array(
				'title'  => esc_html__('Enter your own css to style color swatches', GFCP_TEXT_DOMAIN),
				'fields' => array(
					$custom_css_global_field
				)
			)
		);

		return $fields;
	}

	/**
	 * Configures the settings which should be rendered on the Form Settings > Image Choices tab.
	 *
	 * @return array
	 */
	public function form_settings_fields( $form ) {

		$settings = $this->get_form_settings( $form );

		$form_display_style_value = (isset($settings['gf_color_picker_display_style'])) ? $settings['gf_color_picker_display_style'] : $this->_defaultSwatchStyle;
		$form_display_style_field = array(
			'name' => 'gf_color_picker_display_style',
			'label' => esc_html__( 'Default Color Picker Display Style', GFCP_TEXT_DOMAIN ),
			'type' => 'select',
			'class' => 'medium',
			'default_value' => 'value',
			'choices' => array(
				array(
					'value' => 'pantone',
					'label' => esc_html__('Pantone', GFCP_TEXT_DOMAIN)
				),
				array(
					'value' => 'shadow-box',
					'label' => esc_html__('Shadow Box', GFCP_TEXT_DOMAIN)
				),
				array(
					'value' => 'circle',
					'label' => esc_html__('Circle', GFCP_TEXT_DOMAIN)
				),
				array(
					'value' => 'horizontal-bar',
					'label' => esc_html__('Horizontal Bar', GFCP_TEXT_DOMAIN)
				),
				array(
					'value' => 'compact-button',
					'label' => esc_html__('Compact Button', GFCP_TEXT_DOMAIN)
				),
				array(
					'value' => 'none',
					'label' => esc_html__('None', GFCP_TEXT_DOMAIN)
				),
			)
		);
		if (!empty($form_display_style_value)) {
			$form_display_style_field['default_value'] = $form_display_style_value;
		}


		$form_choices_entry_value = (isset($settings['gf_color_picker_entry_value'])) ? $settings['gf_color_picker_entry_value'] : 'value';
		$form_choices_entry_field = array(
			'name' => 'gf_color_picker_entry_value',
			//'tooltip' => esc_html__('The selected collapsible section will be opened by default when the form loads.', GFCS_TEXT_DOMAIN),
			'label' => esc_html__('Default Entry / Notification Display', GFCP_TEXT_DOMAIN),
			'type' => 'select',
			'class' => 'medium',
			'default_value' => 'value',
			'choices' => array(
				array(
					'value' => 'value',
					'label' => esc_html__('Value (Gravity Forms default)', GFCP_TEXT_DOMAIN)
				),
				array(
					'value' => 'swatch',
					'label' => esc_html__('Swatch', GFCP_TEXT_DOMAIN)
				),
				array(
					'value' => 'text',
					'label' => esc_html__('Label', GFCP_TEXT_DOMAIN)
				)
			)
		);
		if (!empty($form_choices_entry_value)) {
			$form_choices_entry_field['default_value'] = $form_choices_entry_value;
		}

		$form_custom_css_value = (isset($settings['gf_color_picker_custom_css'])) ? $settings['gf_color_picker_custom_css'] : '';
		$form_custom_css_field = array(
			'name' => 'gf_color_picker_custom_css',
			'tooltip' => esc_html__('These styles will be loaded for this form only.<br/>Find examples at <a href="https://jetsloth.com/support/gravity-forms-color-picker/">https://jetsloth.com/support/gravity-forms-color-picker/</a>', GFCP_TEXT_DOMAIN),
			'label' => esc_html__('Custom CSS', GFCP_TEXT_DOMAIN),
			'type' => 'textarea',
			'class' => 'large',
			'default_value' => $form_custom_css_value
		);

		$form_ignore_global_css_value = (isset($settings['gf_color_picker_ignore_global_css']) && $settings['gf_color_picker_ignore_global_css'] == 1) ? 1 : 0;
		$form_ignore_global_css_field = array(
			'name' => 'gf_color_picker_ignore_global_css',
			'label' => '',
			'type' => 'checkbox',
			'choices' => array(
				array(
					'label' => esc_html__('Ignore Global Custom CSS for this form?', GFCP_TEXT_DOMAIN),
					'tooltip' => esc_html__('If checked, the custom css entered in the global settings won\'t be loaded for this form.', GFCP_TEXT_DOMAIN),
					'name' => 'gf_color_picker_ignore_global_css'
				)
			)
		);
		if (!empty($form_ignore_global_css_value)) {
			$form_ignore_global_css_field['choices'][0]['default_value'] = 1;
		}

		return array(
			array(
				'title' => esc_html__( 'Color Picker', GFCP_TEXT_DOMAIN ),
				'fields' => array(
					$form_display_style_field,
					$form_choices_entry_field,
					$form_custom_css_field,
					$form_ignore_global_css_field
				)
			)
		);

	}



	/**
	 * Format the field values for entry list page so they show the swatches instead of values.
	 *
	 * @param string|array $value The field value.
	 * @param int $form_id The ID of the form currently being processed.
	 * @param string $field_id The ID of the field currently being processed.
	 * @param array $entry The entry object currently being processed.
	 *
	 * @return string|array
	 */
	public function entries_table_field_value( $value, $form_id, $field_id, $entry ) {
		if ( ! rgblank( $value ) ) {
			$form_meta = RGFormsModel::get_form_meta( $form_id );
			$field     = RGFormsModel::get_field( $form_meta, $field_id );

			$form = GFAPI::get_form($form_id);

			return $this->maybe_format_field_values( $value, $field, $form, $entry );
		}

		return $value;
	}

	/**
	 * Format the field values on the entry detail page so they show the swatches instead of values.
	 *
	 * @param string|array $value The field value.
	 * @param GF_Field $field The field currently being processed.
	 * @param array $entry The entry object currently being processed.
	 * @param array $form The form object currently being processed.
	 *
	 * @return string|array
	 */
	public function custom_entry_field_value( $value, $field, $entry, $form ) {
		return ! rgblank( $value ) ? $this->maybe_format_field_values( $value, $field, $form, $entry ) : $value;
	}

	public function custom_order_summary_entry_field_value( $markup, $form, $entry, $order_summary, $format = 'html' ) {
		if ($format == 'text') {
			return $markup;
		}

		$style = 'width:80px; height:auto; max-width:100%;';

		// Products by default display value (not text/label)
		// Eg: Selected Product Value
		// Product Options by default display both the main Field Label and the selected Choice Value
		// Eg: Product Option Field Label: Selected Option Value

		$contains_color_picker_fields = false;

		// ---------
		$settings = $this->get_form_settings( $form );
		$form_choices_entry_setting = (isset($settings['gf_color_picker_entry_value'])) ? $settings['gf_color_picker_entry_value'] : 'value';
		$form_swatch_style_setting = (isset($settings['gf_color_picker_display_style'])) ? $settings['gf_color_picker_display_style'] : $this->_defaultSwatchStyle;
		// ---------

		$fields_id_lookup = array();
		$fields_label_lookup = array();
		foreach($form['fields'] as $field) {
			$fields_id_lookup[$field->id] = $field;
			$fields_label_lookup[$field->label] = $field;
		}

		$product_summary_color_choices = array();
		foreach ($order_summary['products'] as $product_field_id => $product) {

			$data = array(
				'product_field_id' => $product_field_id,
				'product_field_label' => '',
				'product_summary_display_value' => $product['name'],
				'product_field_selected_value' => $product['name'],
				'product_field_selected_price' => $product['price'],
				'product_field_selected_label' => '',
				'product_field_selected_color' => '',
				'product_field_swatch_style' => $form_swatch_style_setting,
				'product_field_entry_value_type' => $form_choices_entry_setting,
				'options' => array()
			);
			
			if (isset($fields_id_lookup[$product_field_id])) {
				$field = $fields_id_lookup[$product_field_id];
				if ( is_object( $field ) && property_exists($field, 'colorPicker_senableColor') && $field->colorPicker_enableColors) {
					$field_choices_entry_setting = (property_exists($field, 'colorPicker_entrySetting') && !empty($field->colorPicker_entrySetting)) ? $field->colorPicker_entrySetting : 'form_setting';
					$field_swatch_style_setting = (property_exists($field, 'colorPicker_displayStyleSetting') && !empty($field->colorPicker_displayStyleSetting)) ? $field->colorPicker_displayStyleSetting : 'form_setting';
					$data['product_field_label'] = $field->label;
					$data['product_field_selected_label'] = RGFormsModel::get_choice_text($field, $data['product_field_selected_value']);
					$data['product_field_entry_value_type'] = ($field_choices_entry_setting == 'form_setting') ? $form_choices_entry_setting : $field_choices_entry_setting;
					$data['product_field_swatch_style'] = ($field_swatch_style_setting == 'form_setting') ? $form_swatch_style_setting : $field_swatch_style_setting;
					$data['product_field_selected_color'] = $this->get_choice_color_value($field, $data['product_field_selected_value']);
					$contains_color_picker_fields = true;
				}
			}
			
			if (isset($product['options']) && !empty($product['options'])) {
				foreach($product['options'] as $option) {
					$option_field_label = $option['field_label'];
					$option_data = array(
						'option_field_label' => $option_field_label,
						'option_summary_display_value' => $option['option_label'],
						'option_field_selected_value' => $option['option_name'],
						'option_field_selected_price' => $option['price'],
						'option_field_selected_label' => '',
						'option_field_selected_color' => '',
						'option_field_swatch_style' => $form_swatch_style_setting,
						'option_field_entry_value_type' => $form_choices_entry_setting
					);

					if (isset($fields_label_lookup[$option_field_label])) {
						$field = $fields_label_lookup[$option_field_label];
						if ( is_object( $field ) && property_exists($field, 'colorPicker_enableColors') && $field->colorPicker_enableColors ) {
							$field_choices_entry_setting = (property_exists($field, 'colorPicker_entrySetting') && !empty($field->colorPicker_entrySetting)) ? $field->colorPicker_entrySetting : 'form_setting';
							$field_swatch_style_setting = (property_exists($field, 'colorPicker_displayStyleSetting') && !empty($field->colorPicker_displayStyleSetting)) ? $field->colorPicker_displayStyleSetting : 'form_setting';
							$option_data['option_field_selected_label'] = RGFormsModel::get_choice_text($field, $option_data['option_field_selected_value']);
							$option_data['option_field_entry_value_type'] = ($field_choices_entry_setting == 'form_setting') ? $form_choices_entry_setting : $field_choices_entry_setting;
							$option_data['option_field_swatch_style'] = ($field_swatch_style_setting == 'form_setting') ? $form_swatch_style_setting : $field_swatch_style_setting;
							$option_data['option_field_selected_color'] = $this->get_choice_color_value($field, $option_data['option_field_selected_value']);
							$contains_color_picker_fields = true;
						}
					}

					array_push($data['options'], $option_data);
				}
			}
			array_push($product_summary_color_choices, $data);
		}

		error_log( print_r(array('contains_color_picker_fields' => $contains_color_picker_fields), true) );
		error_log( print_r(array('product_summary_color_choices' => $product_summary_color_choices), true) );
		error_log( print_r(array('debug' => $data), true) );

		if ($contains_color_picker_fields) {
			$color_entry_setting_values = array('swatch');

			foreach($product_summary_color_choices as $summary_item) {
				if (
				in_array($summary_item['product_field_entry_value_type'], $color_entry_setting_values)
				&& !empty($summary_item['product_field_selected_color'])) {

					$replacement_markup = '';

					if ($summary_item['product_field_entry_value_type'] == 'swatch') {
						$replacement_markup = $this->get_choice_swatch_item_markup($summary_item['product_field_selected_color'], $summary_item['product_field_selected_label'], $summary_item['product_field_swatch_style']);
						/*
						$replacement_markup = implode("", array(
							'<span class="gf-color-picker-entry-swatch" style="display: inline-block;">',
								'<span class="gf-color-picker-entry-swatch-color" style="background-color:'.$summary_item['product_field_selected_color'].'; '.$style.'"></span>',
								'<span class="gf-color-picker-entry-swatch-text">'.$summary_item['product_field_selected_label'].'</span>',
							'</span>'
						));
						*/
					}

					if (!empty($replacement_markup)) {
						if (strpos($markup, '<span class="product_name">'.$summary_item['product_summary_display_value'].'</span>') === FALSE) {
							$markup = str_replace(
								$summary_item['product_summary_display_value'],
								$replacement_markup,
								$markup
							);
						}
						else {
							$markup = str_replace(
								'<span class="product_name">'.$summary_item['product_summary_display_value'].'</span>',
								$replacement_markup,
								$markup
							);
						}
					}

				}
				else if ($summary_item['product_field_entry_value_type'] == 'text') {
					// Text
					$markup = str_replace(
						$summary_item['product_summary_display_value'],
						$summary_item['product_field_selected_label'],
						$markup
					);
				}


				foreach($summary_item['options'] as $option_item) {
					if (in_array($option_item['option_field_entry_value_type'], $color_entry_setting_values)) {
						$replacement_markup = '';
						if ($option_item['option_field_entry_value_type'] == 'swatch') {
							$replacement_markup = $this->get_choice_swatch_item_markup($option_item['option_field_selected_color'], $option_item['option_field_selected_label'], $option_item['option_field_swatch_style']);
							/*
							$replacement_markup = implode("", array(
								'<span class="gf-color-picker-entry-swatch" style="display: inline-block;">',
									'<span class="gf-color-picker-entry-swatch-color" style="background-color:'.$option_item['option_field_selected_color'].'; '.$style.'"></span>',
									'<span class="gf-color-picker-entry-swatch-text">'.$option_item['option_field_selected_label'].'</span>',
								'</span>'
							));
							*/
						}

						if (!empty($replacement_markup)) {
							$markup = str_replace(
								$option_item['option_summary_display_value'],
								$replacement_markup,
								$markup
							);
						}

					}
					else if ($option_item['option_field_entry_value_type'] == 'text') {
						$markup = str_replace(
							$option_item['option_summary_display_value'],
							$option_item['option_field_label'] . ': ' . $option_item['option_field_selected_label'],
							$markup
						);
					}
				}
			}

		}

		return $markup;
	}

	public function get_choice_color_value($field, $value, $choice_value_or_text = 'value') {
		$color = '';

		if ($choice_value_or_text != 'value' && $choice_value_or_text != 'text') {
			$choice_value_or_text = 'value';
		}

		foreach($field->choices as $choice) {
			if ($choice[$choice_value_or_text] != $value) {
				continue;
			}
			if (!empty($choice['colorPicker_color'])) {
				$color = $choice['colorPicker_color'];
			}
		}
		return $color;
	}

	public function get_swatch_inline_styles($swatch_style = '', $is_light = false) {
		$inline_styles = array(
			'swatch' => '',
			'swatch-color-wrap' => '',
			'swatch-color' => '',
			'swatch-color-icon' => '',
			'swatch-text-wrap' => '',
			'swatch-text-prefix' => '',
			'swatch-text' => '',
			'swatch-text-suffix' => '',
		);

		if ($swatch_style == 'pantone') {

			$inline_styles['swatch'] = implode(' ', array(
				'cursor: default;',
				'box-sizing: border-box;',
				'position: relative;',
				'width: 88px;',
				'height: 115px;',
				'border-radius: 0 3px 3px 0;',
				'border: 1px solid #fafafa;',
				'box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.05);',
				'background: #fff;',
				'display: inline-block;',
			));
			$inline_styles['swatch-color-wrap'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: inline-block;',
				'position: relative;',
				'width: 100%;',
				'border-radius: 0;',
				'height: 78px;',
			));
			$inline_styles['swatch-color'] = implode(' ', array(
				'box-sizing: border-box;',
				'position: relative;',
				'display: block;',
				'width: 100%;',
				'height: 100%;',
            ));
			$inline_styles['swatch-color-icon'] = implode(' ', array(
				'display:none;'
			));
			$inline_styles['swatch-text-wrap'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: block;',
				'width: 100%;',
				'height: auto;',
				'min-height: 38px;',
				'padding: 7px;',
				'position: absolute;',
				'left: 0;',
				'bottom: 0;',
				'line-height: 1.5;',
				'color: #121212;',
				'font-family: Helvetica Neue, Helvetica, Arial, sans-serif;',
				'font-size: 9px;',
				'font-weight: normal;',
			));
			$inline_styles['swatch-text-prefix'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: block;',
				'text-transform: uppercase;',
				'font-weight: bold;',
            ));
			$inline_styles['swatch-text'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: block;',
			));
			$inline_styles['swatch-text-suffix'] = implode(' ', array(
				'display:none;'
			));

		}
		else if ($swatch_style == 'shadow-box') {

			$inline_styles['swatch'] = implode(' ', array(
				'cursor: default;',
				'box-sizing: border-box;',
				'display: inline-block;',
				'width: 90px;',
				'height: 120px;',
				'border-radius: 4px;',
				'border: 1px solid #e3e8eb;',
				'background: #fff;',
				'box-shadow: 0 10px 20px 0 rgba(93,124,181,.09), 0 5px 12px -3px rgba(0,0,0,.07);',
			));
			$inline_styles['swatch-color-wrap'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: inline-block;',
				'position: relative;',
				'width: 100%;',
				'height: 100%;',
			));
			$inline_styles['swatch-color'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: block;',
				'width: 80px;',
				'height: 110px;',
				'transform: translate(5px, 5px);',
			));
			$inline_styles['swatch-color-icon'] = implode(' ', array(
				'display:none;'
			));
			$inline_styles['swatch-text-wrap'] = implode(' ', array(
				'box-sizing: border-box;',
				'position: relative;',
				'bottom: 30px;',
				'padding: 0;',
				'margin: 0;',
				'font-size: 9px;',
				'line-height: 1.4;',
				'font-family: Helvetica Neue, Helvetica, Arial, sans-serif;',
				'color: #ffffff;',
				'text-align: center;',
				'font-weight: normal;',
			));
			$inline_styles['swatch-text-prefix'] = implode(' ', array(
				'display:none;'
			));
			$inline_styles['swatch-text'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: block;',
			));
			$inline_styles['swatch-text-suffix'] = implode(' ', array(
				'display:none;'
			));

			if ($is_light) {
				$inline_styles['swatch-text-wrap'] .= ' color: #121212;';
			}

		}
		else if ($swatch_style == 'circle') {

			$inline_styles['swatch'] = implode(' ', array(
				'box-sizing: border-box;',
				'cursor: default;',
				'position: relative;',
				'display: inline-block;',
				'text-align: center;',
			));
			$inline_styles['swatch-color-wrap'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: block;',
				'width: 50px;',
				'height: 50px;',
				'border-radius: 50%;',
				'margin: 0 auto 10px;',
				'background: transparent;',
				'box-shadow: 0 3px 6px 2px rgba(0,0,0, 0.04);',
			));
			$inline_styles['swatch-color'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: block;',
				'position: relative;',
				'width: 42px;',
				'height: 42px;',
				'border-radius: 50%;',
				'transform: translate(4px, 4px);',
			));
			$inline_styles['swatch-color-icon'] = implode(' ', array(
				'box-sizing: border-box;',
			));
			$inline_styles['swatch-text-wrap'] = implode(' ', array(
				'box-sizing: border-box;',
				'position: relative;',
				'padding: 0;',
				'margin: 0 auto;',
				'font-size: 9px;',
				'line-height: 1.3;',
				'display: block;',
				'font-family: Helvetica Neue, Helvetica, Arial, sans-serif;',
				'color: #121212;',
				'text-align: center;',
				'font-weight: normal;',
			));
			$inline_styles['swatch-text-prefix'] = implode(' ', array(
				'display:none;'
			));
			$inline_styles['swatch-text'] = implode(' ', array(
				'box-sizing: border-box;',
			));
			$inline_styles['swatch-text-suffix'] = implode(' ', array(
				'display:none;'
			));

		}
		else if ($swatch_style == 'horizontal-bar') {

			$inline_styles['swatch'] = implode(' ', array(
				'box-sizing: border-box;',
				'cursor: default;',
				'position: relative;',
				'vertical-align: top;',
				'display: inline-block;',
				'width: auto;',
				'min-width: 120px;',
				'height: 30px;',
				'border: 1px solid #e2e8eb;',
				'border-radius: 4px;',
				'background-color: #fff;',
				'box-shadow: 0 10px 18px 0 rgba(93,124,181,.09), 0 2px 6px -1px rgba(0,0,0,.07);',
			));
			$inline_styles['swatch-color-wrap'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: inline-block;',
				'position: absolute;',
				'top: 0;',
				'right: 0;',
				'width: 30px;',
				'height: 100%;',
				'vertical-align: top;',
            ));
			$inline_styles['swatch-color'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: block;',
				'position: relative;',
				'width: 100%;',
				'height: 100%;',
			));
			$inline_styles['swatch-color-icon'] = implode(' ', array(
				'display:none;'
			));
			$inline_styles['swatch-text-wrap'] = implode(' ', array(
				'box-sizing: border-box;',
				'position: relative;',
				'color: #121212;',
				'font-size: 9px;',
				'line-height: 1.3;',
				'vertical-align: top;',
				'padding: 9px 12px;',
				'margin-right: 30px;',
				'margin-left: 0;',
				'display: inline-block;',
				'font-family: Helvetica Neue, Helvetica, Arial, sans-serif;',
				'font-weight: normal;',
				'text-align: left;',
			));
			$inline_styles['swatch-text-prefix'] = implode(' ', array(
				'display:none;'
			));
			$inline_styles['swatch-text'] = implode(' ', array(
				'box-sizing: border-box;',
				'white-space: nowrap;',
			));
			$inline_styles['swatch-text-suffix'] = implode(' ', array(
				'display:none;'
			));

		}
		else if ($swatch_style == 'compact-button') {

			$inline_styles['swatch'] = implode(' ', array(
				'box-sizing: border-box;',
				'cursor: default;',
				'position: relative;',
				'vertical-align: top;',
				'display: inline-block;',
				'cursor: pointer;',
				'width: auto;',
				'min-width: 90px;',
				'height: 30px;',
				'box-shadow: 0 1px 0 #ccc;',
				'border: 1px solid #ccc;',
				'border-radius: 4px;',
			));
			$inline_styles['swatch-color-wrap'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: inline-block;',
				'position: absolute;',
				'left: 0;',
				'top: 0;',
				'width: 25px;',
				'height: 100%;',
				'border-right: 1px solid #ccc;',
				'vertical-align: top;',
			));
			$inline_styles['swatch-color'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: block;',
				'width: 100%;',
				'height: 100%;',
			));
			$inline_styles['swatch-color-icon'] = implode(' ', array(
				'display:none;'
			));
			$inline_styles['swatch-text-wrap'] = implode(' ', array(
				'box-sizing: border-box;',
				'display: inline-block;',
				'text-align: left;',
				'font-weight: normal;',
				'font-family: Helvetica Neue, Helvetica, Arial, sans-serif;',
				'position: relative;',
				'color: #121212;',
				'font-size: 9px;',
				'line-height: 1.3;',
				'vertical-align: middle;',
				'padding: 3px 7px;',
				'margin-left: 25px;',
				'margin-right: 0;',
			));
			$inline_styles['swatch-text-prefix'] = implode(' ', array(
				'display:none;'
			));
			$inline_styles['swatch-text'] = implode(' ', array(
				'box-sizing: border-box;',
				'white-space: nowrap;',
			));
			$inline_styles['swatch-text-suffix'] = implode(' ', array(
				'display:none;'
			));

		}

		return $inline_styles;

	}

	public function get_choice_swatch_item_markup($color = '', $text_value = '', $swatch_style = '', $modifier = '') {

		$swatch_style_name = (!empty($modifier) && strlen($modifier) > 6 && substr($modifier, 0, 7) == 'swatch_') ? substr($modifier, 7) : $swatch_style;
		if (empty($swatch_style_name)) {
			$swatch_style_name = $this->_defaultSwatchStyle;// default
		}

		$colorUtil = new Color($color);
		$inline_styles = $this->get_swatch_inline_styles($swatch_style_name, $colorUtil->isLight());
		$inline_styles['swatch-color'] .= ' background-color:'.$color.';';

		$prefix = '';
		if ($swatch_style_name == 'pantone') {
			// TODO: Change the control of this from the JS function to the PHP filter
			$prefix = apply_filters('gf_colorpicker_pantone_label_prefix', __('Color', GFCP_TEXT_DOMAIN));
		}

		$markup = implode('', array(
			'<span style="display: inline-block; vertical-align: top; margin: 0 10px 10px 0; max-width:100%;">',// entry item wrap
				'<span style="max-width:100%; '.$inline_styles['swatch'].'">',// swatch
	                '<span style="'.$inline_styles['swatch-color-wrap'].'">',// swatch color wrapx
	                    '<span style="'.$inline_styles['swatch-color'].'"><i></i></span>',// swatch color
	                '</span>',
	                '<span style="'.$inline_styles['swatch-text-wrap'].'">',// swatch text wrap
	                    '<span style="'.$inline_styles['swatch-text-prefix'].'">'.$prefix.'</span>',// swatch text prefix
	                    '<span style="'.$inline_styles['swatch-text'].'">'.$text_value.'</span>',// swatch text
	                    '<span style="'.$inline_styles['swatch-text-suffix'].'"></span>',// swatch text suffix
	                '</span>',
				'</span>',
			'</span>',
		));

		return $markup;
	}

	public function wrap_choice_swatches_markup($choice_swatches_markup = array()) {
		array_unshift($choice_swatches_markup, '<span style="display: block; text-align: left;">');
		array_push($choice_swatches_markup, '</span>');
		return implode('', $choice_swatches_markup);
	}

	/**
	 * If the field has color choices then replace the choice value with the swatch preview.
	 *
	 * @param string $value The current merge tag value to be filtered. Replace it with any other text to replace the merge tag output, or return “false” to disable this field’s merge tag output.
	 * @param string $merge_tag If the merge tag being executed is an individual field merge tag (i.e. {Name:3}), this variable will contain the field’s ID. If not, this variable will contain the name of the merge tag (i.e. all_fields)
	 * @param string $modifier The string containing any modifiers for this merge tag
	 * @param Object $field The current field.
	 * @param mixed $raw_value The raw value submitted for this field.
	 *
	 * @return string
	 */

	public function custom_notification_merge_tag($value, $merge_tag, $modifier, $field, $raw_value) {

		if ( ($merge_tag != 'all_fields' && substr($modifier, 0, 5) != 'swatch') ) {
			return $value;
		}

		if ( !is_object( $field ) || !property_exists($field, 'colorPicker_enableColors') || empty($field->colorPicker_enableColors)) {
			return $value;
		}

		// ---------
		$form = GFAPI::get_form( $field->formId );
		$settings = $this->get_form_settings( $form );

		$form_choices_entry_setting = (isset($settings['gf_color_picker_entry_value'])) ? $settings['gf_color_picker_entry_value'] : 'value';
		$field_choices_entry_setting = (property_exists($field, 'colorPicker_entrySetting') && !empty($field->colorPicker_entrySetting)) ? $field->colorPicker_entrySetting : 'form_setting';
		$field_entry_value_type = ($field_choices_entry_setting == 'form_setting') ? $form_choices_entry_setting : $field_choices_entry_setting;

		$form_swatch_style_setting = (isset($settings['gf_color_picker_display_style'])) ? $settings['gf_color_picker_display_style'] : $this->_defaultSwatchStyle;
		$field_swatch_style_setting = (property_exists($field, 'colorPicker_displayStyleSetting') && !empty($field->colorPicker_displayStyleSetting)) ? $field->colorPicker_displayStyleSetting : 'form_setting';
		$field_swatch_style = ($field_swatch_style_setting == 'form_setting') ? $form_swatch_style_setting : $field_swatch_style_setting;

		$color_entry_setting_values = array('swatch');
		// ---------

		if ($field_entry_value_type == 'value' || !in_array($field_entry_value_type, $color_entry_setting_values)) {
			return $value;
		}

		$type_property = ($field->type == 'survey' || $field->type == 'poll' || $field->type == 'quiz' || $field->type == 'post_custom_field' || $field->type == 'product' || $field->type == 'option') ? 'inputType' : 'type';
		$text = RGFormsModel::get_choice_text($field, $value);
		$color = '';

		$is_swatch_specific_modifier = ($merge_tag != 'all_fields' && !empty($modifier) && substr($modifier, 0, 5) == 'swatch');

		if ($field[$type_property] == 'text' && property_exists($field, 'colorPicker_color') && !empty($field->colorPicker_color) && $field_entry_value_type == 'swatch') {
			// single picker (text field)

			$color = $field->colorPicker_color;
			$text = $color;
			$swatch_item_markup = '';
			if ($is_swatch_specific_modifier) {
				$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style, $modifier);
			}
			else if ($field_entry_value_type == 'swatch') {
				$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
			}

			if (!empty($swatch_item_markup)) {
				$value = $swatch_item_markup;
			}

		}
		else if ($field[$type_property] == 'checkbox' && strpos($value, ', ') !== FALSE) {
			// multiple selections
			$ordered_values = explode(', ', $value);

			if (is_array($ordered_values)) {
				$return_colors = array();
				$return_strings = array();
				foreach ($ordered_values as $ordered_value) {
					$color = $this->get_choice_color_value($field, $ordered_value);
					$text = RGFormsModel::get_choice_text($field, $ordered_value);

					if ($is_swatch_specific_modifier) {
						$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style, $modifier);
						array_push($return_colors, $swatch_item_markup);
					}
					else if ($field_entry_value_type == 'text') {
						array_push($return_strings, $text);
					}
					else if (!empty($color)) {
						$swatch_item_markup = '';
						if ($field_entry_value_type == 'swatch') {
							$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
						}
						array_push($return_colors, $swatch_item_markup);
					}

				}

				if (!empty($return_colors)) {
					$value = implode(" ", $return_colors);
				}
				else {
					$value = implode(', ', $return_strings);
				}

			}

		}
		else {
			// the field is either a radio button type, or a checkbox with a single selection
			if ($field->type == 'checkbox' || ($field->type == 'poll' && $field->inputType == 'checkbox') || ($field->type == 'survey' && $field->inputType == 'checkbox') ) {

				// The checkbox field value is an unordered list HTML (<ul class='bulleted'><li>First Choice</li><li>Second Choice</li></ul>)
				// so just grab the actual values

				$checkbox_text_values = $field->get_value_entry_detail($raw_value, '', true, 'text');
				$return_colors = array();
				$return_strings = array();

				foreach ($raw_value as $key => $choice_value) {
					if (!empty($choice_value)) {
						$color = $this->get_choice_color_value($field, $choice_value);
						$text = RGFormsModel::get_choice_text($field, $choice_value);

						if ($is_swatch_specific_modifier) {
							$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style, $modifier);
							array_push($return_colors, $swatch_item_markup);
						}
						else if ($field_entry_value_type == 'text') {
							array_push($return_strings, $text);
						}
						else if (!empty($color)) {
							$swatch_item_markup = '';
							if ($field_entry_value_type == 'swatch') {
								$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
							}
							array_push($return_colors, $swatch_item_markup);
						}
					}
				}

				if (!empty($return_colors)) {
					$value = implode(" ", $return_colors);
				}
				else {
					$value = implode(', ', $return_strings);
				}

			}
			else if ($field->type == 'radio' || ($field->type == 'poll' && $field->inputType == 'radio') || ($field->type == 'survey' && $field->inputType == 'radio') ) {

				$swatch_item_markup = '';
				$choice_value = ($field->type == 'survey') ? $raw_value : $value;

				if ($field->type == 'poll') {
					$color = $this->get_choice_color_value($field, $value, 'text');
				}
				else if ($field->type == 'survey') {
					$color = $this->get_choice_color_value($field, $raw_value);
				}
				else {
					$color = $this->get_choice_color_value($field, $value);
				}

				if ($is_swatch_specific_modifier) {
					$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style, $modifier);
				}
				else if ($field_entry_value_type == 'text') {
					$value = $text;
				}
				else if (!empty($color)) {
					if ($field_entry_value_type == 'swatch') {
						$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
					}
				}

				if (!empty($swatch_item_markup)) {
					$value = $swatch_item_markup;
				}

			}
			else if ($field->type == 'product') {

				// product field IF NOT FREE - single selection - saved as
				// Value ($Price)
				// Eg: Choice Value ($20.00)

				// product field IF FREE - single selection - saved as
				// Value
				// Eg: Choice Value

				if (strpos($value, '(') === FALSE && strpos($value, ')') === FALSE) {
					// FREE
					$color = $this->get_choice_color_value($field, $value);
					$swatch_item_markup = '';

					if ($is_swatch_specific_modifier) {
						$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style, $modifier);
					}
					else if ($field_entry_value_type == 'text') {
						$value = $text;
					}
					else if (!empty($color)) {
						if ($field_entry_value_type == 'swatch') {
							$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
						}
					}

					if (!empty($swatch_item_markup)) {
						$value = $swatch_item_markup;
					}
				}
				else {
					// NOT FREE
					$value_without_price = trim(substr($value, 0, strrpos($value, '(')));
					$color = $this->get_choice_color_value($field, $value_without_price);
					$swatch_item_markup = '';

					if ($is_swatch_specific_modifier) {
						$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style, $modifier);
					}
					else if ($field_entry_value_type == 'text') {
						$value = $text;
					}
					else if (!empty($color)) {
						if ($field_entry_value_type == 'swatch') {
							$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
						}
					}

					if (!empty($swatch_item_markup)) {
						$value = $swatch_item_markup;
					}
				}

			}
			else if ($field->type == 'option') {

				$color = $this->get_choice_color_value($field, $value);
				$swatch_item_markup = '';

				if (!empty($color)) {
					$value = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style, $modifier);
				}

				if ($is_swatch_specific_modifier) {
					$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style, $modifier);
				}
				else if ($field_entry_value_type == 'text') {
					$value = $text;
				}
				else if (!empty($color)) {
					if ($field_entry_value_type == 'swatch') {
						$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
					}
				}

				if (!empty($swatch_item_markup)) {
					$value = $swatch_item_markup;
				}

			}
		}

		return $value;

	}


	/**
	 * If the field has color choices then replace the choice value with the swatch preview.
	 *
	 * @param string $value The field value.
	 * @param GF_Field|null $field The field object being processed or null.
	 * @param array $form The form object currently being processed.
	 * @param array $entry The entry object currently being processed.
	 *
	 * @return string
	 */

	public function maybe_format_field_values( $value, $field, $form, $entry ) {

		if (!isset($field) || empty($field)) {
			return $value;
		}


		// ---------
		$settings = $this->get_form_settings( $form );
		$form_choices_entry_setting = (isset($settings['gf_color_picker_entry_value'])) ? $settings['gf_color_picker_entry_value'] : 'value';
		$field_choices_entry_setting = (property_exists($field, 'colorPicker_entrySetting') && !empty($field->colorPicker_entrySetting)) ? $field->colorPicker_entrySetting : 'form_setting';
		$field_entry_value_type = ($field_choices_entry_setting == 'form_setting') ? $form_choices_entry_setting : $field_choices_entry_setting;

		$form_swatch_style_setting = (isset($settings['gf_color_picker_display_style'])) ? $settings['gf_color_picker_display_style'] : $this->_defaultSwatchStyle;
		$field_swatch_style_setting = (property_exists($field, 'colorPicker_displayStyleSetting') && !empty($field->colorPicker_displayStyleSetting)) ? $field->colorPicker_displayStyleSetting : 'form_setting';
		$field_swatch_style = ($field_swatch_style_setting == 'form_setting') ? $form_swatch_style_setting : $field_swatch_style_setting;

		$color_entry_setting_values = array('swatch');
		// ---------

		$real_value = RGFormsModel::get_lead_field_value( $entry, $field );

		if ( is_object( $field ) && property_exists($field, 'colorPicker_enableColors') && $field->colorPicker_enableColors && $field_entry_value_type != 'value' ) {
			$type_property = ($field->type == 'survey' || $field->type == 'poll' || $field->type == 'quiz' || $field->type == 'post_custom_field' || $field->type == 'product' || $field->type == 'option') ? 'inputType' : 'type';

			if ($field[$type_property] == 'text') {
				$color = $value;
				$text = $value;
				if ($field_entry_value_type == 'swatch') {
					$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
					$value = $this->wrap_choice_swatches_markup(array($swatch_item_markup));
				}
			}
			if ($field[$type_property] == 'checkbox' && strpos($value, ', ') !== FALSE) {
				// Product field doesn't have checkboxes, only radio
				// Option field has both

				// multiple selections
				$ordered_values = (!empty($value)) ? explode(', ', $value) : '';
				if (is_array($ordered_values)) {
					$return_strings = array();
					$return_colors = array();
					foreach ($ordered_values as $ordered_value) {
						if ($field->type != 'option') {
							$color = $this->get_choice_color_value($field, $ordered_value);
							$text = RGFormsModel::get_choice_text($field, $ordered_value);
							if ($field_entry_value_type == 'text') {
								array_push($return_strings, $text);
							}
							else if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($color)) {
								$swatch_item_markup = '';
								if ($field_entry_value_type == 'swatch') {
									$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
								}
								array_push($return_colors, $swatch_item_markup);
							}
						}
						else {
							// product option field CHECKBOX - saved as
							// Value|Price
							// Eg: Choice Value|0

							list($name, $price) = explode("|", $value);
							$color = $this->get_choice_color_value($field, $name);
							$text = RGFormsModel::get_choice_text($field, $name);

							if ($field_entry_value_type == 'text') {
								array_push($return_strings, $text);
							}
							else if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($color)) {
								$swatch_item_markup = '';
								if ($field_entry_value_type == 'swatch') {
									$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
								}
								array_push($return_colors, $swatch_item_markup);
							}

						}
					}

					if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($return_colors)) {
						$value = $this->wrap_choice_swatches_markup($return_colors);
					}
					else {
						$value = implode(', ', $return_strings);
					}
				}

			}
			else {

				// either a radio, or a checkbox with a single selection
				if ($field->type == 'checkbox') {

					// When on the View Entry page, checkbox field is unordered list HTML
					// so just grab the real values
					$checkbox_text_values = $field->get_value_entry_detail($real_value, '', true, 'text');

					$return_strings = array();
					$return_colors = array();

					foreach ($real_value as $key => $choice_value) {
						if (!empty($choice_value)) {
							$color = $this->get_choice_color_value($field, $choice_value);
							$text = RGFormsModel::get_choice_text($field, $choice_value);
							if ($field_entry_value_type == 'text') {
								array_push($return_strings, $text);
							}
							else if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($color)) {
								$swatch_item_markup = '';
								if ($field_entry_value_type == 'swatch') {
									$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
								}
								array_push($return_colors, $swatch_item_markup);
							}

						}
					}

					if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($return_colors)) {
						$value = $this->wrap_choice_swatches_markup($return_colors);
					}
					else {
						if (!empty($return_strings)) {
							$markup = '<ul class="bulleted">';
							foreach ($return_strings as $return_value) {
								$markup .= '<li>' . $return_value . '</li>';
							}
							$markup .= '</ul>';
							$value = $markup;
						}
						else {
							$value = implode(', ', $return_strings);
						}
					}

				}
				else if ($field->type == 'quiz' && $field->is_entry_detail()) {

					// Can only show text (choice label) or swatch, or both.
					// Can't show value - doesn't let user set it anyway, it's a unique id

					$choices_data = array();
					foreach ($field->choices as $choice) {
						array_push($choices_data, array(
							'text' => $choice['text'],
							'value' => $choice['value'],
							'color' => $choice['colorPicker_color']
						));
					}

					// Taken from GFQuiz::display_quiz_on_entry_detail (class-gf-quiz.php)
					$new_value = '';
					$new_value .= '<div class="gquiz_entry">';
					$results = gf_quiz()->get_quiz_results($form, $entry, false);
					$field_markup = '';

					foreach ($results['fields'] as $field_results) {
						if ($field_results['id'] == $field->id) {
							$field_markup = $field_results['markup'];
							break;
						}
					}

					if (in_array($field_entry_value_type, $color_entry_setting_values)) {
						// Modify the markup for color choices
						$field_markup = str_replace('<ul>', '<ul class="gf-color-picker-entry">', $field_markup);
						$field_markup = str_replace('<li>', '<li class="gf-color-picker-entry-choice">', $field_markup);
						foreach ($choices_data as $choice) {
							$replacement_markup = '';
							if ($field_entry_value_type == 'swatch') {
								$replacement_markup = '<span class="gf-color-picker-entry-swatch-color" style="background-color:' . $choice['color'] . ';"></span>';
							}
							$field_markup = str_replace($choice['text'], $replacement_markup, $field_markup);
						}
					}

					$new_value .= $field_markup;
					$new_value .= '</div>';

					$value = $new_value;

				}
				else if ($field->type == 'poll' && $field->is_entry_detail()) {

					$choices_data = array();
					foreach ($field->choices as $choice) {
						array_push($choices_data, array(
							'id' => $choice['id'],
							'text' => $choice['text'],
							'value' => $choice['value'],
							'color' => $choice['colorPicker_color']
						));
					}

					// Taken from GFPolls::display_poll_on_entry_detail (class-gf-polls.php)
					$results = gf_polls()->gpoll_get_results($form['id'], $field->id, 'green', true, true, $entry);
					$new_value = sprintf('<div class="gpoll_entry">%s</div>', rgar($results, 'summary'));
					gf_polls()->gpoll_add_scripts = true;

					//if original response is not in results display below
					$selected_values = gf_polls()->get_selected_values($form['id'], $field->id, $entry);
					$possible_choices = gf_polls()->get_possible_choices($form['id'], $field->id);
					foreach ($selected_values as $selected_value) {
						if (!in_array($selected_value, $possible_choices)) {
							$new_value = sprintf('%s<h2>%s</h2>%s', $new_value, esc_html__('Original Response', 'gravityformspolls'), $value);
							break;
						}
					}

					if (in_array($field_entry_value_type, $color_entry_setting_values)) {
						// Now modify the markup for color choices
						$new_value = str_replace('<div class="gpoll_entry">', '<div class="gpoll_entry gf-color-picker-entry">', $new_value);
						foreach ($choices_data as $choice) {
							$replacement_markup = '';
							if ($field_entry_value_type == 'swatch') {
								$replacement_markup = '<span class="gf-color-picker-entry-swatch"><span class="gf-color-picker-entry-swatch-color" style="background-color:' . $choice['color'] . ';"></span></span>';
							}
							$new_value = str_replace($choice['text'], $replacement_markup, $new_value);
						}
					}

					$value = $new_value;

				}
				else if ($field->type == 'survey' && $field->is_entry_detail()) {

					if ($field[$type_property] == 'checkbox') {

						$return_strings = array();
						$return_colors = array();

						foreach ($real_value as $key => $choice_value) {
							if (!empty($choice_value)) {
								$color = $this->get_choice_color_value($field, $choice_value);
								$text = RGFormsModel::get_choice_text($field, $choice_value);
								if ($field_entry_value_type == 'text') {
									array_push($return_strings, $text);
								}
								else if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($color)) {
									$swatch_item_markup = '';
									if ($field_entry_value_type == 'swatch') {
										$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
									}
									array_push($return_colors, $swatch_item_markup);
								}
							}
						}

						if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($return_colors)) {
							$value = $this->wrap_choice_swatches_markup($return_colors);
						}
						else {
							if (!empty($return_strings)) {
								$markup = '<ul class="bulleted">';
								foreach ($return_strings as $return_value) {
									$markup .= '<li>' . $return_value . '</li>';
								}
								$markup .= '</ul>';
								$value = $markup;
							}
							else {
								$value = implode(', ', $return_strings);
							}
						}

					}
					else {

						$color = $this->get_choice_color_value($field, $real_value);
						$text = RGFormsModel::get_choice_text($field, $real_value);

						if ($field_entry_value_type == 'text') {
							$value = $text;
						}
						else if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($color)) {
							$swatch_item_markup = '';
							if ($field_entry_value_type == 'swatch') {
								$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
							}
							$value = $this->wrap_choice_swatches_markup(array($swatch_item_markup));
						}

					}

				}
				else if ($field->type == 'radio'
					|| $field->type == 'post_custom_field'
					|| ($field->type == 'quiz' && !$field->is_entry_detail())
					|| ($field->type == 'poll' && !$field->is_entry_detail())
					|| ($field->type == 'survey' && !$field->is_entry_detail())) {

					if ($field->enableOtherChoice && $this->get_choice_color_value($field, $value) == '') {
						// User has chosen 'Other' for a custom color
						$color = $value;
						$text = $value;
					}
					else {
						$color = $this->get_choice_color_value($field, $value);
						$text = RGFormsModel::get_choice_text($field, $value);
					}

					// Don't show value for quiz, survey and poll fields
					$force_text_instead_of_value = ($field->type == 'quiz' || $field->type == 'poll' || $field->type == 'survey');

					if ($field_entry_value_type == 'text') {
						$value = $text;
					}
					else if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($color)) {
						$swatch_item_markup = '';
						if ($field_entry_value_type == 'swatch') {
							$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
						}
						$value = $this->wrap_choice_swatches_markup(array($swatch_item_markup));
					}

				}
				else if ($field->type == 'product') {

					// product field IF NOT FREE - single selection - saved as
					// Value ($Price)
					// Eg: Choice Value ($20.00)

					// product field IF FREE - single selection - saved as
					// Value
					// Eg: Choice Value

					if (strpos($value, '(') === FALSE && strpos($value, ')') === FALSE) {
						// FREE
						$color = $this->get_choice_color_value($field, $value);
						$text = RGFormsModel::get_choice_text($field, $value);
						if ($field_entry_value_type == 'text') {
							$value = $text;
						}
						else if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($color)) {
							$swatch_item_markup = '';
							if ($field_entry_value_type == 'swatch') {
								$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
							}
							$value = $this->wrap_choice_swatches_markup(array($swatch_item_markup));
						}
					}
					else {
						// NOT FREE
						$value_without_price = trim(substr($value, 0, strrpos($value, '(')));
						$color = $this->get_choice_color_value($field, $value_without_price);
						$text = RGFormsModel::get_choice_text($field, $value_without_price);
						if ($field_entry_value_type == 'text') {
							$value = $text;
						}
						else if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($color)) {
							$swatch_item_markup = '';
							if ($field_entry_value_type == 'swatch') {
								$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
							}
							$value = $this->wrap_choice_swatches_markup(array($swatch_item_markup));
						}
					}
				}
				else if ($field->type == 'option') {

					// product option field RADIO - single selection - saved as
					// Value ($Price)
					// Eg: Choice Value ($20.00)

					// product option field CHECKBOX - single selection - saved as
					// Value|Price
					// Eg: Choice Value|0

					if (strpos($value, '|') === FALSE) {
						// RADIO
						$value_without_price = trim(substr($value, 0, strrpos($value, '(')));
						$color = $this->get_choice_color_value($field, $value_without_price);
						$text = RGFormsModel::get_choice_text($field, $value_without_price);
						if ($field_entry_value_type == 'text') {
							$value = $text;
						}
						else if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($color)) {
							$swatch_item_markup = '';
							if ($field_entry_value_type == 'swatch') {
								$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
							}
							$value = $this->wrap_choice_swatches_markup(array($swatch_item_markup));
						}
					}
					else {
						// CHECKBOX
						list($name, $price) = explode("|", $value);
						$color = $this->get_choice_color_value($field, $name);
						$text = RGFormsModel::get_choice_text($field, $name);

						if ($field_entry_value_type == 'text') {
							$value = $text;
						}
						else if (in_array($field_entry_value_type, $color_entry_setting_values) && !empty($color)) {
							$swatch_item_markup = '';
							if ($field_entry_value_type == 'swatch') {
								$swatch_item_markup = $this->get_choice_swatch_item_markup($color, $text, $field_swatch_style);
							}
							$value = $this->wrap_choice_swatches_markup(array($swatch_item_markup));
						}
					}

				}

			}

			return $value;
		}

		return $value;
	}

	/**
	 * Add the color-picker-field class to the fields where colors are enabled.
	 *
	 * @param string $classes The CSS classes to be filtered, separated by empty spaces.
	 * @param GF_Field $field The field currently being processed.
	 * @param array $form The form currently being processed.
	 *
	 * @return string
	 */
	public function add_custom_class( $classes, $field, $form ) {
		if ( property_exists($field, 'colorPicker_enableColors') && $field->colorPicker_enableColors ) {
			$classes .= (GFCommon::is_form_editor()) ? ' color-picker-admin-field ' : ' color-picker-field ';
			$classes .= 'color-picker-use-colors ';

			$form_settings = $this->get_form_settings($form);
			$form_setting_display_style = ( isset($form_settings['gf_color_picker_display_style']) ) ? $form_settings['gf_color_picker_display_style'] : $this->_defaultSwatchStyle;
			$field_setting_display_style = ( property_exists($field, 'colorPicker_displayStyleSetting') && !empty($field->colorPicker_displayStyleSetting) ) ? $field->colorPicker_displayStyleSetting : 'form_setting';
			$display_style = ($field_setting_display_style == 'form_setting') ? $form_setting_display_style : $field_setting_display_style;
			$classes .= 'color-picker-style-'.$display_style.' ';

		}

		return $classes;
	}

	/**
	 * Add the tooltips for the field.
	 *
	 * @param array $tooltips An associative array of tooltips where the key is the tooltip name and the value is the tooltip.
	 *
	 * @return array
	 */
	public function add_color_choice_field_tooltips( $tooltips ) {
		$tooltips['color_picker_use_picker'] = '<h6>' . esc_html__( 'Use Color Picker', GFCP_TEXT_DOMAIN ) . '</h6>' . esc_html__( 'Enable to make this field a single color picker.', GFCP_TEXT_DOMAIN );
		$tooltips['color_picker_use_colors'] = '<h6>' . esc_html__( 'Use Colors', GFCP_TEXT_DOMAIN ) . '</h6>' . esc_html__( 'Enable to use of colors as choices.', GFCP_TEXT_DOMAIN );
		$tooltips['color_picker_show_labels'] = '<h6>' . esc_html__( 'Show Labels', GFCP_TEXT_DOMAIN ) . '</h6>' . esc_html__( 'Enable the display of the labels together with the color swatch.', GFCP_TEXT_DOMAIN );
		return $tooltips;
	}

	/**
	 * Add the custom settings for the fields to the fields general tab.
	 *
	 * @param int $position The position the settings should be located at.
	 * @param int $form_id The ID of the form currently being edited.
	 */
	public function color_choice_field_settings( $position, $form_id ) {
		if ( $position == 1362 ) {
			//wp_enqueue_media();// For Media Library
		}
	}


	public function add_color_options_markup( $choice_markup, $choice, $field, $value ) {
		if (  property_exists($field, 'colorPicker_enableColors') && $field->colorPicker_enableColors && !empty($choice) ) {
			$color = $choice['colorPicker_color'];

			$form = GFAPI::get_form( $field->formId );
			$form_settings = $this->get_form_settings($form);

			if (empty($color)) {
				$color = '';
			}

			if ($field->type != 'option' || GFCommon::is_form_editor()) {
				$choice_markup = preg_replace('#<label\b([^>]*)>(.*?)</label\b[^>]*>#s', implode("", array(
					'<label ${1}>',
						'<span class="color-picker-swatch">',
						    '<span class="color-picker-swatch-color-wrap">',
						        '<span class="color-picker-swatch-color" style="background-color:'.$color.';"><i></i></span>',
						    '</span>',
						    '<span class="color-picker-swatch-text-wrap">',
						        '<span class="color-picker-swatch-text-prefix"></span>',
						        '<span class="color-picker-swatch-text">${2}</span>',
						        '<span class="color-picker-swatch-text-suffix"></span>',
						    '</span>',
						'</span>',
					'</label>'
				)), $choice_markup);
			}
			else {
				$choice_markup = str_replace('<label', '<label data-color="'.$color.'"', $choice_markup);
			}
			return $choice_markup;
		}

		return $choice_markup;
	}

	public function add_single_color_picker_markup( $field_markup, $field, $value ) {

		if ($field->type == 'text' || ($field->type == 'survey' && $field->inputType == 'text') || ($field->type == 'post_custom_field' && $field->inputType == 'text')) {

			if ( property_exists($field, 'colorPicker_enableColors') && $field->colorPicker_enableColors ) {

				$color = $field['colorPicker_color'];
				$empty_color = false;
				$color = '';

				$form = GFAPI::get_form( $field->formId );
				$form_settings = $this->get_form_settings($form);

				if (empty($color)) {
					$empty_color = true;
					$color = '';
				}

				$color_text = ($empty_color) ? apply_filters('gf_colorpicker_action_label', __('Pick color', GFCP_TEXT_DOMAIN)) : $color;

				// TODO: Only set text if it's actually the pantone style?
				$prefix = apply_filters('gf_colorpicker_pantone_label_prefix', __('Color', GFCP_TEXT_DOMAIN));

				$field_markup = preg_replace('#<input\b([^>]*)>#s', implode("", array(
					'<input ${1}>',
					'<span class="color-picker-swatch">',
						'<span class="color-picker-swatch-color-wrap">',
							'<span class="color-picker-swatch-color" style="background-color:'.$color.';"><i></i></span>',
						'</span>',
						'<span class="color-picker-swatch-text-wrap">',
							'<span class="color-picker-swatch-text-prefix">'.$prefix.'</span>',
							'<span class="color-picker-swatch-text">'.$color_text.'</span>',
							'<span class="color-picker-swatch-text-suffix"></span>',
						'</span>',
					'</span>',
				)), $field_markup);

				return $field_markup;

			}

		}

		return $field_markup;
	}



	/**
	 * Add custom messages after plugin row based on license status
	 */

	public function gf_plugin_row($plugin_file='', $plugin_data=array(), $status='') {
		$row = array();
		$license_key = trim($this->get_plugin_setting('gf_color_picker_license_key'));
		$license_status = get_option('gf_color_picker_license_status', '');
		if (empty($license_key) || empty($license_status)) {
			$row = array(
				'<tr class="plugin-update-tr">',
					'<td colspan="3" class="plugin-update gf_color_picker-plugin-update">',
						'<div class="update-message">',
							'<a href="' . admin_url('admin.php?page=gf_settings&subview=' . $this->_slug) . '">Activate</a> your license to receive plugin updates and support. Need a license key? <a href="' . $this->_url . '" target="_blank">Purchase one now</a>.',
						'</div>',
						'<style type="text/css">',
						'.plugin-update.gf_color_picker-plugin-update .update-message:before {',
							'content: "\f348";',
							'margin-top: 0;',
							'font-family: dashicons;',
							'font-size: 20px;',
							'position: relative;',
							'top: 5px;',
							'color: orange;',
							'margin-right: 8px;',
						'}',
						'.plugin-update.gf_color_picker-plugin-update {',
							'background-color: #fff6e5;',
						'}',
						'.plugin-update.gf_color_picker-plugin-update .update-message {',
							'margin: 0 20px 6px 40px !important;',
							'line-height: 28px;',
						'}',
						'</style>',
					'</td>',
				'</tr>'
			);
		}
		elseif(!empty($license_key) && $license_status != 'valid') {
			$row = array(
				'<tr class="plugin-update-tr">',
					'<td colspan="3" class="plugin-update gf_color_picker-plugin-update">',
						'<div class="update-message">',
							'Your license is invalid or expired. <a href="'.admin_url('admin.php?page=gf_settings&subview='.$this->_slug).'">Enter valid license key</a> or <a href="'.$this->_url.'" target="_blank">purchase a new one</a>.',
							'<style type="text/css">',
								'.plugin-update.gf_color_picker-plugin-update .update-message:before {',
									'content: "\f348";',
									'margin-top: 0;',
									'font-family: dashicons;',
									'font-size: 20px;',
									'position: relative;',
									'top: 5px;',
									'color: #d54e21;',
									'margin-right: 8px;',
								'}',
								'.plugin-update.gf_color_picker-plugin-update {',
									'background-color: #ffe5e5;',
								'}',
								'.plugin-update.gf_color_picker-plugin-update .update-message {',
									'margin: 0 20px 6px 40px !important;',
									'line-height: 28px;',
								'}',
							'</style>',
						'</div>',
					'</td>',
				'</tr>'
			);
		}

		echo implode('', $row);
	}



	/**
	 * Determine if the license key is valid so the appropriate icon can be displayed next to the field.
	 *
	 * @param string $value The current value of the license_key field.
	 * @param array $field The field properties.
	 *
	 * @return bool|null
	 */
	public function license_feedback( $value, $field ) {
		if ( empty( $value ) ) {
			return null;
		}

		// Send the remote request to check the license is valid
		$license_data = $this->perform_edd_license_request( 'check_license', $value );

		$valid = null;
		if ( empty( $license_data ) || !is_object($license_data) || !property_exists($license_data, 'license') || $license_data->license == 'invalid' ) {
			$valid = false;
		}
		elseif ( $license_data->license == 'valid' ) {
			$valid = true;
		}

		if (!empty($license_data) && is_object($license_data) && property_exists($license_data, 'license')) {
			update_option('gf_color_picker_license_status', $license_data->license);
		}

		return $valid;
	}


	/**
	 * Handle license key activation or deactivation.
	 *
	 * @param array $field The field properties.
	 * @param string $field_setting The submitted value of the license_key field.
	 */
	public function license_validation( $field, $field_setting ) {
		$old_license = $this->get_plugin_setting( 'gf_color_picker_license_key' );

		if ( $old_license && $field_setting != $old_license ) {
			// Send the remote request to deactivate the old license
			$response = $this->perform_edd_license_request( 'deactivate_license', $old_license );
			if ( !empty($response) && is_object($response) && property_exists($response, 'license') && $response->license == 'deactivated' ) {
				delete_option('gf_color_picker_license_status');
			}
		}

		if ( ! empty( $field_setting ) ) {
			// Send the remote request to activate the new license
			$response = $this->perform_edd_license_request( 'activate_license', $field_setting );
			if ( !empty($response) && is_object($response) && property_exists($response, 'license') ) {
				update_option('gf_color_picker_license_status', $response->license);
			}
		}
	}


	/**
	 * Send a request to the EDD store url.
	 *
	 * @param string $edd_action The action to perform (check_license, activate_license or deactivate_license).
	 * @param string $license The license key.
	 *
	 * @return object
	 */
	public function perform_edd_license_request( $edd_action, $license ) {
		// Prepare the request arguments
		$args = array(
			'timeout' => GFCP_TIMEOUT,
			'sslverify' => GFCP_SSL_VERIFY,
			'body' => array(
				'edd_action' => $edd_action,
				'license' => trim($license),
				'item_name' => urlencode(GFCP_NAME),
				'url' => home_url(),
			)
		);

		// Send the remote request
		$response = wp_remote_post(GFCP_HOME, $args);

		return json_decode( wp_remote_retrieve_body( $response ) );
	}


	public function debug_output($data = '', $background='black', $color='white') {
		echo '<pre style="padding:20px; background:'.$background.'; color:'.$color.';">';
			print_r($data);
		echo '</pre>';
	}


} // end class
