<?php
/*
Plugin Name: Gravity Forms Color Picker
Plugin URI: https://jetsloth.com/gravity-forms-color=picker/
Description: Easily add a color picker to any Single Line Text field, or provide colour swatches as choices for for Radio Buttons or Checkboxes fields in your Gravity Forms, including Survey, Quiz, Product and Option fields that have their field type set to Radio Buttons or Checkboxes
Author: JetSloth
Version: 1.0.4
Requires at least: 4.0
Tested up to: 5.1.1
Author URI: https://jetsloth.com
License: GPL2
Text Domain: gf_color_picker
*/

/*
	Copyright 2017 JetSloth

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

define('GFCP_VERSION', '1.0.4');
define('GFCP_HOME', 'https://jetsloth.com');
define('GFCP_NAME', 'Gravity Forms Color Picker');
define('GFCP_SLUG', 'gf-color-picker');
define('GFCP_TEXT_DOMAIN', 'gf_color_picker');
define('GFCP_AUTHOR', 'JetSloth');
define('GFCP_TIMEOUT', 20);
define('GFCP_SSL_VERIFY', false);

add_action( 'gform_loaded', array( 'GF_Color_Picker_Bootstrap', 'load' ), 5 );


class GF_Color_Picker_Bootstrap {

	public static function load() {

		if ( ! method_exists( 'GFForms', 'include_addon_framework' ) ) {
			return;
		}

		require_once( 'class-gf-color-picker.php' );

		GFAddOn::register( 'GFColorPicker' );
	}
}

function gf_color_picker() {
	if ( ! class_exists( 'GFColorPicker' ) ) {
		return false;
	}

	return GFColorPicker::get_instance();
}


add_action('init', 'gf_color_picker_plugin_updater', 0);
function gf_color_picker_plugin_updater() {

	if (gf_color_picker() === false) {
		return;
	}

	if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
		// load our custom updater if it doesn't already exist
		include( dirname( __FILE__ ) . '/inc/EDD_SL_Plugin_Updater.php' );
	}

	// retrieve the license key
	$license_key = trim( gf_color_picker()->get_plugin_setting( 'gf_color_picker_license_key' ) );

	// setup the updater
	$edd_updater = new EDD_SL_Plugin_Updater( GFCP_HOME, __FILE__, array(
			'version'   => GFCP_VERSION,
			'license'   => $license_key,
			'item_name' => GFCP_NAME,
			'author'    => 'JetSloth'
		)
	);

}
